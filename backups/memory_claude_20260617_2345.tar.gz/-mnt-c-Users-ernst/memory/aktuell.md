# Aktuell — 2026-06-17

## ⏳ D2D-UPLOAD LÄUFT — Bolla leitet Chris SCHRITT FÜR SCHRITT (17.06. ~23:40)
- **Konto + W-8BEN (Tax) + Bankdaten: ALLES ERLEDIGT.** ✅ Jetzt: Buch-Upload im Browser.
- **Rolle Bolla:** Chris klickt im Browser, ich lotse Schritt für Schritt, lege Texte via clip.exe (`/mnt/c/Windows/System32/clip.exe`) ins Clipboard. NICHT alles auf einmal hinwerfen.
- **Reihenfolge:** erst Buch 1 DE, dann Buch 2 EN.
- **Alle fertigen Texte/Metadaten:** `/mnt/d/OneDrive/Dokumente/AURORA/AURORA_D2D_Materialien.md`
- **EPUBs:** `D:\OneDrive\Dokumente\AURORA\AURORA_deutsch.epub` / `AURORA_english.epub`
- **Cover:** `D:\OneDrive\Dokumente\AURORA\cover_kdp.png`
- **Regeln:** Preise €4,99 / $4.99 · **Amazon IMMER abwählen** (läuft über KDP) · gratis D2D-ISBN · Tolino unbedingt drin lassen (wichtigster DE-Kanal nach Amazon).
- **DE-Schritte:** 1 Publish a New Book→Ebook · 2 Details (Titel AURORA, Autor Chris Mandel, Sprache DE) · 3 EPUB hoch · 4 Cover hoch · 5 Beschreibung(Klappentext)+BISAC(Thriller-first)+Keywords · 6 gratis ISBN · 7 Preis · 8 Kanäle (Amazon AUS) · 9 Publish.

## ⚠️ STRUKTUR-FIX: aktuell.md war doppelt (17.06. 23:37)
- **Problem:** Es gab ZWEI aktuell.md: `~/.claude/.../memory/` (auto-load beim Start) und `workspace/memory/` (von mir gepflegt) → drifteten auseinander → nach /clear las ich den alten Stand. Großer Zeitfresser für Chris.
- **Fix:** workspace-Version ist jetzt ein **Symlink** auf die .claude-Version (gleicher inode). Eine Datei, zwei Pfade, keine Divergenz mehr möglich. Alte .claude-Version gesichert als `aktuell.md.alt_vor_merge_20260617`.

## ✅ Telegram-Bot „aktive Session"-Fehlmeldung gefixt (17.06. 23:26)
- **Bug:** `interactive_claude_running()` (telegram_bot.py) filterte Claude-Prozesse per ` -p ` im Befehl — aber Claude Code überschreibt seinen Prozessnamen mit `claude` und versteckt ALLE Argumente (auch in /proc/PID/cmdline). `-p` war nie sichtbar → Funktion meldete fast immer „interaktiv aktiv" → 60s-Timeout → irreführende Meldung „Bolla ist gerade in einer aktiven Session…".
- **Fix:** Unterscheidung jetzt am TTY (interaktive Session = `pts/*`, Bot-Hintergrund-Call = `?`). Timeouts erhöht: 90s (parallel) / 150s.
- **Watchdog NEU:** `scripts/telegram_bot_watchdog.sh` + cron `*/2` — startet Bot bei Crash neu (vorher nur @reboot). Bot läuft jetzt via cron, PPID 1.

## AURORA — STIL-ENTZERRUNG läuft (17.06. vorm.) 🔄
- **Befund:** Chris stolpert beim Lesen über zu dichten Stakkato/Trikolon-Rhythmus ("kein X, kein Y, kein Z" + kurzer Echosatz). KI-Stil-Tell + kollidiert mit Stilziel "packend wie Follett". Ursache mit-erkannt: meiste Kapitel mit **Sonnet** geschrieben (dessen Schönschreib-Default).
- **Entscheidung Chris:** In BEIDEN Büchern (DE+EN) durchziehen, mit Subagenten, im Hintergrund.
- **Workflow `aurora-destyle` (Task wfetjit7h, Run wf_cefa45f1-bed) läuft:** 94 Kapitel (47 DE + 47 EN). Opus entzerrt Rhythmus (NUR Satzbau, Inhalt 1:1), Sonnet verifiziert Faktentreue. Quota beim Start: 5h 13%, 7d 75% übrig (Max Plan, grün).
- **I/O:** Original-Kapitel in `data/destyle/{de,en}/in/kapNN.txt`, überarbeitet in `.../out/kapNN.txt`.
- **Backups vor Start:** `ki_buch_backup_vor_destyle_20260617_100206.json`, `ki_buch_en_adapted_backup_vor_destyle_20260617_100206.json`.
- **Workflow durch:** 89/94 ok. Plausi perfekt (DE ±0%, EN −0,4%, keine Datei fehlt/abgeschnitten).
- **5 Nacharbeiten erledigt:** de17 ("ganze" raus) + en17 ("No." raus) = Mini-Erfindungen gefixt. de5/de15/en38 mutiger neu (Opus, 2. Durchlauf) + per Sonnet verifiziert: de15 ok, en38 ok (2 Name-Diffs = verschmolzene Echos, harmlos), de5 hatte 2 echte Auslassungen ("als Signatur", "nur eine Folge von Ziffern") → von Hand repariert.
- **✅ ABGESCHLOSSEN (17.06. 12:35):** Chris hat Stil abgenommen ("ja ist besser"), Grad = konservativ/entstaut (Stimme erhalten). 
- **Merge:** 47/47 DE + 47/47 EN out-Texte zurück in `ki_buch.json` / `ki_buch_en_adapted.json` (mit Wortzahl-Asserts). 
- **EPUBs neu gebaut + verifiziert:** `AURORA_deutsch.epub` (3125 KB), `AURORA_english.epub` (3110 KB) in `/mnt/d/OneDrive/Dokumente/AURORA/`. Verifiziert: neue Stilform drin, alte Stakkato-Form weg, Timeline-Fix („einundzwanzig"/"twenty-one years") erhalten, Namen ok.
- **Backups:** JSON `*_backup_vor_destyle_20260617_100206.json`, EPUB `AURORA_*_vor_destyle_20260617_*.epub`. Beispiel-Datei: `OneDrive/Desktop/AURORA_Stil_Vorher_Nachher.txt`.
- **✅ KINDLE (17.06.):** Beide finalen EPUBs (entstaut, je ~3,05 MB) via `scripts/kindle_send.py` an `ernstmandel_MnAuOy@kindle.com` gesendet. Amazon-Verifikationsmail → Chris klickt selbst.
- **✅ KDP-MARKETING-FEINSCHLIFF (17.06.):** `AURORA_KDP_Materialien.md` überarbeitet (Backup `*_backup_vor_keyword-fix_20260617.md`). Recherche: Frauen = größere/kauffreudigere eBook-Gruppe, Lieblingsgenre Krimi/Thriller (#1); Sci-Fi dagegen männerlastig/kleiner. Daher: (a) Klappentext + dezente emotionale Note („Sehnsucht. Schuld. Ein Verlust…" — kein Geheimnis-Spoiler), (b) Keywords Richtung Thriller + „starke weibliche Hauptfigur", (c) Kategorien getauscht: Haupt = Thriller&Krimis→Technothriller, Neben = Sci-Fi→Techno-Thriller. Romanze/Humor nur Würze → NICHT als Genre labeln (Reklamationsgefahr), nur im Klappentext nutzen. Klappentext liegt NUR in der KDP-MD, nicht im EPUB → keine Neubauten nötig.
- **✅ D2D-MATERIALIEN (17.06.):** Neue Datei `AURORA_D2D_Materialien.md` (DE+EN) erstellt. Enthält: Plattform-Aufteilung (Amazon NUR via KDP, Rest via D2D, bei D2D Amazon abwählen, kein KDP Select), W-8BEN-Hinweis, deutscher Klappentext (= KDP) + **neuer englischer Blurb** (Boston/Marley-Setting, mit emotionaler Note), BISAC-Kategorien (Thriller-first) + DE/EN-Keywords. Frage Chris beantwortet: ja, beide Bücher bei beiden Distributoren — mit Shop-Aufteilung (kein Amazon-Doppeleintrag).
- **OFFEN:** Tagesnotiz + git commit + OneDrive-Backup (`rsync .claude/`) bei Session-Ende. Publishing-Upload (KDP+D2D) wartet weiter auf Chris.
- **LERNPUNKT:** Desktop-Dateien gehören auf OneDrive-Desktop (`/mnt/d/OneDrive/Desktop/`), nicht lokal — neu in rules_kritisch + [[feedback_desktop_onedrive]].

---

# Aktuell — 2026-06-16

## AURORA — Welle A (Blocker-Fixes) LÄUFT (16.06. nachm.)
- Entscheidung Chris: **DE zuerst, dann EN-Sync. Welle B kreativ mit Opus.** Quota grün.
- ✅ **Blocker #2 (Tippfehler): 15 Stück gefixt** in `ki_buch.json` (Script mit Count-Assert). Backup: `ki_buch_backup_wellea_20260616_135930.json`.
- ✅ **Blocker #1 (Timeline): ERLEDIGT.** Chris wählte **Option A** (alles rund um Verlust = 22 J., Tochter starb mit 4 J. 7 Mon., Trennung = Tod ~22 J., Theos Beruf bleibt 30 J., Kennenlernen 30 J.). Opus-Agent erstellte 99 Edit-Liste → 96 angewendet (3 „beruf-korrektur" 20→30 verworfen, Scope-Creep) + 2 Prosa-Umformulierungen (K17 Rechen-Beat „8 J. später"→„im selben Jahr"; K34 Doppelzahl raus). Verifiziert: 0 Reste „einundzwanzig", Sterbealter 4J7M, Noah-Bug K23 (zehn→fünfzehn). Backup: `ki_buch_backup_vor_timeline_*`. Liste: `timeline_edits.json`.
- ⚠️ NEBENBEFUND (separat, später): Theos Berufsdauer ist im Buch mal 20/30/40 J. — eigene kleine Inkonsistenz, NICHT im Timeline-Fix angefasst.
- ✅ **WELLE A KOMPLETT (alle 5 Blocker):** #1 Timeline, #2 Tippfehler(15), #3 POV-Bruch K9 (Inferenz nach vorne), #4 Personenzahl (K26 „sechs Gesichter"→„vier", K29 „Sechs"→„Vier erwachsene Menschen"; Opus-Agent verifizierte Bühnenbesetzung), #5 Nachname Marlie=Braun (Fehlalarm, durchgängig konsistent). Backups: `ki_buch_backup_wellea_*`, `ki_buch_backup_vor_timeline_*`.
- ✅ **DE-EPUB neu gebaut + verifiziert** (`AURORA_deutsch.epub`, 3,1MB). Auch Epilog im Generator-Script gefixt (Theo „zwanzig"→„zweiundzwanzig Jahre", Z.50). EPUB-Check: 0 „einundzwanzig", 0 alte Tippfehler, alle Fixes drin. Vorheriges EPUB gesichert als `AURORA_deutsch_vor_wellea.epub`. **→ DE ist jetzt einreichungsreif.**
- ✅ **WELLE B (Kür) KOMPLETT in DE** (Chris: „alles + Ton passt"). 19 Edits + 3 „Weg"-Quotes angewendet, DE-EPUB neu gebaut + verifiziert:
  - Noah belebt K12/18/24/32/33/34 (Opus, roter Faden „der Macher, der baut statt redet"). Backup `ki_buch_backup_vor_welleb_*`.
  - Humor K41 (Ellie/Leni trockener Galgenhumor), K46 gestrafft (3 Schnitte: doppeltes „vorsichtig", „am Grab"-Wdh., Maschinen-Aufzählung).
  - Notstrom-Logik K11/24/45 erklärt, K40 Sekunden auf „achtzig" vereinheitlicht (6×, 0 Reste) + 100km-Hauptschalter entschärft. Redundanzen K5/20/43.
  - Chris-Wunsch: AURORAs Begriff „das Weg" (K24) in Anführungszeichen „Weg" (auch im AURORA-Dialog).
- ✅ **EN-SYNC KOMPLETT.** 4 Opus-Agenten spiegelten DE→EN auf `ki_buch_en_adapted.json` (Namen Marley/Ellie/Howell/Boston; AURORAs Wort „Gone"). 119 Edits angewendet (en_timeline 97, en_noah 6, en_narrativ 7, en_technik 9) + 2 „Gone"-Quotes im AURORA-Dialog. Backup `ki_buch_en_backup_vor_sync_*`. EN-EPUB `AURORA_english.epub` (3111KB) neu gebaut + verifiziert: 0× „twenty-one years", Sterbealter „four years and seven months", Noah-Bug→fifteen, „Gone"-Quotes drin (escaped), K40 „eighty seconds" 6×, four faces/Four adults.

## AURORA — KOMPLETT FERTIG (16.06.) 🎉
**Beide Ausgaben (DE + EN) verkaufsreif, alle 5 Blocker + komplette Kür (Welle B) erledigt und synchron, beide EPUBs neu gebaut + verifiziert.**
- DE: `AURORA_deutsch.epub`, EN: `AURORA_english.epub` (beide in `/mnt/d/OneDrive/Dokumente/AURORA/`).
- Pre-Edit-Backups: `AURORA_deutsch_vor_wellea.epub`, JSON-Backups `ki_buch_backup_vor_timeline/wellea/welleb_*`, `ki_buch_en_backup_vor_sync_*`.
- Edit-Listen als Doku: `timeline_edits.json`, `welleb_*_edits.json`, `en_*_edits.json` (workspace/data).
- OFFEN/optional für später: Theos Berufsdauer-Inkonsistenz (20/30/40 J.) — eigene kleine Sache, nie kritisch. Welle 3 (Foreshadowing Folgeband) weiter optional.
- ✅ **Beide EPUBs an Kindle gesendet** (16.06. abends) via neues Skript `scripts/kindle_send.py` (Graph Upload-Session, da >4MB-sendMail-Limit; Doku in `reference_kindle.md`). Amazon-Verifikationsmail an ernstmandel@outlook.de → Chris muss klicken (48h).
- Nächster realer Schritt = Publishing (KDP + D2D, €4.99/$4.99 — Plan steht im Memory).

## AURORA — Verkaufsreife-Check + Lektorat ✅ (16.06.)
- **Mechanischer Wort-Check** (zusammengeschriebene Wörter) auf beide Sprachen:
  - DE: 1 Fehler `einGeständnis` (Kap22) → gefixt zu „ein Geständnis", DE-EPUB neu gebaut + verifiziert (0 Fehler, 3× korrekt). Backup: `ki_buch_backup_tippfix_*`.
  - EN: 0 echte Fehler (nur „PhD", korrekt). EN-EPUB unverändert.
- **Inhaltl. Einschätzung** (Basis: AURORA_Spannungslandkarte.md vom 14.06, Sonnet+Opus, + aktueller Status):
  - Status JSON: „Lektorat Welle 1+2 abgeschlossen", `buch_fertig: True`. Ende löst auf (Maria+AURORA), kein Cliffhanger.
  - Spannung stark (kein Hook <8), Twist-Mechanik (AURORA=verlorenes Kind) sauber gepflanzt. Keine Plotlöcher.
  - Die 2 „offenen Köder" aus Bericht (Kap13 „zweite Lüge", Kap32 „Zahl") sind real KEINE Löcher — szenenintern bzw. in Kap33/34 weitergeführt.
  - **Verdict: verkaufsreif.** Welle 3 (Foreshadowing f. Folgeband) optional, kein Blocker.
- **Gegencheck FERTIG** (47 Kapitel + Opus-Synthese, ~984k Tokens). Report: `/mnt/d/OneDrive/Dokumente/AURORA/AURORA_Gegencheck_16-06.md`.
  - **Urteil: VERKAUFSREIF — MIT AUFLAGEN** (nicht „glatt verkaufsreif" wie meine erste Einschätzung!).
  - Welle 1 sitzt (Spannungstäler weg, kein Kap <7 im Hauptkörper). Welle 2 nur halb: **Marlie ja, Noah nein** (noch in ~1/3 der Kap blass).
  - **5 BLOCKER vor Einreichung (offen, mechanisch lösbar):** (a) Timeline-Chaos 20/21/22/12/10 Jahre quer durchs Schlussdrittel, Kap23 im selben Absatz widersprüchlich → Master-Chronologie festlegen. (b) ~15 echte Tippfehler/Grammatik (zurueknehmen, Junihaft, „großgezogen hätte können") — meine Regex fand nur Klebungen, DIESE nicht! (c) POV-Bruch Kap9. (d) Personenzahl Kap26/29 geht nicht auf. (e) Nachname-Kanon Marlie („Braun"?).
  - Neu: Kap41 Humor 2→1 (Sorgenkind), Kap46 Sp5 (schwächstes Kap, Ausklang straffen).
  - **NÄCHSTER SCHRITT:** Die 5 Blocker abarbeiten (am besten gezielter Fix-Durchlauf), dann EPUBs neu bauen.
- **Korrektorat-Tool (LanguageTool):** Chris gefragt — Antwort: lohnt für diesen KI-Text kaum (gratis/lokal, aber dass/das etc. macht KI eh richtig; mechan. Klebungen schon gecheckt). Nicht eingerichtet.

## MC „Failed to fetch" behoben ✅ (Bolla-Kachel, lokal)
- **Ursache:** ZWEI mission_control_api.py-Prozesse lauschten gleichzeitig auf 18790 (SO_REUSEPORT). Race beim Reboot: @reboot-Start + */2-Watchdog feuerten gleichzeitig, Watchdog (`pgrep|head -1`) sah Doppelstart nie. Kernel-Round-Robin → ~50% Requests beim hakeligen Prozess → sporadisch „Failed to fetch".
- **Fix:** SO_REUSEPORT aus `mission_control_api.py` (~Z.7330) entfernt — nur noch SO_REUSEADDR. Zweitstart scheitert jetzt sauber mit „Address already in use". Beide Prozesse gekillt, einen frisch gestartet.
- **Verifiziert:** 1 Prozess (PID 545083), 1 Listener, /api/status 200, Bolla-Chat end-to-end success.
- **Defense-in-Depth ✅:** `mc_watchdog.sh` erweitert — erkennt jetzt Doppelstart: ermittelt echten Port-Inhaber (ss), behält ihn, killt überzählige Prozesse. Fälle: kein Prozess→start, Prozess(e) ohne Listener→kill+restart, mehrere→Listener behalten. Live getestet mit Fake-Doppelgänger: korrekt gekillt, echter Server unversehrt.

---

# Aktuell — 2026-06-15 (Nacht)

## Status: Übersetzungs-Workflow läuft im Hintergrund

### EPUB Deutsch ✅ FERTIG
- `/mnt/d/OneDrive/Dokumente/AURORA/AURORA_deutsch.epub`
- 1,18 MB, MAI-Cover (Atmosph. Hintergrundbild + CSS-Titeloverlay)
- 47 Kapitel + Prolog + Vorspann + Vorwort + Impressum
- Kindle: EPUB an @kindle.com senden oder in Kindle-App importieren (P20)

### AURORA Englisch — Übersetzungs-Workflow (Workflow-ID: wf_a35c2870-694)
- **Läuft gerade:** 48 Kapitel parallel mit Sonnet
- **Cache:** `/home/bolla/workspace/data/ki_buch_en_cache/` (Kapitel für Kapitel)
- **Ausgabe:** `ki_buch_en.json` nach Workflow-Ende
- **Dann:** Englisches EPUB generieren (aurora_epub_en_gen.py — noch zu schreiben)

### Figuren-Anpassungen Englisch (Translation Bible)
- Leni Yilmaz → Ellie Yilmaz
- Marlie Braun → Marley Brown
- Noah Khoury → unverändert
- Vogt → Director Howell
- Hamburg → Boston MA, NovaTech HQ = Boston Seaport
- BND → NSA/CIA je Kontext
- AURORA-Stil: Englisch mit leichter Nicht-Muttersprachler-Eigenheit

### Nächste Schritte (nach Workflow)
- [ ] Englisches EPUB aus ki_buch_en.json generieren
- [ ] Vorspann EN prüfen (Sleeping-Beauty-Motiv, nicht Etymologie)
- [ ] Beide EPUBs an Chris melden

### Sonstiges erledigt heute
- ISBN/Publishing-Planung: KDP + D2D, €4.99 / $4.99 → in Memory gespeichert
- Haiku → Sonnet für Übersetzung korrigiert in Memory
- Git-Commit + OneDrive-Backup ✅
