---
name: feedback-session-resume
description: "Nach /clear sauber aufsetzen — aktuell.md ist die EINE Quelle, Stand IMMER dort sichern"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: a791f801-1f65-410b-ab51-9759d0b9d594
---

# Sauberes Aufsetzen nach /clear

Chris verliert massiv Zeit, wenn ich nach einem `/clear` den falschen oder veralteten Stand lese und nicht da weitermache, wo wir waren.

**Why:** Es gab historisch ZWEI `aktuell.md` (`~/.claude/.../memory/` = auto-load beim Start, und `workspace/memory/` = von mir gepflegt). Sie drifteten auseinander → nach /clear las ich den alten Stand und fragte Dinge, die längst erledigt waren.

**How to apply:**
- **Fix steht (17.06.2026):** `workspace/memory/aktuell.md` ist jetzt ein **Symlink** auf die `.claude`-Version → physisch EINE Datei. Egal welchen Pfad ich nehme, es ist dieselbe. Symlink nicht versehentlich löschen/überschreiben.
- Bei Session-Start `aktuell.md` lesen und den GENAUEN nächsten Schritt übernehmen — inkl. WIE (z.B. „leite Chris Schritt für Schritt, nicht alles auf einmal").
- Vor JEDEM `/clear` bzw. bei jeder größeren Aktion den Stand + nächsten Schritt + Arbeitsweise in `aktuell.md` schreiben — nicht in eine Nebendatei. ([[feedback_aktuell_md]])
