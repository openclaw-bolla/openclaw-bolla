# AURORA Publishing Plan — Deutsch + English + D2D

## Terminologie
- **KDP:** Amazon Kindle Direct Publishing (nur Amazon, aber höhere Royalty mit Select)
- **D2D:** Draft2Digital (Apple Books, Google Play, Kobo, etc.)
- **Strategie:** KDP ohne Select (35%) + D2D für breite Reichweite

---

## ✅ DEUTSCHES BUCH — KDP (17.06. abends)
**Status:** Als Entwurf gespeichert, warte auf Bankbestätigung (bis 3 Tage)

**Konfiguration:**
- Kategorien: Thriller&Krimis → Technothriller (Haupt) + Netzwerke (Neben)
- Preis: 4,99€ (EUR)
- Royalty: 35% (keine KDP Select, damit D2D möglich)
- EPUB: `AURORA_deutsch.epub` (3,1 MB) — schon hochgeladen

**Nach Bankbestätigung:** Klick "Veröffentlichen" und es geht live

---

## 🔄 ENGLISCHES BUCH — KDP (später heute)
**Unterschied zu Deutsch:** KEINE Wartezeit — Bankdaten sind schon bestätigt!

**Gleicher Prozess wie DE:**
1. Kategorien setzen (Thriller-first)
2. Preis: $4.99 USD (4.99 ist OK, da zwischen 2.99–9.99 für 35%)
3. Royalty: 35%
4. EPUB: `AURORA_english.epub` (3,1 MB)
5. Speichern → sofort veröffentlichen (keine Wartezeit!)

---

## 📦 D2D — BEIDE BÜCHER (später heute, Step-by-Step im Terminal)

**Plattformen (nicht Amazon):**
- Apple Books
- Google Play
- Kobo
- Scribd
- itch.io
- Smashwords

**Preise (identisch):**
- EUR-Märkte: €4,99
- USD-Märkte: $4,99

**Prozess:**
1. D2D-Account einloggen (draft2digital.com)
2. Neuen Titel hinzufügen (AURORA Deutsch)
3. EPUB hochladen
4. Kategorien setzen (Thriller)
5. Keywords + Beschreibung (wie bei KDP)
6. **WICHTIG:** Amazon ABWÄHLEN (sonst Konflikt mit KDP!)
7. Preise einstellen
8. Review & Publish
9. Dann dasselbe für English-Version

---

## 📋 Checkliste
- [ ] Deutsches KDP-Buch: Bankbestätigung abwarten (3 Tage max)
- [ ] Deutsches KDP-Buch: Nach Bestätigung veröffentlichen
- [ ] Englisches KDP-Buch: Hochladen & sofort veröffentlichen
- [ ] D2D Deutsch: Alle Märkte außer Amazon
- [ ] D2D English: Alle Märkte außer Amazon
- [ ] Überprüfen: Keine Doppel-Einträge auf Amazon (KDP-only!)

---

*Gespeichert: 2026-06-17*
