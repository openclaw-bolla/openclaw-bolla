---
name: feedback-tageszeit
description: WSL-Uhr kann nach Reboot mehrere Stunden falsch gehen — IMMER date + Plausibilitätscheck
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 45b0c2b6-e5ff-4c48-ac61-83fd6511af0e
---

IMMER `date` aufrufen vor Tageszeit-Aussagen.

**Why:** WSL-Uhr kann nach Reboot stundenweise falsch gehen. Konkretes Beispiel 2026-06-09: `date` zeigte 10:06 CEST, echte Zeit war 14:34 CEST — 4,5 Stunden Abstand!

**How to apply:**
- `date` aufrufen, ABER auch auf Plausibilität prüfen: Stimmt die Zeit mit dem Kontext überein (ScheduleWakeup-Timestamps, was Chris sagt, vorherige Nachrichten)?
- ScheduleWakeup zeigt die echte Systemzeit — wenn `date` und ScheduleWakeup-Timestamp stark abweichen: ScheduleWakeup vertrauen
- Bei Unsicherheit kurz beim User nachfragen bevor Zeitversprechen gemacht werden ("laut meiner Uhr ist es X — stimmt das?")
