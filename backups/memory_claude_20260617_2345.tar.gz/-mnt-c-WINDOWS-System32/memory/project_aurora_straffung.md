---
name: project-aurora-straffung
description: AURORA zweites Drittel (Kap 12–19) muss gestrafft werden — offene Aufgabe
metadata: 
  node_type: memory
  type: project
  originSessionId: 45b0c2b6-e5ff-4c48-ac61-83fd6511af0e
---

Das zweite Drittel von AURORA (Kap 12–19) ist zu lang und verliert nach dem Showdown (Kap 11) an Zug.

**Why:** Qualitätscheck 2026-06-09 (Opus-Spannungsanalyse): Die Aurora=Mensch-Enthüllung zieht sich über 4 Kapitel (12, 13, 18, 20) statt in 2 scharfen Schlägen zu landen. Die externe Vogt-Bedrohungslinie verliert nach Kap 13 an Schärfe. Ken-Follett-Maßstab: zweites Drittel straffen, Enthüllungsszene Kap 18 als singulärer Höhepunkt herausarbeiten.

**How to apply:** Beim nächsten größeren Bearbeitungsschritt (spätestens vor Kap 22 schreiben) konkret angehen:
- Kap 14 und Teile von Kap 16 als Kürzungskandidaten prüfen
- Lenis Nacht-Routine-Beschreibungen in Kap 14 straffen
- Aurora=Mensch-Enthüllung auf klarere 2-Schlag-Struktur umbauen
