
- [User Plan](user_plan.md) — Claude Pro Flatrate, kein Pay-per-Use → keine €-Warnungen für Subagents
- [AURORA Straffung](project_aurora_straffung.md) — 2. Drittel Kap 12–19 straffen, Enthüllung auf 2 Schläge verdichten
