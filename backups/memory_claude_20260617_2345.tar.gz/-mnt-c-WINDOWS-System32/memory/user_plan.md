---
name: user-plan
description: "Chris hat Claude Pro (Flatrate) — kein Pay-per-Use, keine Token-Kosten pro Aktion"
metadata: 
  node_type: memory
  type: user
  originSessionId: 45b0c2b6-e5ff-4c48-ac61-83fd6511af0e
---

Chris hat einen **Claude Pro Plan** (monatliche Flatrate, kein Pay-per-Use).

**Why:** Keine Kosten pro Token/Agent-Call. Das Schwaben-Protokoll gilt weiterhin für externe APIs (z.B. Google, OpenAI, andere Dienste), aber NICHT für Claude-eigene Subagents/Workflows — die kosten nichts extra.

**How to apply:** Bei Workflows/Agenten keine Kostenschätzungen in € nennen (wäre irreführend). Stattdessen nur noch Zeitaufwand und Qualitätsabwägung kommunizieren. Einzige Schranke: Session-Limits (wie gestern Nacht getroffen, Reset nach Stunden).
