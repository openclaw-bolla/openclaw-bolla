---
name: project-bildgen-ordner
description: BildGen Wunsch-Feature — Zielordner frei wählbar beim Speichern
metadata: 
  node_type: memory
  type: project
  originSessionId: 15a49665-2efe-468c-a1eb-7159840d986d
---

Chris möchte beim BildGen-Download (⬇-Button) den Zielordner selbst auswählen können.

**Wunsch:** Ordner-Auswahl idealerweise direkt über den Windows-Explorer-Dialog (Folder-Picker).

**Why:** Aktuell wird immer fix nach `/mnt/d/OneDrive/Bilder/BildGen` gespeichert. Chris will flexibel wählen können.

**How to apply:** Wenn BildGen-Download verbessert wird: `window.showDirectoryPicker()` API im Browser (Chromium/Edge unterstützt das), oder alternativ über MC-API einen `POST /api/bildgen/save-to-disk` mit optionalem `folder`-Parameter + Server-seitiger Ordner-Auswahl via Dialog.

**Status:** Nicht-dringend, "irgendwann".
