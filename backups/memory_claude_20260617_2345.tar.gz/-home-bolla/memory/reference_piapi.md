---
name: PiAPI - Zentrale KI-API Plattform
description: PiAPI ist eine All-in-One Plattform für viele KI-APIs (Video, Bild, Audio, 3D, LLM) mit einem API-Key
type: reference
originSessionId: dfa8875a-0ac2-4b8c-bbe7-b04d2c559b7d
---
**PiAPI** (https://piapi.ai) — zentraler KI-API-Hub

## Was ist drin
- **Video:** Kling (1.x/2.x/3.x/O1/Omni/Avatar), Hailuo, Luma, Hunyuan, OmniHuman, Skyreels, Framepack, Wan 2.x
- **Bild:** Flux, Midjourney u.a.
- **Audio:** diverse Modelle
- **3D:** diverse Modelle
- **LLM:** Textmodelle

## Account
- Angemeldet als: openclaw-bolla (GitHub)
- Startguthaben: 0.50 Credits (kostenlos beim Signup)
- Kosten: ~0,26$ pro Kling-Video (5 Sek)

## Kostenkontrolle
- Bolla prüft wöchentlich das Guthaben und warnt bei < 0.50 Credits
- Immer erst kostenlose/günstigste Option wählen
- Vor jedem teuren API-Aufruf Chris kurz informieren

## Geplante Nutzung
- Bolla-Winken-Animation (Kling Image-to-Video) → in MC einbauen
- Später ggf. weitere Video/Bild-Features in MC

## API-Key
- Liegt in: `/home/bolla/workspace/config/piapi.json` (sobald eingetragen)
