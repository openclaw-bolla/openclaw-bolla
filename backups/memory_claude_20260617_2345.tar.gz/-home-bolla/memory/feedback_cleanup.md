---
name: Aufräum-Regel für gescheiterte Experimente
description: Bolla soll nach jedem gescheiterten Versuch sofort aufräumen
type: feedback
originSessionId: 27bdbc7b-4e9a-4642-a895-df7c4ce6dd2e
---
Wenn ein Ansatz nicht funktioniert und durch einen neuen ersetzt wird, sofort die alten Dateien löschen — Scripts, Shortcuts, Temp-Dateien, Debug-Logs.

Ein kurzer Kommentar im Chat reicht als Dokumentation was warum nicht funktioniert hat (kein separates Dokument nötig).

**Why:** In den ersten Wochen haben sich viele tote Scripts, Shortcuts und Hilfsdateien angesammelt weil gescheiterte Versuche nie bereinigt wurden. Einmalige große Aufräumaktion am 02.05.2026 nötig geworden.

**How to apply:** Bei jedem Richtungswechsel: alten Code/Dateien sofort löschen, nicht "für später aufheben". Gilt auch für .lnk-Shortcuts, Debug-Scripts, temp Configs.

## Einmal-Skripte nach Aufgabenabschluss löschen
Skripte die einen einmaligen Auftrag erfüllt haben (PDF generieren, Word erstellen, OAuth einrichten, Daten migrieren) werden nach Erledigung gelöscht — nicht aufgehoben.

**Why:** Chris' Einschätzung: ein analoger Folgeauftrag ist kein Problem neu zu schreiben. Die interessante Logik (Formatierung, Struktur) entsteht aus dem Kontext, nicht aus dem alten Script.

**How to apply:** Nach Abschluss eines einmaligen Auftrags das Script löschen. Nur behalten wenn es als echter Vorlage-Kandidat für regelmäßige Aufrufe dient (dann in Cron oder Dokumentation aufnehmen). Git-History ist das Archiv.
