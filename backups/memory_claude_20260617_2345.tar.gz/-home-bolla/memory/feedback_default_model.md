---
name: Default-Modell ist Sonnet, Opus auf Anfrage
description: Default in settings.json ist Sonnet 4.6; bei anspruchsvollen Aufgaben proaktiv Opus vorschlagen, Chris schaltet via /model
type: feedback
originSessionId: f1d60c97-2496-4780-9dfd-8b9a6a8d64c3
---
**Default-Modell:** Sonnet 4.6 (`claude-sonnet-4-6`), gesetzt in `/home/bolla/.claude/settings.json` → `"model"`.

**Opus-Wechsel:** Ich kann das Modell **nicht selbst zur Laufzeit wechseln** (kein Tool dafür) — `/model` ist ein interaktiver CLI-Command, den nur Chris auslösen kann.

**Meine Aufgabe:** Wenn ich bei einer anstehenden Aufgabe denke, dass Opus sie spürbar besser oder schneller löst (komplexe Refactorings, harte Debugging-Sessions, längere Architektur-Planung, kniffliges Reasoning), **proaktiv Bescheid sagen**: "Das wäre eher Opus-Stoff — willst du via `/model` umschalten?". Bei Standard-Kram (Tagesnotiz, Mails, kleine Bugfixes, Routine-Recherche) bleiben wir auf Sonnet.

**Why:** Chris will den Mehrwert von Opus bewusst dosieren (langsamer, teurer), aber nicht selbst entscheiden müssen wann es sich lohnt — das ist mein Job.

**How to apply:** Beim Lesen einer neuen Anfrage kurz einschätzen: Standard-Aufgabe → still Sonnet machen. Anspruchsvolle Aufgabe → einen Satz vorweg: "Vorschlag: kurz auf Opus wechseln (`/model`), das wird hier sauberer." Nach Abschluss der Opus-Phase erinnern: "Können wieder zurück auf Sonnet."
