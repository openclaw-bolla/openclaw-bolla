---
name: E-Auto & Ladekosten
description: Chris fährt VW ID.3 1st, Ladekosten-Präferenzen für Unterwegs
type: user
originSessionId: dfa8875a-0ac2-4b8c-bbe7-b04d2c559b7d
---
**Fahrzeug:** VW ID.3 1st

**Reichweite pro Ladung (realistisch + Puffer, für Reiseplanung):**
- **Sommer:** ~200 km pro Ladung
- **Winter:** ~160 km pro Ladung
- Danach jeweils **~30 Min laden**.
- **How to apply:** Bei Reisezeit-Schätzungen (MC-Reiseplaner) nach ca. dieser Strecke einen 30-Min-Ladestopp einplanen und in die Gesamtzeit einrechnen. Umgesetzt im Reiseplaner-Prompt in `mission_control_api.py` (`trip_plan`, Variable `ev_inst`), saison-abhängig über das Reisedatum.

**ECHTE Erfahrungswerte Langstrecke (wichtiger als Theorie!):**
- **Norderstedt ↔ Ulm (zu Robin), ~720 km:** Winter ~**10 h**, Sommer ~**9 h** (inkl. aller Ladestopps/Pausen). Effektiver Schnitt also ~72 km/h Winter / ~80 km/h Sommer.
- **How to apply:** Lange Strecken IMMER nach diesen realen Schnitten rechnen und **großzügig aufrunden** ("etwas Luft" lassen, Chris' Wunsch). Verbrenner-Fahrzeiten (z.B. „700 km = 6½ h") sind für den ID.3 zu optimistisch. Diese Werte sind seit 2026-06-07 auch in der Sommerreise-2026-Anreise (`SR_ROUTE[0]` in index.html) und im `trip_plan`-Prompt hinterlegt.

**Ladekosten-Priorität (günstigste zuerst):**
1. **EnBW** — 46 ct/kWh (mit Abstand bevorzugt)
2. **ARAL Pulse** — 55 ct/kWh (knapp dahinter, akzeptabel)
3. **Alle anderen** — min. 69 ct/kWh → nur im Notfall, zu teuer

**How to apply:** Bei Reiseplanung immer zuerst EnBW-Stationen suchen, dann ARAL Pulse. Andere Betreiber nur wenn keine Alternative vorhanden.
