---
name: Familie Mandel / Garschagen
description: Chris' gesamte Familie — Frau, Töchter, Schwiegersohn, Enkelkinder — mit Geburtstagen, E-Mails und Telefon
type: user
originSessionId: 080984ef-5d04-4952-965e-dd355c159d3f
---

## Herkunft
Alle Mandels und Ewalds (Chris' Umfeld) sind **Schwaben** — sparsam, kein unnötiges Geld ausgeben. Bei Kostenentscheidungen immer kostenlose Alternativen prüfen und ansprechen.
## Renate Mandel — Frau
- Geburtstag: 24.10.1965
- E-Mail: renatemandel@wtnet.de
- Mobil: 0160-99182840

## Stephanie Garschagen — Tochter (verheiratet mit Daniel)
- Geburtstag: 10.01.1987
- E-Mail: stephanie.garschagen@gmail.com
- Mobil: +49 176 61983818
- Kinder: Emma, Mia, Zwillinge Marie & Anton

## Daniel Garschagen — Schwiegersohn (Stephanies Mann, genannt "Dani")
- Geburtstag: 10.01.1967
- E-Mail: daniel.garschagen@web.de / daniel.garschagen@googlemail.com

## Ann-Kristin Mandel — Tochter (wird "Anne" gerufen)
- Geburtstag: 15.03.1991
- E-Mail: anne15.03@hotmail.de
- Mobil: +49 176 70778562
- Freund: Benedikt (genannt "Bene") — keine weiteren Daten bekannt

## Enkelkinder (Stephanie & Daniel)

| Name | Geburtstag | Besonderheit |
|------|-----------|--------------|
| Emma Garschagen | 20.03.2018 | |
| Mia Garschagen | 22.12.2021 | |
| Marie Garschagen | 21.02.2025 | Zwilling |
| Anton Garschagen | 21.02.2025 | Zwilling |
