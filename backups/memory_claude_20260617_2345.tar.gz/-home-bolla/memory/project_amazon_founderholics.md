---
name: project_amazon_founderholics
description: Amazon-Rückgabestreit Founderholics (Kieselerde) — ERLEDIGT 13.06.2026, vollständiger Verlauf als Beleg
metadata:
  type: project
  originSessionId: current
---

# Amazon-Rückgabe: Nature Basics Kieselerde Kapseln

## Kerndaten
- **Bestellung:** #306-6616120-2543506
- **Produkt:** Nature Basics Kieselerde Kapseln, 120 Stück
- **Preis:** 24,90 €
- **Händler:** Founderholics (friends@founderholics.com)
- **Lieferung:** 08.06.2026
- **Widerruf erklärt:** 10.06.2026 (fristgerecht, Artikel originalverpackt/ungeöffnet)

## Zeitlinie

| Datum | Aktion |
|---|---|
| 08.06. | Lieferung |
| 10.06. | Widerruf per Mail an Founderholics erklärt, Rücksendelabel angefragt |
| 10.06. | Amazon-Portal für Rücksendung versucht → **läuft in Loop**, funktioniert nicht |
| 10.06. | Auf Bollas Rat: SEPA-Lastschrift zurückgezogen → **24,90 € zurück auf Konto** ✓ |
| 11.06. | Founderholics antwortet: Rücknahme akzeptiert, aber kein Label — „Vertrag sei mit Amazon" (rechtlich falsch) |
| 12.06. | Amazon/Riverty schickt Zahlungserinnerung: 24,90 € + 3 € Rücklastschriftgebühr = **27,90 €**, Frist 26.06.2026, Referenz 72458498987062, IBAN DE87300308801908262006 (HSBC), VWZ: 72458498987062, Kontakt: lastschriftservice@riverty.de |
| 12.06. | **Bolla versendet zwei Mails:** |
| | → Riverty: Widerruf-Info, Zahlungsaussetzung erbeten, 3 € zurückgewiesen |
| | → Founderholics: Label oder Rücksendeadresse + Kostenübernahme bis **19.06.** gefordert |
| 13.06. | Riverty antwortet (Sachbearb. Mieko Herrmann): **Abschiebeantwort** — „wenden Sie sich an Amazon Kundenservice" — kein inhaltliches Eingehen |

## Rechtliche Lage
- Widerruf fristgerecht (Lieferung 08.06., Widerruf 10.06. = 2 Tage)
- Founderholics-Behauptung „Vertrag mit Amazon" ist **falsch** — bei Marketplace ist Vertragspartner der Händler
- Rücksendekosten trägt der Händler, sofern er den Käufer nicht ausdrücklich in der Widerrufsbelehrung darauf hingewiesen hat
- Amazon-Zahlungserinnerung enthält selbst den Hinweis: *„Wenn du die Artikel zurückgeschickt hast, kannst du diese Nachricht ignorieren"*

## Abschluss (13.06.2026)
Amazon-Chat mit Mitarbeiterin Alina:
- Rücksendung ist **nicht erforderlich**
- 3 € Rücklastschriftgebühr wird in 3–5 Tagen storniert
- 24,90 € bereits zurückerstattet
- Screenshot archiviert: OneDrive/Dokumente/Bolla/Amazon_Founderholics_Chat_Abschluss_2026-06-13.png

## Status
✅ ERLEDIGT — kein weiterer Handlungsbedarf
