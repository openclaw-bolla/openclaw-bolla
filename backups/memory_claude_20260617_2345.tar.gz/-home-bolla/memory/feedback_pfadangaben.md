---
name: Exakte Pfadangaben in Anleitungen
description: Chris möchte immer den vollständigen Klickpfad — nie nur das Ziel nennen
type: feedback
originSessionId: 080984ef-5d04-4952-965e-dd355c159d3f
---
Bei Anleitungen (Azure Portal, Google Cloud, Windows-Einstellungen etc.) immer den vollständigen Navigationspfad angeben, nicht nur das Ziel.

**Why:** Chris hat explizit darum gebeten — hilft ihm sich nicht zu verirren.

**How to apply:** Format: "Startseite → Abschnitt → Unterseite → Element → Aktion". Zum Beispiel: "portal.azure.com → App-Registrierungen → Bolla Mail → Verwalten → Authentifizierung → Erweiterte Einstellungen → Öffentliche Clientflows zulassen → Ja → Speichern"
