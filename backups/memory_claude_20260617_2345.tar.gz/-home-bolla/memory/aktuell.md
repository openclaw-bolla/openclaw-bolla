---
name: aktuell
description: Aktueller Arbeitsstand — was zuletzt gemacht wurde und was als nächstes ansteht
metadata: 
  node_type: memory
  type: project
  originSessionId: current
---

# Aktueller Stand — 2026-06-17

> **Rollende Momentaufnahme — bewusst schlank halten.**

## ✅ BUILD-SKRIPTE ENT-HARTKODIERT (17.06. ~16:35) — GRUNDSATZ GELÖST
Beide Skripte (`aurora_epub_gen.py` DE + `aurora_epub_en.py` EN) komplett umgebaut: KEIN Buchtext mehr hartkodiert (nur noch CSS = Styling). Alle Inhalte (epilog, epilog_untertitel, vorspann, impressum, vorwort, ueber_autor, danksagung, rezensions_bitte) kommen jetzt aus der JSON. Fehlt ein Pflichtfeld → Build bricht mit `SystemExit` ab (kein stiller Fallback). Per Text-Diff bewiesen: Output vor/nach Umbau inhaltlich IDENTISCH. Backups: `*.py.bak_vor_dehardcode_*`, `ki_buch*_backup_vor_dehardcode_*`.
- **AURORA-Ordner aufgeräumt:** nur noch `AURORA_deutsch.epub` + `AURORA_english.epub` (beide final, verifiziert sauber). 6 alte/Proof-EPUBs gelöscht.
- **Prozess-Doku:** `workspace/docs/BUCHPROJEKT_EPUB_PROZESS.md` (+ Kopie in OneDrive/AURORA) — Playbook fürs nächste Buch.
- **Beide finalen Bücher an Kindle gesendet** (ohne Proof-Stempel). Chris klickt Amazon-Verifikation.
## ⏸️ D2D — STAND 17.06. ABENDS (HIER MORGEN WEITER)
**Konto voll aktiv & fertig eingerichtet:**
- 20-USD-Aktivierungsgebühr (NEU seit 14.05.2026) bezahlt ✅
- Bank (Auszahlung): Direct Deposit International, EUR, Deutsche Bank, IBAN+BIC eingetragen ✅
  - ⚠️ „Account holder name" steht auf „Chris Mandel" — sollte „Christoph Mandel" sein (wie Bank/Finanzamt). Vor erster Auszahlung anpassen. [[facts-steuername]]
- W-8BEN/Steuer-Interview komplett ✅. Status „VALIDATION PENDING", Withholding zeigt noch 30 % → wird nach Validierung automatisch 0 % (DE-US, Royalty-Copyright). Falls in paar Tagen noch 30 % → prüfen.

**NÄCHSTER SCHRITT MORGEN:** Auf „My Books" → **ADD NEW BOOK** klicken → DE-Buch hochladen:
1. Titel `AURORA`, Untertitel `Was bleibt, wenn die Maschinen träumen`, Autor `Chris Mandel`, Sprache German
2. Manuskript: `D:\OneDrive\Dokumente\AURORA\AURORA_deutsch.epub`
3. Cover: `cover_kdp.png` (oder cover_v6_portrait.png)
4. Gratis D2D-ISBN nehmen
5. Klappentext + Kategorien (FICTION/Thrillers/Technological) + Keywords → alles in `D:\OneDrive\Dokumente\AURORA\AURORA_D2D_Materialien.md`
6. Preis 4,99 €
7. **Amazon ABWÄHLEN** (läuft über KDP)
8. Review & Publish → dann EN-Buch analog (`AURORA_english.epub`, $4.99)
- Steuerlicher Name Chris = **Christoph Mandel** (Finanzamt+Bank), Steuer-ID endet auf 2930. [[facts-steuername]]

## 🐛 EN-VORSPANN-BUG GEFIXT (17.06. ~16:25) — WICHTIG
Chris vermisste die englische Aurora-*Definition* (Lexikon-Stil wie DE, US-adaptiert). Ursache: `vorspann_xhtml()` in `aurora_epub_en.py` warf den JSON-Vorspann weg (`text = VORSPANN_EN.strip()`) und nutzte eine alte "princess who sleeps"-Konstante. Fix: liest jetzt JSON. Verlorene Definition aus Transkript `f61ff412-…jsonl` wiederhergestellt → ins `vorspann`-Feld von `ki_buch_en_adapted.json` geschrieben ("aurora · noun, feminine · Latin: the dawn … She is the moment when you sense that it is ending."). EPUB neu gebaut + verifiziert. Backup JSON: `ki_buch_en_adapted_backup_vor_vorspannfix_*`. Details: [[project-aurora-hardcoded-blocks]].
- Neue EN-Korrekturkopie an Kindle gesendet: "AURORA — Proof 17.06.2026 (EN, Epilog+Vorspann-fix)".

## 🐛 EN-EPILOG-BUG GEFUNDEN & GEFIXT (17.06. 16:08) — WICHTIG
Chris' Verdacht stimmte: englische EPUB war NICHT final. Der Kultur-Fix (16.06.) lief nur über die JSON-Kapitel — **der Epilog ist aber in `scripts/aurora_epub_en.py` HARTKODIERT** (`EPILOG_BODY`, Z.49–122) und blieb deutsch: "Marlie Braun" + "Theo had stayed in Lübeck".
- Fix im Skript: Marlie→Marley, Braun→Brown, Lübeck→Providence. Backup: `aurora_epub_en.py.bak_vor_epilogfix_*`.
- EN-EPUB neu gebaut + verifiziert: 0 deutsche Reste (Hamburg nur noch in Autoren-Bio = korrekt). Alt gesichert: `AURORA_english_backup_vor_epilogfix_*.epub`.
- **DE-EPUB ist korrekt** (aus finaler `ki_buch.json`, nach beiden Opus-Wellen).
- ⚠️ LEHRE: Bei AURORA-Änderungen IMMER auch hartkodierte Blöcke in BEIDEN Build-Skripten prüfen (`EPILOG_BODY`, `ABOUT_THE_AUTHOR`). Siehe [[project-aurora-epilog-hardcoded]].

## 📖 KINDLE-KORREKTURKOPIEN (17.06. 16:08)
Problem gelöst: Kindle zeigte mehrfach nur "AURORA" → Chaos. Lösung = separate PROOF-EPUBs mit Versionskennung (Verkaufs-EPUBs bleiben sauber/ohne Stempel):
- `AURORA_deutsch_PROOF.epub` → Bibliothekstitel "AURORA — Korrektur 17.06.2026 (DE)"
- `AURORA_english_PROOF.epub` → "AURORA — Proof 17.06.2026 (EN, Epilog-fix)"
- Beide: fette Stand-Zeile oben im Impressum. An `ernstmandel_MnAuOy@kindle.com` gesendet (Chris klickt Amazon-Verifikation).
- TODO Chris: ALLE alten "AURORA"-Einträge am Kindle löschen, nur die zwei 16:08-Versionen behalten.

## 🚀 AURORA KDP-VERÖFFENTLICHUNG (17.06. ab 18:00) — LIVE

**DEUTSCH — aktueller Stand (vor /clear):**
- Details-Tab: ✅ komplett (Titel, Klappentext, Keywords, 3 Kategorien)
- Content-Tab: ✅ EPUB + Cover hochgeladen, Rechtschreibprüfung ✅, Vorschau OK
- Pricing-Tab (AKTIV): 
  - Muss noch **Details-Tab zurück** → Primary Marketplace auf **Amazon.de** ändern
  - Dann zurück zu Pricing → Preis **4,99 €**, Royalty 70%, KDP Select ❌
  - **"Publish Your Kindle eBook"** klicken → fertig Deutsch

**ENGLISH — noch nicht gestartet:**
- EPUB: `AURORA_english.epub` bereit
- Cover: `cover_kdp.jpg` bereit
- Metadaten auf Desktop: `AURORA_KDP_BEIDE_BUECHER.md` (Keywords, Klappentext EN, etc.)
- **Nach Deutsch publish:** Gleicher Flow wiederholen (Details → Content → Pricing → Publish)

**Nächster Schritt NACH /clear:** Details-Tab für Deutsch aufsuchen, Marketplace auf Amazon.de stellen, zurück zu Pricing → 4,99€ + Publish.

**Lessons learned:** KDP JPG/TIFF nur (kein PNG) — Cover konvertiert ✅. Rechtschreibprüfung ist falsch-positiv-überempfindlich (Eigennamen).

---

## 🔄 CLAUDE-CODE VERSIONS-WÄCHTER (17.06.) — NEU
Chris ließ Claude Code 7 Tage ohne Neustart laufen → bereitliegendes Update (2.1.170) nie aktiv.
Zwei Wächter gebaut, damit das nicht mehr passiert:
1. **Statusline** (`~/.claude/statusline.sh` + `settings.json`): zeigt laufende Version + gelben Hinweis „⟳ Neustart → vX bereit", wenn Symlink-Ziel ≠ laufende Version.
2. **mp-Dashboard**: neuer Endpunkt `/api/claudeversion` (in `mission_control_api.py`, Funktion `get_claude_version`) vergleicht Prozess-Startzeit vs. mtime der neuesten installierten Version. Badge `cc-restart-badge` auf der 🤖-Claude-Code-Seite (`index.html`, `loadClaudeCode()`): orange „Neustart bereit" / grün „aktuell · läuft seit Xd".
- mp-Server neu gestartet (PID wechselt), Endpunkt getestet: `needs_restart:true, v2.1.170, 7d 3h`. ✅
3. **mp Auto-Refresh** (`index.html`): Banner zusätzlich aufs **Dashboard** gelegt (`dash-restart-banner`, nur sichtbar wenn Neustart nötig). Neuer `visibilitychange`+`focus`-Handler `refreshOnReturn()` lädt beim Zurückkehren zur mp die aktive Seite sofort neu (+ Tageswechsel-Check für Foto/Rezept/Geburtstage/Greeting). Löst „morgens Stand von gestern" durch eingefrorene Tabs. Bewusst KEIN Dauerpollen aller Seiten (teure Endpunkte).
4. **BUGFIX 17.06.:** `get_claude_version()` erkannte laufenden Prozess nicht (`pgrep -f "/home/bolla/.local/bin/claude"` matchte nie, da argv nur `claude`). Neu: `pgrep -x claude` + laufende Version direkt aus `/proc/<pid>/exe`-Symlink (zeigt auf `.../versions/X`), direkter Vergleich running_version≠available_version statt mtime/etime-Raterei. Neues Feld `running_version` im JSON. Frontend (`index.html` Banner + Badge) zeigt jetzt „v2.1.170 → Neustart für v2.1.179". Server neu gestartet, getestet ✅ (running:true, needs_restart:true).
- **✅ GESICHERT 17.06.:** Commit `42f861a` + Push nach GitHub (origin master), OneDrive-Backup durchgelaufen.
- **✅ BACKUP-ROUTINE 17.06.:** `cp -a` → `rsync -a` (ohne --delete) in CLAUDE.md. **Wichtigste Erkenntnis:** rsync bringt KEINEN Speedup (~4 Min, gemessen) — Flaschenhals ist `stat` von ~4661 Dateien über 9p-Mount (~55ms/Datei), nicht das Kopieren. Chris: bewusst „so lassen" (läuft im Hintergrund am Session-Ende, stört nicht). Echter Speedup nur via tar-Archiv möglich (verworfen: kein browsebarer Spiegel). **`--delete` ist TABU** (NTFS case-insensitiv vs Linux case-sensitiv: `-mnt-c-WINDOWS-System32`+`system32` kollidieren → --delete wollte 2413 Dateien löschen, inkl. memory/+MEMORY.md). Alles in CLAUDE.md Punkt 4 dokumentiert.
- **✅ GEPRÜFT 17.06.:** `/api/recipe` & `/api/photo` generieren serverseitig korrekt täglich neu — `date.today()` wird pro Request frisch gezogen (`simple[path]()` Z.5215), kein In-Memory-Cache friert ein. Recipe-Cache lückenlos `recipe_2026-06-10..17`, heutiges existiert. Client-Refresh (`refreshOnReturn`) reicht aus. KEIN Bug. (Optional offen: Cron-Vorwärmung 06:00 gegen 60s-Wartezeit beim ersten Recipe-Aufruf.)

## 📖 AURORA ENGLISCH — KULTUR-CHECK LÄUFT (16.06.)

Datei: `/home/bolla/workspace/data/ki_buch_en_adapted.json` (47 Kap.)
Backup: `workspace/backups/ki_buch_en_adapted_PRE-CULTURAL-FIX_2026-06-16.json`
Kapitel als Einzeltexte: `/tmp/aurora_en_chapters/00.txt ... 46.txt`

### ✅ ERLEDIGT — mechanische Fixes (per Script, alle verifiziert 0 Reste)
- Marlie → Marley (141×), Braun → Brown (12×) — Namens-Inkonsistenz Hauptfigur
- "Four thousand two hundred square meters" → "Forty-five thousand square feet" (Kap0, matcht Kap5)
- "Greenbridge Street 14" → "14 Greenbridge Street" (US-Adressformat)
- "three meters" → "ten feet" (Kap42)
- "Papa?" → "Daddy?" (2×, Kap25 — Motiv der toten Tochter, vereinheitlicht mit Kap24)
- "Ms. Hoffmann" → "Ms. Yilmaz" (Kap29, Ellies Nachname konsistent)
- "Germany" ergänzt in "Über den Autor" (`scripts/aurora_epub_en.py`)

### ✅ ERLEDIGT — Autoren-Entscheidungen (Chris gewählt, umgesetzt, verifiziert 0 Reste)
1. **Geografie:** HQ → **Kendall Square, Cambridge** (war 50/50 Split mit Seaport); 2. Labor/Node/Grab → **Providence RI** (~50 mi südlich, I-95/Route 1 S; Gloucester+North Shore raus); Distanz K40 100→50 mi
2. **Nachbar-Ehepaar:** bleibt deutschstämmig **Günter & Hanni Brandt**, Beruf Telefongesellschaft, wohnt in Allston (Walter/Walt Brennan/post office bereinigt)
3. **Behörden:** "notary" → **court-appointed receiver** (Kap18/19/22/23/24); FBI → **police** im Zivilstreit (Kap24/26); Whistleblower-FBI Kap18 bleibt
4. **Vornamen:** Konrad→Conrad (9×), Anselm→Aaron Kern (8×). Dreyer bleibt.
5. **Marleys Wohnung** → durchgängig **Allston** (South End/Jamaica Plain/Beacon Hill/Seaport bereinigt; Ellie+Theo bleiben legit in Beacon Hill)
6. Mechanisch: Marlie→Marley(141×), Braun→Brown(12×), m²→sq ft, Papa→Daddy, Ms.Hoffmann→Yilmaz, Adressformat

### ✅ EPUB neu gebaut: `D:\OneDrive\Dokumente\AURORA\AURORA_english.epub` (3109 KB, 47 Kap.)

7. **Temperatur Kap34/35** ✅ — °C-Werte → plausibles °F: 84→183, 89→192, 92→198(sector-loss), 95→203(Klimax); Halten 190-191, Abkühlen 187. Dezimal-Drama erhalten. "eighty-six words" (Wortzahl!) NICHT angefasst.

### ✅ KOMPLETT FERTIG — EPUB neu gebaut: `D:\OneDrive\Dokumente\AURORA\AURORA_english.epub` (3109 KB)

### Hinweis
- "four letters, lowercase" (Kap31/32) = bewusstes Plot-Geheimnis (tote Tochter Aurora Santos), KEIN Fehler — nicht angefasst

## 🔧 Modell
- Default jetzt **Opus 4.8** bis Max-Plan-Ende (settings.json + [[feedback_modell_auswahl]])

## Dateipfade
- Buch EN adapted: `workspace/data/ki_buch_en_adapted.json`
- EPUB-Script EN: `scripts/aurora_epub_en.py`
- Cover v6: `D:\OneDrive\Dokumente\AURORA\cover_v6.png`
