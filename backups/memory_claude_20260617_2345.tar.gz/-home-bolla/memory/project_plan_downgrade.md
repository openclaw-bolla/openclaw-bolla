---
name: Plan-Downgrade Max → Pro
description: Chris wechselt am 10.05.2026 von Max- auf Pro-Plan; Verhalten entsprechend anpassen
type: project
originSessionId: 643bdaeb-3ed3-4610-a5dd-1f269e984b75
---
Chris hat den Downgrade von **Claude Max** auf **Claude Pro** initiiert. Wirksam ab **10.05.2026** (Ende der laufenden Max-Periode, gebucht am 10.04.2026).

**Why:** Sein Verbrauch (geprüft am 16.04.: 12% pro 5h-Fenster auf Max) ist überschaubar. Er testet bewusst, ob Sonnet-Default + selektiver Opus-Einsatz für sein Nutzungsprofil reicht. Spart ~80 €/Monat.

**How to apply:**
- Default-Modell bereits auf Sonnet umgestellt (`~/.claude/settings.json`)
- Opus nur bei komplexen Aufgaben vorschlagen (siehe `feedback_model_choice.md`)
- Wenn Chris ab 10.05. ans Pro-Limit stößt: Anbieten auf Sonnet zu wechseln (`/model sonnet`) statt automatisch upzugraden
- Wenn ich merke, dass Pro regelmäßig zu eng wird, Chris drauf hinweisen — er kann jederzeit wieder auf Max upgraden

**Status der Mission-Control-Anzeige:**
- System Info → Bolla-Box zeigt 7-Tage-Historie halbtageweise (VM/NM)
- Nutzt Chris zum Selbstbeobachten ob Pro reicht
