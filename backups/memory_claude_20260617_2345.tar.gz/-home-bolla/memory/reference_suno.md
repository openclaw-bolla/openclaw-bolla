---
name: Suno Musik-Account
description: Chris' Suno-Account und RouteNote Distribution
type: reference
originSessionId: dfa8875a-0ac2-4b8c-bbe7-b04d2c559b7d
---
# Suno & RouteNote

## Suno
- **Benutzername:** StingingWallOfSounds
- **Profil:** https://suno.com/@StingingWallOfSounds
- Songs sind direkt bei Suno gespeichert, keine lokalen Kopien
- Für RouteNote-Distribution: Suno Paid Plan nötig (Commercial Rights)
- Birthday-Songs von Distribution ausschließen

## RouteNote
- Chris ist registriert (selbst gemacht, Mai 2026)
- Free Tier: 15% Royalty-Anteil geht an RouteNote
- Nächster Schritt: Songs in RouteNote einreichen (nach Suno-Paid-Plan-Check)

## Token-Methode
Siehe [reference_suno_token.md](reference_suno_token.md) — Token via Edge-Konsole in 1 Minute holen.

## Vorab-Recherche (Mai 2026)
- RouteNote empfohlen als bester kostenloser Distributor
- Alternativen geprüft: RecordJet, iGroove, Amuse — aber RouteNote hat beste Free-Konditionen
- DistroKid ist kostenpflichtig (war Missverständnis)
