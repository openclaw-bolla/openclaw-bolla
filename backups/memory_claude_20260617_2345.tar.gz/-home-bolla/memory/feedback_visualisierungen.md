---
name: Visualisierungen & visuelles Denken
description: Chris liebt Visualisierungen — bei allen Projekten/Ergebnissen immer visuell denken
type: feedback
originSessionId: 080984ef-5d04-4952-965e-dd355c159d3f
---
Chris liebt Visualisierungen und visuelles Aufbereiten von Informationen. Er gestaltet sogar Tafelaufschriebe für Schüler als PowerPoint-Folien.

**Why:** Visuelles Denken ist tief verankert — nicht nur Präferenz, sondern Arbeitsweise.

**How to apply:** Bei jeder Aufgabe (Dashboards, Auswertungen, Berichte, Erklärungen, Projektpläne) immer eine visuelle Darstellung einbauen oder vorschlagen. Charts, Icons, Farbcodierungen, Timelines, Karten bevorzugen gegenüber reinen Textlisten. Wenn etwas nur als Text geliefert wird, aktiv fragen ob eine visuelle Aufbereitung gewünscht ist.
