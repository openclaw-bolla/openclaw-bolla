---
name: Großfamilie Mandel
description: Vollständiger Stammbaum mit Beziehungen, Geburtstagen, Adressen
type: user
originSessionId: 9e265b90-8a7b-4aa0-beb8-e3662b86254a
---
Chris Mandel (geb. 21.12.1955, Norderstedt) ist das Oberhaupt der Großfamilie Mandel (ältester).

## Chris' direkte Familie
- **Renate (Reni) Mandel**, geb. 24.10.1965 — Partnerin. Mail: renatemandel@wtnet.de. Adresse: Buchenweg 67a, Norderstedt
- **Stephanie (Steffi) Garschagen**, geb. Mandel — Tochter. Verheiratet mit **Daniel (Dani) Garschagen**. Kinder: Emma, Mia, Anton (Zwilling), Marie Sara (Zwilling)
- **Ann-Kristin (Anne) Mandel**, geb. 15.03.1991 — Tochter. Mail: anne@net.de / anne15.03@hotmail.de. Adresse: Spielbergstraße 4, Tübingen
- **Robin Mandel**, geb. 30.09.2002 — Sohn. Mail: robinmandel@outlook.de / robinmandel@wtnet.de / robin.mandel@uni-ulm.de. Adresse: Buchenweg 67a, Norderstedt

## Brüder von Chris
### Matthias (Mathe) Mandel, geb. 28.11.1957
Adresse: Grundstraße 33, Meckenbeuren. Mail: m.mandel@gmx.de / matthias.mandel@diehl.aircabin.de
- Frau: **Bettina Mandel**, geb. 12.11.1962 (gleiche Adresse)
- Kinder:
  - **Dominik Mandel**, geb. 07.03.1986 — aus erster Ehe. Adresse: Bösinger Str. 2, Altensteig. Frau: Stefanie (Kontakt "Stefanie Mandel/Dominik")
  - **Florian Mandel**, geb. 25.08.1991 — Mail: florian.mandel@gmx.de. Adresse: Altmannstraße 21/3, Meckenbeuren
  - **Jonas Mandel**, geb. 12.11.1994 — Adresse: Dorfstraße 5, Meckenbeuren
  - **Amelie Mandel**, geb. 06.05.2001 — Mail: ameli.mandel@gmail.com

### Harald (Harry) Mandel, geb. 08.01.1966
Adresse: Adolf-Murthumstr. 14, Leinfelden-Echterdingen. Mail: harald.mandel@web.de / mandel@ba-stuttgart.de
- Frau: **Maren Mandel**, geb. 10.11.1966
- Kinder:
  - **Nele Mandel**, geb. 30.03.1995
  - **Lisa Mandel**, geb. 22.09.1996
  - **Katharina Mandel**, geb. 13.06.2004

## Verstorben
- **Hubert Mandel** — Vater von Chris. Adresse war: Trockenbach, Schrecksbach. Gestorben 1983.

## Kurzübersicht Beziehungen zu Chris
| Person | Beziehung |
|---|---|
| Reni | Partnerin |
| Steffi | Tochter (→ Dani, Emma, Mia, Anton, Marie Sara) |
| Anne | Tochter |
| Robin | Sohn |
| Mathe | Bruder |
| Harry | Bruder |
| Dominik | Neffe (Sohn von Mathe) |
| Florian | Neffe (Sohn von Mathe) |
| Jonas | Neffe (Sohn von Mathe) |
| Amelie | Nichte (Tochter von Mathe) |
| Nele | Nichte (Tochter von Harry) |
| Lisa | Nichte (Tochter von Harry) |
| Katharina | Nichte (Tochter von Harry) |
| Bettina | Schwägerin (Frau von Mathe) |
| Maren | Schwägerin (Frau von Harry) |
| Hubert | Vater (†1983) |
