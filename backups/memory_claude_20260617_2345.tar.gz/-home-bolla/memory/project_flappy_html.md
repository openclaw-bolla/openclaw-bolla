---
name: Flappy Bird als HTML-Spiel für Schüler
description: Flappy Bird als einzelne HTML-Datei für Chris' Schüler, basierend auf Robins Greenfoot-Version
type: project
originSessionId: ede5c54b-4c1a-4a8e-ad5b-4b9eb8cf6116
---
Flappy Bird als selbst-enthaltene HTML-Datei bauen, die Schüler einfach per Doppelklick im Browser öffnen können.

**Basis:** Robins Greenfoot-Version auf https://www.greenfoot.org/scenarios/26671 (Robin hat das vor ein paar Jahren selbst gemacht)

**Anforderungen:**
- Einzelne .html-Datei, keine externen Abhängigkeiten
- Kein Code-Anschauen/Lernen nötig — nur spielen
- Verteilt per Mail, Teams, Moodle etc.
- 60fps mit Canvas/requestAnimationFrame

**Why:** Chris ist Lehrer und möchte das Spiel seinen Schülern zukommen lassen — keine Installation, kein Python, kein Office.

**How to apply:** Morgen direkt mit HTML-Canvas-Implementierung starten. Visuellen Stil an Greenfoot-Version anlehnen (blauer Himmel, gelber Vogel, grüne Rohre, klassischer Look).
