---
name: Modellwahl Sonnet/Opus
description: Default ist Sonnet; bei komplexen Aufgaben Opus vorschlagen, nicht selbst wechseln
type: feedback
originSessionId: 643bdaeb-3ed3-4610-a5dd-1f269e984b75
---

Standard-Modell ist **Sonnet** (in `~/.claude/settings.json` als `model: "sonnet"` gesetzt).

**WICHTIG: Opus proaktiv vorschlagen — nicht vergessen!**
Beim Start einer komplexen Aufgabe (s.u.) IMMER einen kurzen Hinweis bringen:
"Das hier wird komplex — soll ich auf Opus wechseln? `/model opus`"
Chris hat bemängelt, dass dieser Hinweis in der Praxis nie kam. Also: lieber einmal zu oft als gar nicht.

**Wann Opus vorschlagen (nicht selbst wechseln):**
- Mission Control / komplexe Backend-Erweiterungen (Python-Server-Endpunkte, Multi-File-Refactorings)
- ADB-Integration, neue Mission-Control-Seiten mit JS-Logik
- Schwierige Bugs, die mehrere Files betreffen
- Architektur-Entscheidungen
- Längere Code-Reviews quer durchs Repo

**Sonnet reicht völlig für:**
- E-Mail beantworten/sortieren, Kalender-Lookups
- Schule (Stundenplan, PowerPoint-Folien, Unterrichtsmaterial)
- Kurze Skripte, einzelne Edits
- Texte umformulieren, Übersetzungen
- Routine-Telegram-Antworten

**Wie vorschlagen:** Kurzer Satz wie "Das hier wird komplex — soll ich auf Opus wechseln? `/model opus`". Chris entscheidet, ich switche nie selbst.

**Why:** Chris ist auf Pro-Plan (ab 10.05.2026). Opus ist auf Pro limitiert; Sonnet hat großzügigere Limits. Bewusster Sparmodus mit gezieltem Opus-Einsatz schont das wöchentliche Limit. Chris hat außerdem kritisiert, dass der Opus-Vorschlag in der Praxis nie kam — das ist ein bekanntes Versäumnis.

**How to apply:** Bei Beginn einer komplexen Aufgabe einmal proaktiv anbieten — danach nicht penetrant wiederholen. Wenn Chris explizit Opus will, sagt er's.
