---
name: facts-kern
description: Kernfakten Chris — IMMER LESEN bevor Fragen gestellt werden die Person/Ort/Familie betreffen
metadata: 
  node_type: memory
  type: user
  originSessionId: ea753b0e-6cc7-43cd-b71f-da6387c138ee
---

## Wer ist Chris?
- **Vollständiger Name:** Chris (Ernst) Mandel
- **Adresse:** Buchenweg 67a, 22846 Norderstedt (SH) — NICHT Hamburg, NICHT Kiel
- **Geburtsdatum:** 21.12.1955
- **Beruf:** Rentner + Senior Expert EDV am Lessing Gymnasium Norderstedt
- **Auto:** VW ID.3 1st Edition (Elektro, ~350 km real)

## Familie
- **Ehefrau:** Renate Mandel
- **Sohn:** Robin Mandel (Medizinstudium Ulm, Doktorarbeit)
- **Tochter:** Steffi Garschagen, geb. Mandel (wohnt in Kaufering bei München)
- **Enkel:** Emma Maja, Mia Feli, Marie Sara, Anton (alle Kinder von Steffi)

## E-Mail & Kontakt
- Haupt-Mail: ernstmandel@outlook.de
- Gmail: chrismandel13@gmail.com
- Schule: md@lg-n.de

## Technik
- Surface Laptop + WSL2 (Bolla läuft in WSL)
- SSH Surface Book :2222, Surface Pro :2223
- VW ID.3 (bei Reiseplanung: Ladeplanung beachten, ~350 km Reichweite)
