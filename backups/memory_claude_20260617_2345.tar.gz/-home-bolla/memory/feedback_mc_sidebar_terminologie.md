---
name: Mission Control Sidebar — Terminologie
description: Gemeinsame Begriffe für MC-Sidebar-Elemente
type: feedback
originSessionId: 9e265b90-8a7b-4aa0-beb8-e3662b86254a
---
Sektionen = aufklappbare Hauptbereiche (ARBEIT, KI, FAMILIE, INFO, ÜBERSICHT)
Gruppen = aufklappbare Untergruppen innerhalb einer Sektion (z.B. Schule-Gruppe, Projekte-Gruppe)
Einträge = einzelne klickbare Punkte (Kalender, E-Mail, etc.)
Subitems = Einträge innerhalb einer Gruppe (eingerückt)

**Why:** Einheitliche Sprache damit Chris und Bolla beim Beschreiben von MC-Änderungen klar kommunizieren.

**How to apply:** Diese Begriffe bei allen MC-Sidebar-Änderungen verwenden.
