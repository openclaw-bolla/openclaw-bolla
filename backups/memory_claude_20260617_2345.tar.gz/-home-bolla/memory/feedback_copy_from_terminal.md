---
name: Code aus Terminal kopieren
description: Chris kann Code nicht aus dem Terminal kopieren — immer clip.exe nutzen
type: feedback
originSessionId: dfa8875a-0ac2-4b8c-bbe7-b04d2c559b7d
---
Chris arbeitet im Terminal und kann Code nicht einfach aus der Ausgabe kopieren.

**Why:** Terminal-Selektion ist in WSL/Claude Code unpraktisch, besonders bei längeren Code-Blöcken.

**How to apply:** Wenn Chris Code braucht um ihn irgendwo einzufügen (Browser-Konsole, Notepad, etc.) → immer direkt mit `clip.exe` in die Windows-Zwischenablage kopieren, dann kann er einfach Strg+V nutzen.
