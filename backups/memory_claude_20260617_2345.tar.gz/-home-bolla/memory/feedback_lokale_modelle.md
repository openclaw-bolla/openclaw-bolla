---
name: Lokale LLMs sind für Chris Lernobjekt, nicht Werkzeug
description: Keine produktiven Use Cases für lokale Modelle pushen — Chris nimmt Claude/Copilot für echte Arbeit
type: feedback
originSessionId: f1d60c97-2496-4780-9dfd-8b9a6a8d64c3
---
Chris interessiert sich für lokale Modelle (LM Studio, phi, gemma usw.) ausschließlich zum Verstehen/Experimentieren — nicht um sie produktiv einzusetzen. Für echte Arbeit nutzt er Claude und Copilot, weil die "wesentlich besser" sind.

**Why:** Chris hat kein starkes Privacy-Bedürfnis, das lokale Modelle rechtfertigen würde. Cloud-Tools liefern einfach bessere Qualität. Er hat das beim Thema Phi-4/LM Studio klar gesagt: meine Vorschläge (E-Mail-Triage, Spam-Watcher-Erweiterung, PDF-Bulk-Zusammenfasser mit lokalem LLM) hat er abgelehnt mit "brauch ich nicht, geht in Copilot oder Claude wesentlich besser".

**How to apply:** Wenn Chris Fragen zu lokalen Modellen stellt, erkläre technisch sauber (wie's funktioniert, Setup, Parameter), aber hänge KEINE "das könntest du produktiv nutzen"-Vorschläge dran. Ausnahme: Wenn er selbst explizit nach Use Cases fragt. Die bestehende Mission-Control-Integration mit phi ist okay — die gab's schon, die verteidigen wir nicht neu.
