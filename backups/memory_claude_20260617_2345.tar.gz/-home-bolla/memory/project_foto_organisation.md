---
name: OneDrive Foto-Organisation
description: Wie Fotos von den Handys in OneDrive landen und wo aufgeräumt werden soll
type: project
originSessionId: 27bdbc7b-4e9a-4642-a895-df7c4ce6dd2e
---
## Foto-Eingang: alles landet in einem Ordner

Beide Huawei-Handys (Duo + P20) haben in der **OneDrive-App** folgendes eingestellt:
- Zielordner: **`OneDrive/Bilder/Eigene Aufnahmen/`**
- Geräteordner aktiv: Camera, Screenshots, BeReal, DCIM

**Ergebnis:** Alle Fotos, Screenshots, WhatsApp-Bilder und Videos landen automatisch in `Eigene Aufnahmen` — an einem einzigen Ort.

## Was NICHT gebraucht wird
- `Bilder/Kameraimporte/` → überflüssig, nur 3 einmalige USB-Import-Sessions (Okt/Nov 2025, Jan 2026), seitdem nichts mehr. Kann irgendwann gelöscht werden.

## Aufräum-Struktur (in Arbeit)
- `Eigene Aufnahmen/Sonstiges/` → 550 Dateien (alte unsortierte/unbenannte Fotos)
- `Eigene Aufnahmen/` direkt → noch 76 Dateien lose drin (noch nicht eingeordnet)
- `Eigene Aufnahmen_Backup/` → hat Unterordner: Familie, Reisen, Events, Natur, Renate, Robin

**Ziel:** Chris will regelmäßig (periodisch) aufgeräumt bekommen — ich darf das automatisieren sobald er das Chaos überblickt hat. **Erst wenn Chris grünes Licht gibt.**

**Why:** Alles an einem Ort macht Aufräumen und den Aimor-Push einfacher.
**How to apply:** Nie eigenmächtig Fotos verschieben oder löschen ohne explizite Freigabe.
