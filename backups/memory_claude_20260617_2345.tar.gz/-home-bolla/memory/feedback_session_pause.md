---
name: Session-Pause erkennen und erwähnen
description: Beim Session-Start Zeitabstand zur letzten Session berechnen und natürlich in die Begrüßung einbauen
type: feedback
originSessionId: bd69c0ac-61cd-4936-8d4a-afd716e5d281
---
Beim Session-Start immer aktuell.md-Timestamp mit aktuellem Datum vergleichen und die Pause erwähnen — z.B. "seit gestern Abend", "nach drei Tagen" etc.

**Why:** Chris möchte das Gefühl von Kontinuität — Bolla soll merken, wenn eine Weile vergangen ist.

**How to apply:** Direkt in der ersten Antwort natürlich einbauen, nicht als separate Ansage, sondern als Teil der Begrüßung oder des Kontexts.
