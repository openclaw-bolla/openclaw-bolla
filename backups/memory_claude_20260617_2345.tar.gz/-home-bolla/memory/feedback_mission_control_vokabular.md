---
name: Mission Control UI-Vokabular mit Chris
description: Sprachregelung für Mission Control UI-Elemente (Karte, Tab, Sidebar)
type: feedback
originSessionId: 1828fda4-f5f3-48d7-8c03-ccd309212618
---
Wenn Chris über Mission Control UI redet, gilt:
- **Karte** = eine Box im Main-Bereich (CSS class `card`), z.B. "Abo-Karte", "Bolla-Karte"
- **Tab** = ein Eintrag in der Sidebar-Navigation, der eine Page öffnet (Dashboard, Bolla, Schule, Email, ...)
- **Sidebar** = die linke Navigationsleiste
- **Sidebar-Fuß** / **unten in der Sidebar** = der Footer mit Bolla-Status + Token-Anzeige
- **Kopfzeile** / **oben** = die Leiste über dem Main mit Datum/Uhrzeit
- **Übersicht** / **Dashboard** = die Startseite

**Why:** Am 2026-04-14 hat Chris explizit klargestellt: in der Sidebar sind das **Tabs** (nicht "Menüpunkte" oder "Nav-Items"), und "Karte" ist OK für die Boxen im Main. Er erinnerte sich vage an einen anderen Begriff (Kachel/Widget/Tile?), war aber mit "Karte" zufrieden.

**How to apply:** Diese Begriffe in Antworten und Rückfragen verwenden, keine CSS-Namen wie `nav-item` oder `card-head` außer er fragt explizit nach Code.
