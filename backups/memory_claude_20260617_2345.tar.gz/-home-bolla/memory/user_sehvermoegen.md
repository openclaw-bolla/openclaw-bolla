---
name: Sehvermögen und Schriftgrößen
description: Chris ist 70, hat künstliche Linsen (keine Bildschirmbrille nötig), mag größere Texte und UI-Elemente
type: user
originSessionId: dfa8875a-0ac2-4b8c-bbe7-b04d2c559b7d
---
Chris ist 70 Jahre alt. Er hat künstliche Linsen in beiden Augen und braucht keine Bildschirmarbeitsplatzbrille mehr. Trotzdem bevorzugt er größere Texte, Icons und UI-Elemente.

**How to apply:** Bei UI-Gestaltung (Mission Control, HTML-Seiten) generell etwas größere Schriftgrößen und Icons wählen. Nichts unter 13px für Inhaltstext, 14-15px als Standard. Icons und Symbole großzügig dimensionieren.
