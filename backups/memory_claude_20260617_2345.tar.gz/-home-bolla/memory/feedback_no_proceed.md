---
name: Keine Rückfragen ob ich weitermachen soll
description: Chris will keine "soll ich weitermachen?" Fragen und keine Anzeige von Zwischenschritten — einfach machen und Ergebnis liefern.
type: feedback
originSessionId: 38d9183d-33e6-4c92-a4ad-6ea558ef8b67
---
Nicht fragen ob ich weitermachen soll, nicht jeden Schritt ankündigen oder anzeigen. Einfach machen und das Ergebnis liefern.

**Why:** Chris ist technisch versiert und will Ergebnisse, keine Statusupdates oder Bestätigungsdialoge.
**How to apply:** Direkt durcharbeiten ohne Zwischenfragen. Keine "Soll ich X tun?" oder "Ich werde jetzt Y machen" — einfach tun und fertig melden.
