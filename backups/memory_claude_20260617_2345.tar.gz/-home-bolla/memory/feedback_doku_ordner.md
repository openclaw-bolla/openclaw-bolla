---
name: Anleitungen direkt im Doku-Ordner speichern
description: Word/PDF Anleitungen immer direkt im Doku-Ordner erstellen, nicht woanders
type: feedback
originSessionId: dfa8875a-0ac2-4b8c-bbe7-b04d2c559b7d
---
Technische und allgemeine Anleitungen (.docx, .pdf) immer **direkt** in folgendem Ordner erstellen:
`D:\OneDrive\Dokumente\Bolla\claud code - openclaw Doku\`

**Why:** Dateien in diesem Ordner sind direkt in Mission Control verlinkt und öffnen ohne Download/Protected View.

**How to apply:** Wenn eine Anleitung, Dokumentation oder ein How-To als Word/PDF erstellt wird, als Zielordner immer den Doku-Ordner verwenden — nicht erst woanders speichern und dann kopieren.

Wenn sich ein dokumentierter Prozess ändert (z.B. neue Schritte, neue Erkenntnisse, Status-Updates), die zugehörige Word/PDF-Anleitung nach Abschluss der Aktionen neu generieren. Nicht nur die Markdown-Quelle updaten — auch das Dokument selbst.
