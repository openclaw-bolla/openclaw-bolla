---
name: reference-bolla-songs
description: "Schüler-Geburtstagslieder werden über die Site \"Bolla Songs\" erstellt, nicht über Claude"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 2430877f-7d01-4a18-a5f2-d3b0d3b27139
---

Für Schüler-Geburtstagslieder nutzt Chris die Site **"Bolla Songs"** — nicht Claude.

**How to apply:** Wenn Chris nach Geburtstagslieder für Schüler fragt, auf Bolla Songs verweisen statt selbst Songs zu generieren.
