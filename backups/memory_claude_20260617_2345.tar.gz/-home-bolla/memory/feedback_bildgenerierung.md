---
name: feedback-bildgenerierung
description: "Bildgenerierung für Covers und MC immer Pollinations.ai — kostenlos, kein API-Key nötig"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 6f7a5017-294d-4876-8441-7eca934fd61a
---

Für Cover-Generierung (Suno/RouteNote) und alle anderen Bildaufgaben immer **Pollinations.ai** verwenden, nicht Gemini Image API.

**Why:** Pollinations ist kostenlos und kein API-Key nötig. Gemini kostet Geld. Explizit so vereinbart.

**How to apply:** URL: `https://image.pollinations.ai/prompt/{encoded_prompt}?width=3000&height=3000&nologo=true&enhance=true`  
Falls Pollinations nicht 3000×3000 liefert → mit Pillow auf 3000×3000 hochskalieren (LANCZOS).  
Einzige Ausnahme: wenn Pollinations down ist und Qualität kritisch — dann erst fragen.
