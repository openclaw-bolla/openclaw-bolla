---
name: suno-routenote-releases
description: Welche Songs bereits für RouteNote vorbereitet/eingereicht wurden — keine Duplikate!
metadata: 
  node_type: memory
  type: project
  originSessionId: b0f104b7-97a3-4ae8-a86e-722b13d75cfa
---

# Suno Songs für RouteNote Distribution

**Why:** Chris hat ~350 Suno-Songs (Paid Plan = Commercial Rights). Viele sind Schüler-Songs (Geburtstag, Klassen). Nur namenfreie Songs ohne Schulbezug werden eingereicht.

**How to apply:** Vor jedem neuen Batch prüfen ob Song bereits in dieser Liste steht. Lyrics immer auf Namen/Schulbezug checken (Mandel, Lessing, Schülernamen).

## Batch 1 — Mai 2026 ✅ RELEASED (in released/ Ordner)
Iron Thunder, Prairie Moonlight Waltz, Night Whispers, Lonely Echoes, Echoes of Eternity,
Shake It Loose, Mein Hund Hat Meine Hausaufgaben Gefressen, AI Symphony, KI-Wunder,
Die Zukunft ist Jetzt, Hippity Hoppity Chaos, Bunny Hop Hustle, Blazing Waves Match,
Sonnenzeit, Sommerleuchten, The Forgotten Star
→ 16 Songs

## Batch 2 — 2026-05-15 ✅ RELEASED (in released/ Ordner)
Lights Fade Slowly, Classroom Daydreams, Hellish Hallways, Escuela de Vida,
Schoolyard, School of Life, Classroom Dreams, Back to the Chalkboard,
Classroom Chaos, Schoolhouse Days, Pflanze die aus dem Boden wächst,
School Days Groove, School Vibes, School of No Rules
→ 14 Songs

## Batch 3 — 2026-05-15 🟡 BEREIT (im Hauptordner, noch nicht eingereicht)
Class in Session, Faith in the Classroom, Fever in the Classroom,
Old Messages, School Rules, Teenage Dreams
→ 6 Songs in: `D:\OneDrive\Dokumente\Bolla\Suno_RouteNote\`

## Suno Account
- Username: StingingWallOfSounds
- Plan: Paid (Monthly) → Commercial Rights für alle Songs
- API: `https://studio-api-prod.suno.com` (Stand Mai 2026)

## Ausschluss-Kriterien
1. Geburtstagssongs raus (birthday, Geburtstag, Herzlichen Glückwunsch)
2. Schülernamen in Lyrics raus
3. "Mandel" / "Lessing" / "Gymnasium" in Lyrics raus
4. "In der Weihnachtskinderküche" → NIE einreichen (Enkelnamen!)
