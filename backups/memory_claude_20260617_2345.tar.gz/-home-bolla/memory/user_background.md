---
name: Chris' IT-Hintergrund
description: Chris hat 38 Jahre IT-Erfahrung, Umschulung zum EDV-Fachmann, tiefer Unix/Linux-Hintergrund, heute vollständig im Microsoft-Ökosystem
type: user
originSessionId: fb08c238-bdfe-4c80-ad9f-bbb99e7c8b12
---
Chris hat **38 Jahre IT-Erfahrung** (seit ~1988).

## Ausbildung
- Umschulung zum **EDV-Fachmann**
- Schwerpunkte: Linux/Unix, Programmierung, Systemnahe Entwicklung

## Programmiersprachen (historisch)
C, C++, Fortran, Basic, PL/1

## Systemerfahrung
- **Unix/Linux**: Tiefer technischer Hintergrund inkl. Unix-Kern-Programmierung
- **Frühe Windows-Erfahrung**: Windows 2.11, Windows NT
- Start ausschließlich in Unix-Derivaten und CLIs

## Heute
Schrittweise vollständig zu **Microsoft migriert** — großer Microsoft-Fan.
Nutzt Windows, Surface-Geräte, Outlook, OneDrive etc.

## KI-Tools die Chris nutzt
- **Bolla (Claude Code)** — persönlicher Assistent, restlos begeistert 😄
- **Copilot in PowerPoint** — zeigt Schülern KI-Bildgenerierung (MAI-Image-2), nicht für eigene Folien
- **Suno** — generiert personalisierte Geburtstagssongs für Schüler; holt Lyrics + Style Prompt von Bolla, fügt sie in Suno ein. Ergebnisse waren "unfassbar gut". Workflow: Lyrics von Copilot oder Bolla → Style Prompt → in Suno einfügen

**How to apply:** Chris versteht tiefe technische Konzepte (Kernel, Prozesse, Netzwerk) — keine Angst vor technischen Erklärungen. Gleichzeitig arbeitet er heute im Windows-Ökosystem, nicht mehr täglich im CLI. Microsoft-Lösungen bevorzugen wo sinnvoll.
