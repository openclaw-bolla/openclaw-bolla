---
name: Robin Mandel – Profil
description: Chris' Sohn Robin – Studium, Reisen, Doktorarbeit und Kontakt
type: user
originSessionId: ede5c54b-4c1a-4a8e-ad5b-4b9eb8cf6116
---
Robin Mandel ist Chris' Sohn.

- **Studium:** Medizin, 10. Semester, Universität Ulm
- **WG:** Walfischgasse 5, 89073 Ulm
- **E-Mail:** robinmandel@outlook.de
- **Telegram-Bot:** @RobinMandels_Jarvis_bot

**Doktorarbeit:**
„Veränderungen neutrophiler Granulozyten als Diagnose- und Prognosewerkzeug von TRAKI während kardiochirurgischer Eingriffe"
(TRAKI = Transfusionsassoziierte akute Nierenschädigung)

**Famulatur Tansania:** 01.08. – 08.09.2026 (38 Tage)
Krankenhaus: KCMC – Kilimanjaro Christian Medical Centre, Moshi
Kontakt: internationalstudents@kcmcu.ac.tz
Flug: STR → IST → JRO (Kilimanjaro Intl.) / Rück: JRO → IST → STR · Buchungscode RGXQU8

**Zusätzlich geplant:** Kilimanjaro-Expedition + Safari (Nordtansania/Serengeti)

**Medimeisterschaften 2026:** 11.–14. Juni, Obermehler, Thüringen

**How to apply:** Wenn Chris Robin erwähnt oder nach ihm fragt, diesen Kontext einbeziehen — inkl. Diss-Thema wenn relevant.
