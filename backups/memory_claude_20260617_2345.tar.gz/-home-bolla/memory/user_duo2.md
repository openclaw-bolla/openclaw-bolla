---
name: Handys: Surface Duo 2 + Huawei P20
description: Chris hat zwei Handys — Surface Duo 2 (ADB via WLAN) und Huawei P20 (zweites Handy, kein ADB wegen Android 11)
type: user
originSessionId: 392e2e08-0564-42ef-9c3b-3e90798109e6
---

## Huawei P20 — Haupt-Handy fürs Telefonieren UND Sprachaufnahmen
- **Chris nutzt das P20 zum Telefonieren** und für mmc-Sprachaufnahmen (Browser, Edge auf dem P20)
- Android 11 → **kein ADB-Management möglich** (Android 11 blockiert wireless ADB ohne USB-Debugging-Aktivierung die auf dem P20 nicht zugänglich ist)
- **Wenn mmc-Audio "dumpf/Hall/leise" klingt → kommt vom P20-Mic, nicht vom Duo 2**

## Surface Duo 2 — Smart-Device, NICHT zum Telefonieren
- **🚨 Mic ist kaputt verklebt** — Chris nutzt das Duo 2 **nicht zum Telefonieren oder für Sprachaufnahmen**
- Bleibt aber als Smart-Device im Einsatz: ADB-Steuerung, Apps, Notification-Hub
- Wenn jemand "Sprache auf dem Handy" sagt → ist es das P20

### Verbindung Duo 2 (ADB):

- **IP:** `192.168.178.20` (DHCP-fest im Heimnetz, ändert sich nie)
- **Connect-Port:** `41873`
- **Verbinden:** `adb connect 192.168.178.20:41873`
- **Pairing** (nur wenn connect fehlschlägt): Duo → Entwickleroptionen → Kabelloses Debugging → Gerät koppeln → neuen IP:Port + 6-stelligen Code verwenden, dann `echo "<code>" | adb pair <ip:port>`
