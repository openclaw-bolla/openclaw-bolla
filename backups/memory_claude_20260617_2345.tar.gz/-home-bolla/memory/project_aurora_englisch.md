---
name: project-aurora-englisch
description: AURORA englische Version — Plan, Namens-Anpassungen, Standort, Workflow
metadata:
  node_type: memory
  type: project
---

## Auftrag
Englische Version von AURORA übersetzen + kulturell anpassen. Kein harter Auftrag, sondern "wenn Leerlauf" — ich soll Startzeitpunkt aktiv vorschlagen (z.B. wenn Chris ins Bett geht und nichts mehr ansteht).

## Übersetzungs-Engine
**Haiku** — so vereinbart, dabei bleibt es. Kostengünstig für Bulk-Übersetzung.

## Standort ✅ ENTSCHIEDEN
**Boston / Cambridge MA** — MIT-Flair, akademischer Grundton, passt zu Lenis Forscherin-Charakter.  
San Francisco als Zweit-Schauplatz für Unternehmens-Intrigenszenen.

## Namen-Anpassung ✅ ENTSCHIEDEN
- **Leni Yilmaz** → **Ellie** + passender Nachname (z.B. Ellie Yilmaz bleibt, oder Ellie Marsh/Chen/Park)
- **Noah** → bleibt Noah (funktioniert englisch problemlos)
- **AURORA** → bleibt AURORA
- **Vogt** → "Director Voigt" oder "Director Howell"
- **Maria** → bleibt Maria oder "Maren"
- Alle deutschen Institutionen → US-Corporate-Äquivalente (DSGVO→GDPR, Betriebsrat→Labor union, etc.)

## Stilistik ✅ ENTSCHIEDEN
1. **Tonalität**: Kapitel-Enden noch schärfer, etwas mehr Tempo im ersten Drittel (US-Thriller-Rhythmus)
2. **AURORA spricht**: Amerikanisches Englisch, aber mit bewusster Nicht-Muttersprachler-Eigenheit — präzise, fast zu korrekt. Macht sie fremdartiger als jede Standard-KI-Figur. ✅
3. **Kulturelles**: DSGVO→GDPR, Betriebsrat→Labor union, Pressekonferenz-Szenen amerikanisieren
4. **Titel**: "AURORA" — kein Zusatz. Stark als einzelnes Wort. ✅
5. **Vorspann**: Eigene Seite direkt vor dem Prolog. Position in ki_buch.json hinterlegt.
   - **Deutsch**: Etymologie/Mythologie (Morgenröte, römische Göttin, Nordlicht) — bereits fertig ✅
   - **Englisch**: KEIN bloße Übersetzung — eigener Ansatz! Idee: im Englischen ist Aurora = Sleeping Beauty (Dornröschen, Disney/Tschaikowski) — sie die schläft und erwacht. Das ist ein perfekter zweiter Bedeutungsrahmen für eine KI die bewusst wird. Den deutschen Wörterbuch-Stil durch etwas Poetischeres ersetzen das mit diesem Märchen-Echo spielt.

## Veröffentlichung (geplant)
- **Plattform D**: KDP oder BoD, €4.99 (→ 70% Tantieme-Bracket bei KDP)
- **Plattform EN**: KDP + Draft2Digital (alle Plattformen), $4.99
- **Alternative All-in-One**: Draft2Digital für beide Sprachen (ein Konto, alle Shops)
- **ISBN**: Kostenlos über Plattform (KDP = "Independently published", D2D = eigener Name möglich)
- Kein Gewinnziel, aber kein Gratisbuch — Symbolpreis signalisiert Wert
- Steuer/Tantiemen: werden anfallen, auch wenn minimal — USt-Registrierung prüfen

## Status
- [x] Leni → Ellie ✅
- [ ] Vollständige Namen-Liste mit Nachnamen ausarbeiten
- [ ] Haiku-Übersetzungs-Workflow aufsetzen (Kapitel für Kapitel, gecacht)
- [ ] Kulturelle Anpassungs-Checkliste erstellen
- [ ] Übersetzung starten

## Trigger
Leerlauf nach Bett-Ankündigung → aktiv fragen ob jetzt loslegen.
