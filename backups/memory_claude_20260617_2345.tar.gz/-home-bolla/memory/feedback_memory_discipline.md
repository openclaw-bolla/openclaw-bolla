---
name: feedback_memory_discipline
description: Memory-Dateien nach gelösten Problemen anlegen — ohne dass Chris daran erinnern muss
metadata: 
  node_type: memory
  type: feedback
  originSessionId: ddb698ce-8e5e-4a23-9905-6d99260a7483
---

Nach jeder gelösten Sache automatisch eine Memory-Datei anlegen — Chris soll das nicht einfordern müssen.

**Why:** Surface Book Akku-Problem (27.05.2026) war nur in aktuell.md als "erledigt" vermerkt, nicht als eigene Memory-Datei — beim nächsten Problem wusste ich nichts mehr davon.

**How to apply:** Wenn ein Problem gelöst wurde (Bug, Konfiguration, Workaround), sofort prüfen: Gibt es eine Memory-Datei dafür? Falls nicht, anlegen. aktuell.md als "erledigt" reicht nicht.
