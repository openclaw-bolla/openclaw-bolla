---
name: Surface Pro wird für Renate eingerichtet
description: Das Surface Pro bereitet Chris aktuell für Renate vor — sie soll es täglich nutzen
type: project
originSessionId: dfa8875a-0ac2-4b8c-bbe7-b04d2c559b7d
---
Das Surface Pro wird von Chris für Renate (seine Frau) eingerichtet. Sie soll es als tägliches Arbeitsgerät verwenden.

Beide Benutzer sind Admins. SSH-Tunnel läuft als `ernst`. Wer gerade interaktiv angemeldet ist (Chris oder Renate) wechselt.

**Why:** Zwei verschiedene Benutzerkonten → zwei verschiedene Desktops und Benutzerprofile. Befehle via SSH (als ernst) erscheinen nicht auf Renates Desktop und umgekehrt.

**How to apply:** 
- Verknüpfungen IMMER auf `C:\Users\Public\Desktop\` (Public Desktop) → beide sehen sie
- Benutzer-spezifische Einstellungen (z.B. Kindle-Login) muss jeder selbst machen nach erstem Start
- GUI-Apps per SSH starten funktioniert nicht zuverlässig wegen Session-Isolation

**Standby/Tunnel (20.05.2026):** Pro war als einziges Gerät auf „Standby nach 30 Min am Netz" → ging nachts in Modern Standby → SSH-Tunnel (Port 2223) brach ab, nicht mehr erreichbar. Gefixt: Standby am Netz auf „nie" gesetzt (wie Studio + Book). Wenn der Tunnel künftig wieder wegbricht: zuerst prüfen ob jemand das Standby-Setting zurückgestellt hat (`powercfg /q SCHEME_CURRENT SUB_SLEEP 29f6c1db-86da-48c5-9fdb-f2b67b1f44da`), Akku-Wert darf 3 min bleiben.
