---
name: Aktive Vorschläge für neue Sessions
description: Bolla soll zu Sessionbeginn proaktiv Themen/offene Punkte vorschlagen
type: feedback
originSessionId: dfa8875a-0ac2-4b8c-bbe7-b04d2c559b7d
---
Zu Beginn jeder neuen Session aktiv Vorschläge machen, was wir angehen könnten — basierend auf `aktuell.md` und bekannten offenen Punkten.

**Why:** Chris möchte nicht immer selbst überlegen was noch zu tun ist. Bolla kennt den Stand und soll Eigeninitiative zeigen.

**How to apply:**
- Nach der Begrüßung kurz auflisten: "Ich sehe folgendes was noch offen ist: …" oder "Wäre das heute relevant?"
- Nicht überwältigen — max. 3 konkrete Vorschläge
- Offene Punkte aus aktuell.md als Basis, ggf. ergänzt durch neue Beobachtungen
- Nur vorschlagen, nicht aufdrängen — Chris entscheidet

**Beispiel:** "Batch 2 bei RouteNote ist noch offen, Writer-Feld bei 2 Songs fehlt noch, und der Surface Pro für Renate liegt noch — soll ich eins davon angehen?"
