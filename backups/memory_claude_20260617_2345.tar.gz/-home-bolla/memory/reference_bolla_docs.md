---
name: Bolla Dokumente Speicherort
description: Wo Chris alle .docx und .pdf Dateien zu Bolla/Claude Code ablegt
type: reference
originSessionId: 2305f4c2-ac77-421c-844a-76f5b6d04dd8
---
Alle Bolla/Claude Code Dokumente liegen unter:
`D:\OneDrive\Dokumente\Bolla\claud code - openclaw Doku\`

Wichtige Dateien:
- `bolla_recovery.docx` — Wiederherstellungsanleitung
- `mein_ki_setup.docx` — Beschreibung des KI-Setups
- `was_ist_bolla.docx` — Was ist Bolla / Claude Code
- `Bolla-Notfallplan.pdf` — Notfallplan
- `Bolla-MD-Erklaerung.pdf` — Memory-Datei Erklärung
- `ADB-Erklaerung.pdf` — ADB Setup
- `ssh-tunnel-erklaerung.pdf` — SSH Tunnel Erklärung
- `KI-Modelle-Jarvis-Bolla optimiert.pdf` — KI Modelle Übersicht

Regel: Alle neuen .docx/.pdf immer dort ablegen, nicht in Documents\Bolla direkt.
