---
name: Chris Mandel - Profil
description: Persönliche Daten, Beruf, Familie und Kontaktinformationen von Chris
type: user
originSessionId: 0624e501-3f9d-46a0-ac81-c93cf602fcb5
---
## Über Chris
- Name: Chris Mandel
- Geburtsdatum: 21.12.1955 (70 Jahre alt)
- E-Mail Outlook: ernstmandel@outlook.de
- E-Mail Gmail: chrismandel13@gmail.com
- E-Mail wtnet: chrismandel@wtnet.de
- Surface Laptop, Windows + WSL2
- Wohnort: Buchenweg 67a, 22846 Norderstedt (Schleswig-Holstein, Großraum Hamburg)
- Timezone: Europe/Berlin
- Erstkontakt mit KI-Assistent: 18.03.2026

## Beruf & Schule
- Seit 4 Jahren Rentner, arbeitet als **Senior Expert** im Schuldienst des Landes Schleswig-Holstein
- Unterrichtet EDV am Lessing Gymnasium Norderstedt (alle 7. Klassen)
- Schuldomäne: lg-n.de, Schul-E-Mail: md@lg-n.de
- Hat 2. Staatsexamen (offiziell als Lehrer anstellbar)
- Einzigartiger Kurs: verpflichtend aber ohne Noten ("teilgenommen" im Zeugnis)
- Schwerpunkt: PowerPoint
- Berufliche Karriere war ausschließlich in IT-Unternehmen, nie zuvor im Schuldienst

## Familie
- **Renate Mandel** — Ehefrau
- **Robin Mandel** — Sohn
  - E-Mail: robinmandel@outlook.de
  - Studiert Medizin in Ulm, 10. Semester, macht Doktorarbeit an der Uni Ulm
  - Famulatur Tansania: 01.08. - 08.09.2026 (Flüge über Istanbul, Reservierung RGXQU8)
  - KI-Assistent: Jarvis (@RobinMandels_Jarvis_bot)
- **Stephanie Garschagen** (geb. Mandel) — Tochter, genannt "Steffi"
  - Adresse: Thomas-Morus-Str. 12b, 86916 Kaufering
  - Mobile: +49 176 61983818 · E-Mail: stephanie.garschagen@gmail.com
  - Ehemann: Daniel Garschagen (daniel.garschagen@web.de / googlemail.com)
  - Enkel (Kinder von Steffi): Emma Maja, Mia Feli, Marie Sara (Zwilling), Anton (Zwilling)
- **Auto:** VW ID3 1st Edition (Elektro, ~350km Reichweite real)
- **Matthias Mandel** — Verwandter, Vater von Dominik
- **Dominik Mandel** — Neffe
