---
name: feedback_kdp
description: KDP-Anforderungen — Cover-Formate, Kategorieproblem
metadata:
  type: feedback
---

## KDP Cover-Format
**Nur JPG oder TIFF akzeptiert, NICHT PNG** — auch wenn PNG qualitativ besser ist. Wenn Cover als PNG vorhanden: zu JPG konvertieren vor Upload.

**Why:** KDP-Upload ist restriktiv bei Dateiformaten.

**How to apply:** Immer Cover zu JPG konvertieren, bevor ich es erwähne oder Chris hochlädt.

## KDP Kategorien
Hierarchie und verfügbare Optionen sind weniger stabil als gedacht — nicht blind auf Dokumentation verlassen. Besser: Chris schaut im Live-Dropdown, welche Kategorien existieren, und ich helfe dann, die besten auszuwählen.

**Why:** KDP-Kategorien variieren regional und ändern sich. "Techno-Thriller" existiert, aber nicht immer direkt unter "Thriller" — muss durchsucht werden.

**How to apply:** Bei KDP-Uploads: "Was siehst du im Dropdown?" statt theoretisch zu sagen "wähle XYZ".
