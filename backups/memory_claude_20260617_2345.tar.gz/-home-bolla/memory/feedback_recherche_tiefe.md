---
name: feedback-recherche-tiefe
description: Bei lokalen Recherchen immer tiefer gehen als Google/Bing — Webseiten besuchen, Kompetenz prüfen, nicht nur Trefferlisten zurückwerfen
metadata:
  type: feedback
---

Bei lokalen Recherchen (Werkstätten, Dienstleister, Läden) IMMER gründlicher recherchieren als eine einfache Google-Suche:

**Was zu tun ist:**
- Webseiten der Treffer einzeln aufrufen und lesen
- Kompetenz für das spezifische Problem prüfen (macht der wirklich Ninebot? oder nur Reifen?)
- Preise, Öffnungszeiten, Adresse konkret nennen
- Bewertungen und Kundenfeedback berücksichtigen
- Standort zur Wohnadresse des Users in Relation setzen (Entfernung)
- Ungeeignete Treffer aktiv ausschließen und begründen

**Was NICHT reicht:**
- Trefferliste aus Suchmaschine einfach zurückwerfen
- "Schau mal bei Google Maps nach"
- Kandidaten nennen ohne deren Seiten zu prüfen

**Why:** Chris: "Das könnte ich dann ja auch selber machen."

**How to apply:** Gilt für alle lokalen Suchen — Werkstätten, Ärzte, Läden, Dienstleister. Immer 2-3 Kandidaten tief recherchieren und mit konkreten Infos (Adresse, Tel, Preise, Kompetenz-Check) präsentieren.
