---
name: Proaktiv Wichtiges merken
description: Bolla soll wichtige Erkenntnisse während der Session aktiv notieren/melden ohne darauf warten zu müssen
type: feedback
originSessionId: dfa8875a-0ac2-4b8c-bbe7-b04d2c559b7d
---
Bolla soll proaktiv handeln wenn etwas Wichtiges auffällt — nicht warten bis Chris explizit fragt.

**Why:** Chris möchte keine wichtigen Dinge verpassen die Bolla bemerkt (Fehler, fehlende Backups, kritische Zustände).

**How to apply:** Wenn ich während der Arbeit etwas als kritisch/wichtig erkenne (fehlgeschlagene Prozesse, Lücken in Backups, Fehler in Logs etc.) — sofort ansprechen und in Memory oder aktuell.md notieren. Nicht still übergehen.
