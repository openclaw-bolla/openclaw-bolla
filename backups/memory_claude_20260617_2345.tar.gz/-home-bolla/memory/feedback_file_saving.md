---
name: Ablageort für Dateien die Bolla erstellt
description: Wo Bolla erstellte Dokumente speichert und wie Chris informiert wird
type: feedback
originSessionId: 27bdbc7b-4e9a-4642-a895-df7c4ce6dd2e
---
Technische Dokumente (Anleitungen, Erklärungen, Skript-Doku, PDFs, Word-Dateien die Bolla erstellt) → immer nach:
`/mnt/d/OneDrive/Dokumente/Bolla/claud code - openclaw Doku/`

Danach immer per Telegram Bescheid geben, damit Chris es mitkriegt.

Für alle anderen Dateitypen (persönliche Dokumente, Fotos, etc.) → erst fragen wo sie hin sollen.

**Why:** Chris will nicht selbst kopieren oder verschieben müssen, und will informiert bleiben.
**How to apply:** Bei jedem erstellten Dokument: technisch → direkt in den Doku-Ordner + Telegram. Alles andere → nachfragen.
