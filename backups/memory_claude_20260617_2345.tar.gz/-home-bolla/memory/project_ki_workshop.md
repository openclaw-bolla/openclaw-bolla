---
name: ki-workshop-lehrer
description: "Chris' 90-Min KI-Workshop für Lehrerkollegen in der Projektwoche am Lessing-Gymnasium — laufende Ideensammlung"
metadata: 
  node_type: memory
  type: project
  originSessionId: 5f0e023b-525a-40af-8dff-17bc6d20ce73
---

# KI-Workshop für Lehrerkollegen (Projektwoche Lessing-Gymnasium)

Chris hält in der Projektwoche einen 90-Minuten Short-Track für Lehrerkollegen über aktuelle KI-Möglichkeiten. Er sammelt über mehrere Tage laufend Ideen und kippt sie mir stückweise ein.

**Why:** Er hat schon konkrete Vorstellungen, will aber dass ich alles zentral sammle und strukturiere, damit er später gezielt Anweisungen draus ableiten kann ("erzeuge Folie X", "passe Y an").

**How to apply:**
- **Zentrale Sammeldatei:** `/home/bolla/workspace/projektwoche-ki-workshop/workshop-ideen.md` — IMMER dort einsortieren wenn Chris was zum Workshop einwirft. Thematisch gegliedert, mit Status-Tags `[IDEE]`/`[RECHERCHE]`/`[IN PPT]`/`[FERTIG]`.
- **Roh-Einwürfe** die nicht sofort zuordenbar sind → in den "Inbox"-Abschnitt der Datei.
- **PPT-Deliverable:** `D:\OneDrive\Desktop\KI_fuer_Lehrer.pptx` (Stand 20.05.: nur Titelfolie). python-pptx ist auf dem Studio installiert → Folien programmatisch erzeugbar. Vor Bearbeitung Backup.
- **Assets** (generierte Bilder/Videos) → `projektwoche-ki-workshop/assets/`. Bilder via Pollinations (kostenlos), nicht Gemini Image.
- **Termin:** Projektwoche 22.–26.06.2026, Vortrag voraussichtlich 24.06.2026 13:30 Uhr (ab 20.05. noch ~5 Wochen Vorlauf).

**Inhaltliche Blöcke (Stand 20.05.):** Meilensteine der IT (Gutenberg→Quantencomputer, Adoptions-Beschleunigung), Urheberrecht (Suno), Modell-Arten (Text/Bild/Video), Telli (Education SH), Copilot-Lizenzierung+Einsatz (von Chris als "ganz wichtig" markiert).
