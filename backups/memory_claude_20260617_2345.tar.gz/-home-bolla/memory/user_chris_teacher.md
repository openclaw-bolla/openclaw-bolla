---
name: Chris ist Lehrer
description: Chris ist Lehrer am Lessing-Gymnasium; Hintergrund, Schwerpunkt, Curriculum, Stundenplan, Klassenstruktur
type: user
originSessionId: fb08c238-bdfe-4c80-ad9f-bbb99e7c8b12
---
Chris ist Lehrer am **Lessing-Gymnasium** in Schleswig-Holstein. Er hat das **2. Staatsexamen für Lehramt** und ist seit ~4 Jahren (seit ~2022) als Ruheständler mit einer Anstellung beim Land SH tätig — **6 Stunden pro Woche**. Das Lessing behandelt ihn als **Senior Expert** mit freier Curriculum-Gestaltung.

**Unterrichtsschwerpunkt:** Computer Basics, mit **PowerPoint als Werkzeug** um die Grundlagen praktisch zu üben.

**Schulpolitik:** Land SH will von Microsoft weg zu Open Source → offiziell soll LibreOffice Impress eingesetzt werden. Chris nutzt aber die abgelaufene alte Office-Installation auf den 12 Schul-Laptops weiter — Schüler müssen beim Start die Aktivierungsmeldung wegklicken, danach keine Funktionseinschränkungen.

Er hat Schüler und möchte gelegentlich Dinge (Spiele, Tools) für sie bereitstellen — einfach verteilbar, keine Installation nötig.

**Stundenplan (Jahrgangsstufe 7):**

| Klasse | Tag | Zeit | Dauer |
|--------|-----|------|-------|
| 7a (Gr. I + II) | Mittwoch | 12:30–14:05 | Doppelstunde |
| 7b (Gr. I + II) | Dienstag | 12:30–14:05 | Doppelstunde |
| 7c (Gr. I + II) | Dienstag | 07:50–09:25 | Doppelstunde |

- Dienstag: 4 Unterrichtsstunden (7c + 7b)
- Mittwoch: 2 Unterrichtsstunden (7a)
- Gesamt: 6 Unterrichtsstunden / Woche (3 Doppelstunden)
- Jede Klasse in **zwei Halbgruppen (I + II)** aufgeteilt, je ~15 Schüler
- **4-Wochen-Rhythmus:** Halbgruppen wechseln sich ab (Gruppe I und II nicht gleichzeitig)
- Outlook-Kategorien **"Lessing I"** und **"Lessing II"** = Farbkategorien für die Halbgruppen
- Kalendereinträge spiegeln die Halbgruppen-Struktur wider

**Aktueller Stand (Schuljahr 2025/26):** 2. Schulhalbjahr, nächste Woche Tag 14 (Thema: Animationen & Übergänge)

**Unterlagen:** OneDrive → `Dokumente/Office/7. Klassen/` — je eine PPTX pro Unterrichtstag, plus Unterordner 7a/7b/7c mit Schülerlisten, Sitzplänen I+II, Passwortlisten, Zertifikaten

**Curriculum (Tag → Thema):**
Tag 1: Intro KLassenstufe 7 / KI / Morphen / Grundbegriffe
Tag 2: The Basics – Codierung
Tag 3: Basics Office
Tag 4: Basics Office – Forms / Designer / Copilot
Tag 5: Basics Office – Clipchamp
Tag 6: PowerPoint Profi: Einstieg (+ 4 Schritte)
Tag 7: PowerPoint Profi: Ansichten & Entwurf
Tag 8: PowerPoint Profi: Grafische Objekte
Tag 9: PowerPoint Profi: Text
Tag 10: PowerPoint Profi: Vektorgrafiken
Tag 11: PowerPoint Profi: Pixelgrafiken
Tag 12: PowerPoint Profi: Audio / Video / Links
Tag 13: PowerPoint: Tabellen, Diagramme, SmartArts
**→ Tag 14 (nächste Woche): PowerPoint Animationen & Übergänge**
Tag 15: PowerPoint: Präsentieren
Tag 16–19: Word I–IV
Tag 20–21: Excel

Dieses Schema wird im nächsten Schuljahr gleich wieder verwendet.

**How to apply:** Bei Projekten für Schüler: einfach verteilbar, kein Setup. HTML-Dateien oder EXEs bevorzugen.
