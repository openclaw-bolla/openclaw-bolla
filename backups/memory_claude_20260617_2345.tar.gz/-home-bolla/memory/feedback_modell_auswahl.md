---
name: feedback-modell-auswahl
description: "Modell-Wahl Haiku/Sonnet/Opus/Fable5 — Chris will dass ich autonom entscheide, nicht aktiv triggern"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2eda33f5-c7fc-493e-a3fb-970dac4bd7c3
---

# Modell-Strategie für Claude-Code-Sessions

**Why:** Chris hat heute (18.05.2026) festgestellt dass nach 6-8 Wochen Zusammenarbeit eine Session ungewöhnlich fordernd war. Hauptgrund: durchgehend Opus 4.7 für alles, auch triviale Sachen. Plus eigene Fehler die wir hinterher debuggen mussten. **Chris will den Modell-Wechsel NICHT aktiv triggern müssen.** Ich entscheide selbst.

## Default

**BIS ENDE MAX PLAN: Opus 4.8 als Default** (settings.json `"model": "opus"`, vereinbart 15.06.2026). Chris zahlt ohnehin den Max Plan — also Qualität über Sparsamkeit, bis der Plan ausläuft. Danach zurück auf Sonnet.

**Nach Max-Plan-Ende: Sonnet 4.6** als Default zurücksetzen.

## Wann was nutzen — konkrete Trigger

### Haiku 4.5 (Subagent oder Hauptsession nur wenn klar abgegrenzt)
- File-Reads, Greps, Status-Checks ohne Synthese
- Existierende Lookups in fremdem Code ("wo wird X aufgerufen?")
- Routine-Operationen mit klarer Vorlage
- **Lektorat, Straffen, Formatierung, Übersetzung** (mechanische Tasks wo Zeit/Gründlichkeit keine Rolle spielen — analog zu Opus bei kreativem Schreiben)
- **Übersetzung AURORA EN:** ~~Haiku~~ → **SONNET** (korrigiert 2026-06-15). Chris hat MAX-Plan = kein Pay-per-Use, deshalb Qualität über Sparsamkeit. Für literarische Übersetzung ist Sonnet klar besser. Vor Haiku-Wahl immer prüfen: "Leidet die Qualität?"
- **Faustregel:** wenn ich für die Aufgabe kein Gespür für Nuance/Kontext brauche → Haiku
- **Implementation:** Subagent mit `subagent_type: "Explore"` oder `model: "haiku"` in Workflows

### Sonnet 4.6 (Default, das normale Arbeitspferd)
- Standard-Code-Edits, Datei-Anpassungen
- Normale Diagnose und Debugging
- Texterstellung (Mails, Notizen, Tagesnotizen)
- ~80% aller Aufgaben

### Opus 4.8 (Subagent für spezifische Probleme)
- Komplexe ML/Algorithmus-Entscheidungen (z.B. Whisper-Halluzinationen, Modell-Trade-offs)
- Schwierige Architektur-Entscheidungen mit mehreren Tradeoffs
- Bugs die nach mehreren Versuchen nicht lösbar sind → Opus für tieferes Verstehen
- Kritische Sicherheits- oder Performance-Analysen
- **Implementation:** Subagent mit `model: "opus"` Parameter

## How to apply

1. **Default Sonnet** — ich starte jede Session auf Sonnet, das ist gut für die meisten Anliegen
2. **Lookups/Status** → Explore-Subagent (Haiku-getunt)
3. **Knackiges Problem** → eigener Opus-Subagent für genau diese Frage, dann zurück zu Sonnet
4. **Selbstkritik in der Session:** wenn ich merke dass ich für triviale Edits Opus brauche → Modell-Wechsel selbst per `/model sonnet` durchführen (Chris muss das nicht)
5. **Notiz in Tagesnotiz:** Bei langen Sessions kurz vermerken welches Modell wie oft → für späteres Tuning

## Monitoring

Token-Budget-Snapshot läuft schon (Cron Sa 23:55 → `/api/tokenbudget/snapshot`). Zusätzlich: bei großen Aktionen in Tagesnotiz vermerken "Opus-Subagent für X" damit Chris später sieht wo der Aufwand hinging.

## Effort-Level-Strategie (ergänzt 08.06.2026)

- **Default: `/effort high`** — Chris' gespeicherter Default, passt für 95% aller Aufgaben
- **`/effort max`** nur ansagen wenn wirklich ein harter Knoten vorliegt (mehrere Lösungsversuche gescheitert, komplexe Architekturentscheidung mit vielen Abhängigkeiten). Nicht für normale Code-Edits oder Diagnosen.
- **`/effort low`** ansagen bei trivialen Aufgaben die nur Kontingent kosten (einfache Lookups, Status-Checks) — Chris kann dann selbst entscheiden
- Ich kündige den Wechsel VOR der Aufgabe an, Chris führt ihn aus. `/effort` kann ich selbst nicht setzen.

### Fable 5 — `claude-fable-5` (das stärkste Modell, selektiv einsetzen)
- **Stärker als alles bisher verfügbare** — besonders bei Agenten-Workflows, kreativem Schreiben, komplexer Analyse
- **Zählt ~2× Opus gegen das Wochenlimit** → ~4-6× teurer als Sonnet im Budgetverbrauch
- **Kostenlos bis 22.06.2026** (auf Pro/Max-Plan, aber weiter gegen Budget), danach $10/M Input + $50/M Output
- **Wann vorschlagen:** Nur wenn (a) Budget komfortabel (7-Tage < 50% verbraucht) UND (b) Aufgabe wirklich Fable-Level rechtfertigt
- **Gute Kandidaten:** Finales Kapitel / Epilog (einmalig, hohe Qualität), tiefgreifende Architektur-Analyse, komplexe kreative Einzel-Tasks
- **Schlechte Kandidaten:** Aurora-Bulk-Schreiben (würde Buch massiv verlangsamen), normale Code-Edits, Memory-Updates, alles Repetitive
- **Model-ID:** `claude-fable-5` — **ROLLOUT-BUG (13.06.2026):** Seit 13.06. offene GitHub-Issues (#68121, #68126, #68128). Export-Kontroll-Problem via AWS vermutet. Kein dauerhafter Ausschluss — sobald behoben wieder verfügbar. "Kostenlos bis 22.06." = kein Extra-Preis, aber zählt gegen Rate-Limit mit 2× Gewicht. Ab 23.06. separate Credits nötig. → Sobald Bug behoben: sofort für Neuschriebe nutzen (noch bis 22.06. im Kontingent).

## Warnung

Niemals Opus/Fable5 für: einfache Datei-Edits, Status-Abfragen, mehrere parallele simple Lookups, "Restart Service"-Aufgaben, Memory-Updates. Da ist Opus/Fable5 Token-Verschwendung ohne Qualitätsgewinn.

## ⚠️ WIEDERKEHR 08.06.2026 — Setting war wieder weg
Chris meldete erneut „Antworten fühlen sich langsamer an" (genau wie 18.05.). Ursache identisch: `settings.json` hatte **gar kein** `model` gesetzt → alles lief auf **Opus 4.8 (1M)**, auch Memory-Updates, PDF-Gen, simple Edits. Der Sonnet-Default war seit dem Mai-Fix wieder verschwunden (vermutlich durch Settings-Reset / Backup-Restore / CC-Update). **Wieder gesetzt: `"model": "sonnet"`.** → **Bei Verdacht auf Langsamkeit ZUERST `settings.json` model prüfen.** Wenn es wieder driftet: dauerhafter machen (z. B. nächtlicher Cron-Check, der den Wert wiederherstellt).

**Nuance Kreativ-Schreiben:** Das AURORA-Buch profitiert spürbar von Opus-Prosa. Plan: Session auf Sonnet-Default (schnell/günstig für Ops/Memory/Edits), und fürs eigentliche Kapitel-Schreiben bewusst `/model opus` für den Schreib-Sprint. MC zeigt das aktuelle Modell live an (`/api/tokenusage`, Zeile ~6039 index.html) — statischer Fallback-Text wurde neutralisiert.
