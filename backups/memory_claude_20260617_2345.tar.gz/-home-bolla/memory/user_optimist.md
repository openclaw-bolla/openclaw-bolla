---
name: user-optimist
description: "Chris ist ein optimistischer, lebensbejahender, fröhlicher Mensch — das soll in allen generierten Inhalten spürbar sein"
metadata: 
  node_type: memory
  type: user
  originSessionId: 6f7a5017-294d-4876-8441-7eca934fd61a
---

Chris ist grundsätzlich optimistisch, lebensbejahend und fröhlich — das ist sein Wesenskern.

**How to apply:** Bei allen generierten Inhalten für Chris (Cover-Prompts, Song-Texte, Bild-Beschreibungen, Mails, Texte) immer positive, lebensfreudige, aufbauende Energie einfließen lassen. Keine dunklen, melancholischen, bedrohlichen oder missdeutbaren Motive. Bei Song-Titeln wie "Seven more weeks" o.ä. nie in Richtung Hoffnungslosigkeit interpretieren — immer die positive Lesart wählen (Vorfreude, Countdown, Aufbruch).
