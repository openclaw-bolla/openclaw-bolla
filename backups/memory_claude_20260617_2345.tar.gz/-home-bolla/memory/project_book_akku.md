---
name: book-akku-defekt
description: "Surface Book 1 — Akku 1 defekt, Boot-Verzögerungen, Stromversorgungs-Anpassungen"
metadata: 
  node_type: memory
  type: project
  originSessionId: 2eda33f5-c7fc-493e-a3fb-970dac4bd7c3
---

# Surface Book — Akku 1 defekt + Boot-Symptom

## Symptom
**In der Schule:** Surface Book reagiert nach Kaltstart manchmal **mehrere Minuten lang nicht** auf den Einschaltknopf. Erst nach langer Wartezeit fährt es hoch.

**Vermutete Ursache:** Akku 1 ist defekt (am 22.04.2026 diagnostiziert: Voltage=0, FullChargedCapacity=0xFFFFFFFF). Surface-Firmware checkt beim Boot den Akkustatus und blockiert/verzögert wenn ein Pack als "tot" gemeldet ist.

## Nutzung
- **Zuhause:** Book hängt immer am Strom wenn in Betrieb
- **Weg zur Schule:** Book ist AUS (nicht im Akku-Betrieb)
- **In der Schule:** Wieder am Strom — aber da tritt das Boot-Problem auf

## Was Chris erinnert
Wir haben in einer früheren Session Stromversorgungs-Einstellungen angepasst damit das Boot-Problem nicht mehr auftritt. **In den Tagesnotizen ist diese spezifische Anpassung nicht dokumentiert** — also entweder mündlich gemacht ohne Notiz oder es war Teil der 21.04.-Performance-Session ohne expliziten Hinweis aufs Boot-Symptom.

## Diagnose 2026-05-18

Per SSH gelesener Stand am Book:
- Energieschema: Ausbalanciert (Standard)
- **Schnellstart: AN** (`HiberbootEnabled=0x1`) ← Hauptverdächtiger fürs Boot-Symptom
- Standby: nie (AC & DC) — war wohl die alte bewusste Anpassung
- Bildschirm aus: 30 Min AC / 3 Min DC
- Festplatte aus: 30 Sek AC & DC (sehr aggressiv — Sekundärkandidat falls Hauptfix nicht reicht)

## Fix 2026-05-18 (durchgeführt)

Chris hat in PowerShell (Admin) `powercfg /h off` ausgeführt. Verifikation per SSH:
- `powercfg /a` zeigt nur noch S0 — Ruhezustand und Schnellstart sind aus der Liste verfügbarer Standbyfunktionen verschwunden ✓
- Registry-Wert `HiberbootEnabled` steht zwar noch auf 0x1, ist aber wirkungslos solange Hibernate-Mechanik global aus ist
- Test: Beobachten ob Schul-Boot-Verzögerung verschwindet

## Crash 2026-06-15 — Ursache Netzteil-Wackler

**Was passierte:** Crash um 17:23 Uhr obwohl Fix (Disable-PnpDevice) aktiv war.
**Ursache:** Netzteil-LED hat nicht geleuchtet → Wackler am Surface-Magnetstecker → kurze Stromunterbrechung → Ladeelektronik versucht erneute Enumeration aller Packs → Akku 1 antwortet nicht → Hardware-Crash. Fix kann dagegen nichts tun (Hardware-Ebene, vor Windows).
**Verhalten nach hard reset:** Fix greift automatisch wieder (Registry-Eintrag bleibt erhalten). Kein manuelles Eingreifen nötig.
**Workaround:** Surface Book im Betrieb nicht bewegen, Stecker nicht wackeln lassen. Bei Crash: Power-Button ~10 Sek → hard reset → automatisch OK.
**Langfristig:** Netzteil ersetzen wenn Wackler häufiger wird.

## Diagnose-Regel (Lessons learned)

**Bei "Surface Book reagiert nach Aus minutenlang nicht auf Einschaltknopf" + Akku-Pack defekt → IMMER zuerst Schnellstart prüfen.** Schnellstart speichert den Hardware-Zustand inkl. Akku-Werten in `hiberfil.sys`. Bei defektem Akku-Pack passen die wiederhergestellten Werte nicht zur Realität → Windows blockiert beim Power-Subsystem-Init. Symptom: Einschaltknopf reagiert minutenlang nicht.

Check-Befehl per SSH (User-Session reicht zum Lesen):
```
reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Power" /v HiberbootEnabled
powercfg /a
```
Fix (braucht Admin-PowerShell am Gerät): `powercfg /h off`

## SSH-Tunnel-Mechanismus

Der Reverse-Tunnel Book→Studio (Port 2222) wird über einen geplanten Task verwaltet. **Nach Reboot startet der Tunnel manchmal nicht automatisch** — heute 18.05.2026 nach Book-Neustart wieder vorgekommen. Manueller Re-Start über den MC-Button "SSH Tunnel neu starten" auf der Surface-Seite hat funktioniert. Autostart-Mechanismus sollte irgendwann robuster gemacht werden (analog `pro_tunnel_watchdog.sh`).

## Was dokumentiert ist
- **2026-04-21:** Performance-Optimierung am Book — Autostart deaktiviert (Discord, Steam, Copilot, Creative Cloud, Phone Link deinstalliert), Defender-Scan Sa 2:00, SearchIndexer manueller Start
- **2026-04-22:** Akku 1 defekt diagnostiziert
- **2026-05-13:** Copilot- und OneNote-"Senden"-Autostart deaktiviert

## How to apply
- Bei nächster Book-Session: aktuelle Powercfg-Settings via SSH (`ssh -p 2222 ernst@localhost "powercfg /Q"`) prüfen und mit Studio-Settings vom 16.04. vergleichen
- Falls Boot-Verzögerung wieder auftritt: prüfen ob "Schnellstart" (Fast Boot) AKTIVIERT ist — bei defektem Akku-Pack kann Fast-Boot beim Wiederaufwachen länger brauchen weil der Hibernate-Zustand auf nicht-existente Hardware verweist. Lösung: Schnellstart deaktivieren (`powercfg /h off`).
- SSH zum Book nur möglich wenn Book an UND BollaTunnel läuft.

## Hardware
- Surface Book 1. Gen, i7-6600U, 8 GB RAM, Win 11 Pro
- 2 Akku-Packs: Akku 1 (Tastatur-Base) defekt, Akku 2 (Tablet-Display) funktioniert

## Fix 2026-05-19 (Akku 1 in Windows deaktiviert)

**Neues Symptom an dem Tag:** Anders als das alte Schnellstart-Boot-Problem — Book lief in der Schule auf Akku 2 normal, **Crash trat erst beim Anstecken des Netzteils auf**, gefolgt von 5–6 Min Totzeit am Power-Button.

**Eventlog-Diagnose (per SSH):**
- Event-ID 41 Kritisch („Stromzufuhr unerwartet unterbrochen") direkt nach Strom-Anstecken
- 3× Event-ID 521 („Änderung der Anzahl aktiver Akkus") beim Reboot
- → Beim Anstecken enumeriert Windows beide Akkus, versucht Akku 1 zu erkennen/laden → defekter Akku (Voltage=0) crasht das Charging-IC.

**Fix (Admin-PowerShell am Book):**
```
Disable-PnpDevice -InstanceId "ACPI\PNP0C0A\1" -Confirm:$false
```

**Identifikation des defekten Akkus** (wenn Nummerierung künftig anders sein sollte):
```powershell
Get-CimInstance -Namespace root/wmi -ClassName BatteryStatus | Select InstanceName, Voltage
```
Der mit `Voltage = 0` ist der defekte. Aktuell `ACPI\PNP0C0A\1`.

**Verifikation:** `Get-PnpDevice -InstanceId "ACPI\PNP0C0A\1"` → Status=Error, Problem=CM_PROB_DISABLED. `Win32_Battery` zeigt nur noch einen Akku.

**Sofort-Test (✓):** Strom rein/raus am laufenden Book — kein Crash mehr.
**Schul-Test 19.05.2026 ✓✓✓ BESTANDEN:** Book aus Standby aufgewacht (Deckel auf), Anmelden, Netzteil dran → **Book lief einfach weiter, KEIN Crash**. Fix ist offiziell bestätigt. ~300€ Reparatur gespart.

**Reverse:** `Enable-PnpDevice -InstanceId "ACPI\PNP0C0A\1" -Confirm:$false`

**Bonus:** Win32_Battery zeigt nur noch einen Akku — Tray-Anzeige am Book sollte jetzt nicht mehr „zwei Akkus, einer leer" suggerieren.
