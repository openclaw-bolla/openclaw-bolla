---
name: feedback_mp_name
description: Mission Control heißt bei Chris "MP" (Mission Portal), nicht "MC"
metadata:
  type: feedback
  node_type: memory
---

Chris nennt das Mission Control Dashboard immer **MP** (Mission Portal), nie "MC".
- URL: http://127.0.0.1:18790/ (lokal) bzw. https://bolla.chrismandel.de (remote)
- HTML: /home/bolla/workspace/mission-control/index.html
- API: /home/bolla/workspace/scripts/mission_control_api.py

**Why:** Chris hat mich korrigiert als ich "in MC" sagte — er sagt "in MP".
**How to apply:** Immer "MP" verwenden wenn vom Dashboard die Rede ist.
