---
name: Schule und Unterricht
description: EDV-Unterricht am Lessing Gymnasium - Kurse, Zeiten, Themen
type: project
originSessionId: 0624e501-3f9d-46a0-ac81-c93cf602fcb5
---
## Kalender/Kurse (eingerichtet 02.04.2026)
- 100 Kalendereinträge für 7a, 7b, 7c (je I + II) in Outlook
- Kategorien: Lessing I (preset4) / Lessing II (preset21)
- 16 Themen pro Kurs (Basics -> PowerPoint -> RECAP)
- Titel-Format: `7a I - Thema`
- Rollback-Dateien in `backups/7a|7b|7c-created-events.json`
- Dateipfad Kurse: `D:\OneDrive\Dokumente\Office\7. Klassen\`

## Stundenplan
- 7a: Mi 12:30-14:05
- 7b: Di 12:30-14:05
- 7c: Di 7:50-9:25

**Why:** Chris unterrichtet alle 7. Klassen EDV, PowerPoint ist Schwerpunkt
**How to apply:** Bei Fragen zu Unterrichtsmaterial, Kalender oder Schulthemen
