---
name: Chris Accounts & Login-Emails
description: Welche E-Mail-Adresse Chris wo nutzt — wichtig um Verwechslungen zu vermeiden
type: user
originSessionId: 8984efab-50e2-453a-b2d6-950c3dceec55
---
## Anthropic / Claude Code Login
- **Aktuell:** chrismandel13@gmail.com
- **Pending:** Chris hat Support kontaktiert um die E-Mail zu ändern (Stand 16.04.2026) — Zieladresse noch nicht bekannt

## Standard-Absender für E-Mails
- ernstmandel@outlook.de (Microsoft 365 / Outlook) — Standard für alle E-Mail-Aktionen

## Weitere Konten
- chrismandel13@gmail.com — Gmail, Google Calendar, Anthropic-Login
- chrismandel@wtnet.de — wtnet Mail (Spam-Watcher)
- ernstmandel@outlook.de — Outlook, OneDrive, Azure, Cloudflare
