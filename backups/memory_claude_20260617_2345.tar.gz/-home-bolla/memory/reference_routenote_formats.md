---
name: reference-routenote-formats
description: "RouteNote Upload-Anforderungen für Audio und Cover — Suno liefert 64kbps, muss auf 320kbps konvertiert werden"
metadata: 
  node_type: memory
  type: reference
  originSessionId: e7c5cd24-7705-4855-82d9-31abaf36ffab
---

## RouteNote Upload-Anforderungen

### Audio (MP3)
- **Bitrate: mindestens 320kbps** (CBR)
- Sample Rate: 44.1kHz
- Problem: Suno liefert nur 64kbps — immer mit ffmpeg konvertieren!
- Fix in `mission_control_api.py` (Route `/api/suno/download-cover`): nach MP3-Download ffmpeg ausführen: `ffmpeg -y -i tmp.mp3 -b:a 320k -ar 44100 output.mp3`

### Cover (Bild)
- Format: **JPEG**
- Größe: **3000 × 3000 px** (quadratisch)
- Kein Text/Schrift im Bild erlaubt

### Ablageort
- Fertige Dateien landen in: `/mnt/d/OneDrive/Dokumente/Bolla/Suno_RouteNote/`
- Nach Upload → in `released/` Unterordner verschieben (routenote_watcher.py benachrichtigt per Telegram)

**Why:** RouteNote lehnt zu niedrige Bitraten mit "Oops! Upload failed" ab — ist schon zweimal passiert.
**How to apply:** Bei jeder MP3-Verarbeitung für RouteNote sicherstellen, dass ffmpeg-Konvertierung auf 320kbps stattfindet.
