---
name: MAI-Image-2 für BildGen einbauen
description: Microsoft MAI-Image-2 in Mission Control BildGen integrieren sobald für Copilot Pro / API verfügbar
type: project
originSessionId: ede5c54b-4c1a-4a8e-ad5b-4b9eb8cf6116
---
Microsoft MAI-Image-2 in den BildGen-Bereich von Mission Control einbauen, sobald API-Zugang für Privatnutzer/Copilot Pro verfügbar ist.

**Why:** Chris ist Copilot Pro Kunde und möchte MAI-Image-2 als Option neben Nano Banana nutzen.

**Stand (Juni 2026):** MAI-Image-2, MAI-Image-2-Efficient und MAI-Image-2.5 sind über **Azure AI Foundry** offiziell per API verfügbar.
- Endpunkt: `https://<resource>.services.ai.azure.com/mai/v1/images/generations`
- Preise: MAI-Image-2 = $33/1M Output-Tokens (~$0.13/Bild), MAI-Image-2-Efficient = $19.50/1M (~$0.08/Bild)
- Braucht: Azure-Account + Pay-as-you-go (kein Free Tier)
- Alternativ: **OpenRouter** hat MAI-Image-2.5 ($47/1M) — einfacher Setup, aber teurer
- PiAPI hat es NICHT

**How to apply:** Azure-Account einrichten → API-Key in config/ speichern → als neues Modell in `bildgen_generate()` (mission_control_api.py) + Option in Model-Auswahl (index.html) ergänzen. Einrichtung wartet auf Azure-Account von Chris.
