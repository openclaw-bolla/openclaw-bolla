---
name: Zwischenablage vs. Clipboard in MC
description: Wenn Chris "Zwischenablage" sagt meint er immer die Windows-Zwischenablage. "Clipboard" in MC ist ein eigenes Feature.
type: feedback
originSessionId: bd69c0ac-61cd-4936-8d4a-afd716e5d281
---
"Zwischenablage" = immer die Windows-eigene Zwischenablage (Ctrl+C/V).

**Why:** Chris hat klargestellt: In Mission Control gibt es ein eigenes Feature namens "Clipboard". Das sind zwei verschiedene Dinge.

**How to apply:** Nie verwechseln. Wenn Chris "in die Zwischenablage kopieren" sagt → Windows clipboard via `navigator.clipboard.writeText()`. Wenn er "Clipboard" sagt → MC-eigenes Feature gemeint.
