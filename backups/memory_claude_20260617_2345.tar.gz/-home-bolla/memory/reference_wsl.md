---
name: WSL2 Setup & RAM-Limits
description: .wslconfig Konfiguration und Hintergrund zum vmmem-Absturz vom 01.05.2026
type: reference
originSessionId: 27bdbc7b-4e9a-4642-a895-df7c4ce6dd2e
---
## RAM-Limit Konfiguration

`C:\Users\ernst\.wslconfig`:
```
[wsl2]
memory=4GB
swap=2GB
processors=4
```

Gesetzt nach vmmem-Absturz am 01.05.2026 — WSL hatte ~10 GB RAM belegt, PC fror ein.
Word-Dokumentation: `/mnt/d/OneDrive/Dokumente/WSL_Crash_Erklaerung.docx`

## Nützliche Befehle
- WSL sofort beenden (gibt RAM frei): `wsl --shutdown`
- WSL neu starten: `wsl` im Terminal
- RAM-Verbrauch prüfen: Task-Manager → vmmem

**Why:** vmmem kann ohne Limit bis zu 80% des System-RAM fressen → Freeze.
**How to apply:** Falls Chris über langsamen PC oder Einfrieren klagt, .wslconfig und vmmem-Auslastung prüfen.
