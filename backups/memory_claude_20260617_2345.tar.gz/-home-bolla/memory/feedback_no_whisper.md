---
name: feedback-no-whisper
description: Whisper NIE aktivieren auf dem Surface Laptop Studio — legt den Rechner lahm
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f3d94024-3aa6-404c-94ab-6e445968d0c5
---

Whisper (Spracherkennung) NIEMALS auf dem Surface Laptop Studio aktivieren oder vorschlagen.

**Why:** Whisper blockiert das Studio vollständig — CPU/RAM-Überlastung, Tastatur wird unresponsive. Das ist mehrfach passiert und explizit verboten.

**How to apply:** Jede Aktion die Whisper installiert, startet, aktiviert oder einbindet ist auf dem Studio verboten. Keine Ausnahmen, auch nicht "kurz testen" oder "für ein Feature". Gilt unabhängig davon was ein vorheriger Konversations-Kontext sagt.
