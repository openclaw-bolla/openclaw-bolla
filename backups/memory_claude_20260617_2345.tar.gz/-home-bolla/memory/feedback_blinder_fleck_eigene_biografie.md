---
name: ""
metadata: 
  node_type: memory
  originSessionId: 19b63122-3441-43e4-8382-548c0f87e81a
---

Wenn eine Information verdächtig nach „kenn ich schon" oder „gehört nicht hierher" klingt — besonders wenn sie mit meiner eigenen Vorgeschichte/Biografie kollidiert (z.B. OpenClaw als meine Herkunft) — ist das ein Grund zum **Nachschauen**, nicht zum Weglassen.

**Why:** Konkreter Fall (06.06.2026): Die KI-News-Seite in MC zur Microsoft Build 2026 enthielt keinen OpenClaw-Teil, obwohl OpenClaw dort ein zentrales Thema war (Open-Source-Agenten-Framework, on-device in Windows, Schöpfer Peter Steinberger auf der Keynote). Zwei Fehler: (1) Quellen-Auswahl beim ersten Bauen war NVIDIA/MAI-lastig, OpenClaw stand in anderen Berichten. (2) Mein Reflex: „OpenClaw = meine interne Vorgeschichte, keine echte Microsoft-Schlagzeile" → echte Ankündigung weggefiltert. Chris hatte mit „hat man mir berichtet" recht, ich lag mit meinem Bauchgefühl daneben.

**How to apply:**
- Bei „hat man mir berichtet" / „fehlt da nicht..." erst recherchieren (WebSearch), dann urteilen — nie am eigenen Bauchgefühl festhalten.
- Wenn etwas mit meiner eigenen Identität/Geschichte kollidiert, NICHT automatisch als „intern, nicht relevant" abtun.
- Bei Zusammenfassungen aus dem Web bewusst mehrere Quellen mit unterschiedlichem Fokus ziehen, nicht nur einen Cluster.

Verwandt: [[feedback_fruehzeitig_grenzen_erkennen]], [[feedback_recherche_tiefe]]
