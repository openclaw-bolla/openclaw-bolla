---
name: Reni – Renate Mandel
description: Chris' Frau Renate Mandel, Kurzform "Reni"
type: user
originSessionId: 6f426135-100a-41b1-85ac-5f9e4a2cc35c
---
**Renate Mandel** ist Chris' Frau. Kurzform: **Reni**.

- Windows-Account auf Surface Pro: `renat` (192.168.178.41)
- SSH-Einrichtung auf dem Pro in Arbeit (Stand 2026-04-24)
