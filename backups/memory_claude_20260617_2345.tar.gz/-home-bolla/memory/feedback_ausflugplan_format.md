---
name: feedback-ausflugplan-format
description: "Wie Chris Ausflugspläne haben möchte — Karte + Tabelle, Menge stimmt"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: a0f612b2-6e93-4f64-a747-df49f6f592d7
---

Bei Ausflugsplänen / Sightseeing-Übersichten genau dieses Format verwenden:

- Nummerierte Marker (1–9 o.ä.) auf einer Karte (OSM-Tiles, Nominatim für Koordinaten)
- Dazu eine passende Tabelle mit kurzen Erklärungen zu jedem Highlight
- Übersicht und Quantität: nicht zu wenig, nicht zu viel — 7–10 Punkte ist ideal

**Why:** Chris hat den Flensburg-Plan (Mai 2026) explizit als "mega" gelobt — "genau so brauche ich das"

**How to apply:** Bei jeder Städte-/Ausflugplanung dieses Format als Standard verwenden, ohne nachzufragen.
