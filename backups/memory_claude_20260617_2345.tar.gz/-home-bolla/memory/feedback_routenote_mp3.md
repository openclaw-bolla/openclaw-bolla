---
name: RouteNote MP3 Format
description: Suno-MP3s müssen vor dem RouteNote-Upload konvertiert werden — immer 320kbps / 44.1kHz
type: feedback
originSessionId: dfa8875a-0ac2-4b8c-bbe7-b04d2c559b7d
---
RouteNote verlangt MP3s mit exakt **320kbps und 44.1kHz**. Suno liefert ~187kbps / 48kHz — das wird abgelehnt.

**Why:** Beim ersten Upload von "Iron Thunder" kam Upload-Fehler wegen falscher Bitrate/Samplerate.

**How to apply:** Vor jedem RouteNote-Upload alle MP3s konvertieren:
```bash
ffmpeg -i "input.mp3" -ar 44100 -b:a 320k "output_320.mp3" -y
```
Danach die Original-MP3s löschen, nur `_320.mp3` behalten. Cover-Art muss außerdem exakt **3000×3000px** sein (Pollinations liefert nur 768×768 → per Pillow hochskalieren).
