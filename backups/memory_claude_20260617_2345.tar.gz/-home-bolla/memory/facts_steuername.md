---
name: facts-steuername
description: Offizieller Steuer-/Bankname Chris — für amtliche Formulare (Steuer, Bank, Verlag)
metadata:
  node_type: memory
  type: user
---

# Offizieller Name für amtliche Formulare

- **Steuerlicher Vorname (Finanzamt / Steuer-ID): Christoph** — NICHT „Chris".
- Voller Name laut Unterlagen: **Ernst Christoph Mandel** (Mandel = Nachname).
- **Bankkonto (Deutsche Bank) lautet auf: Christoph Mandel.**
- „Chris" und „Ernst" sind die Namen, die er im Alltag/Mail nutzt (ernstmandel@outlook.de), aber für **W-8BEN, Bank, Steuer, Verlagsverträge** gilt **Christoph Mandel**.

**How to apply:** Bei offiziellen/finanziellen Formularen IMMER „Christoph Mandel" verwenden (Konsistenz W-8BEN ↔ Bank ↔ Steuer-ID), nicht „Chris". Siehe [[facts-kern]].
