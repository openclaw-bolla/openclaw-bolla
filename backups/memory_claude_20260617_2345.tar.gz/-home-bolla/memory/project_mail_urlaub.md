---
name: project_mail_urlaub
description: mail_to_calendar läuft nur auf Studio — bei Urlaub (Studio aus) gehen Termine verloren
metadata: 
  node_type: memory
  type: project
  originSessionId: 2470f4da-762c-47fe-9179-bb62cf000d86
---

mail_to_calendar.py schaut standardmäßig nur 1 Tag zurück. Bei Urlaub (Studio aus) werden Terminmails verpasst.

**Why:** Script läuft per Cron auf dem Studio — kein Studio = kein Scan.

**Geplante Lösungen (noch nicht implementiert, Urlaub noch nicht geplant):**
- **Option A (einfach):** Script merkt sich letzten erfolgreichen Lauf-Timestamp → schaut beim Start automatisch genau so weit zurück wie es weg war
- **Option B (robust):** Script auf Cloud-Server oder Router auslagern, läuft unabhängig vom Studio

**How to apply:** Wenn Urlaub konkreter wird, Option A oder B umsetzen. Option A ist schnell (paar Zeilen in mail_to_calendar.py), Option B mehr Aufwand.
