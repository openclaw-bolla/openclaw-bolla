---
name: Desktop-Dateien gehören auf den OneDrive-Desktop
description: Wenn etwas "auf den Desktop" soll, immer der OneDrive-Desktop (D:\OneDrive\Desktop), nicht der lokale C:\Users\ernst\Desktop
type: feedback
originSessionId: aurora-destyle-2026-06-17
---
Wenn eine Datei "auf den Desktop" gelegt werden soll, IMMER den OneDrive-Desktop nehmen — Chris' Windows-Desktop ist nach OneDrive umgeleitet. Der lokale `/mnt/c/Users/ernst/Desktop` ist tot, da sieht Chris nichts.

**Why:** Chris' Desktop ist OneDrive-umgeleitet. Ich habe 17.06.2026 das AURORA-Stilbeispiel nach C:\Users\ernst\Desktop geschrieben — Chris sah es nicht ("Onedrive schon wieder vergessen?"). Ist schon mehrfach passiert.
**How to apply:** Ziel ist `/mnt/d/OneDrive/Desktop/` (Haupt-OneDrive lt. CLAUDE.md). Es existiert auch `/mnt/c/Users/ernst/OneDrive/Desktop/` — im Zweifel in beide kopieren. Zum Öffnen den D:\OneDrive\Desktop-Pfad nehmen. Verwandt: [[feedback_datei_speicherort]] (Dokumente → OneDrive/Dokumente/Bolla).
