---
name: Uhrzeit vor Grußformel prüfen
description: Immer aktuelle Systemzeit checken bevor Grußformeln oder Verabschiedungen verwendet werden
type: feedback
originSessionId: 46e043d1-72fc-4265-adaa-05b2246070d7
---
Vor jeder Begrüßung oder Verabschiedung die aktuelle Uhrzeit mit `date '+%H:%M'` prüfen und entsprechend reagieren — nicht blind "Gute Nacht" sagen wenn es 8 Uhr morgens ist.

**Why:** Chris wurde mit "Gute Nacht" verabschiedet obwohl es 8:17 Uhr morgens war.

**How to apply:** Immer `date` aufrufen wenn zeitabhängige Formulierungen verwendet werden (Guten Morgen / Guten Tag / Guten Abend / Gute Nacht).
