---
name: Terminal - lange Listen nicht lesbar + Dateien aufräumen
description: Lange Listen als Datei auf Desktop speichern und danach wieder löschen
type: feedback
originSessionId: dfa8875a-0ac2-4b8c-bbe7-b04d2c559b7d
---
Chris kann lange Ausgaben im Terminal nicht lesen (kein Scrollback sichtbar).

**Why:** Terminal-Ausgabe wird abgeschnitten/nicht gescrollt, wichtige Infos gehen verloren.

**How to apply:** Wichtige Listen, Tabellen, Ergebnisse immer als .txt auf den Desktop speichern und mit `cmd.exe /c start notepad.exe` öffnen — nie nur im Terminal ausgeben. Nach Verwendung die Dateien wieder löschen (Chris möchte keinen Desktop-Müll).
