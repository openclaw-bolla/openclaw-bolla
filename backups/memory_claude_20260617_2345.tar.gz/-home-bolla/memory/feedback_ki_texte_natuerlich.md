---
name: KI-Texte natürlich klingen lassen
description: Wenn Texte für Chris oder in seinem Namen produziert werden, müssen sie menschlich klingen — keine KI-typischen Floskeln, keine strukturellen Doppelungen
type: feedback
originSessionId: 392e2e08-0564-42ef-9c3b-3e90798109e6
---
Wo immer Texte entstehen, die nicht wie KI klingen sollen (E-Mails, Elternbriefe, MC-Outputs), aktiv auf folgende KI-Marker achten und vermeiden:

**Typische KI-Tells:**
- Immer gleiche Einstiege ("Ich verstehe Ihre Bedenken", "Vielen Dank für Ihre Nachricht", "Zunächst möchte ich...")
- Parallele Absatzstruktur — jeder Absatz fängt gleich an
- Übermäßig ausgewogene Drei-Punkte-Listen
- Übergänge wie "Darüber hinaus", "Abschließend", "In diesem Sinne"
- Immer gleiche Briefschlüsse ("Ich stehe Ihnen jederzeit zur Verfügung", "Mit freundlichen Grüßen")

**Was zu tun ist:**
- Prompt explizit anweisen: kein Floskelstart, Struktur variieren, klingt wie echter Mensch
- Bei mehreren Outputs im gleichen Tool: Varianten aktiv erzwingen ("Beginne NICHT mit X")
- Kurze, direkte Sätze mischen mit längeren — kein gleichmäßiger Rhythmus
- Manchmal mitten im Satz einsteigen statt mit Anrede

**Wann anwenden:**
- E-Mail-Antworten, die Chris verschickt
- Elternbriefe / Lehrerkorrespondenz
- Alle MC-Features die Text "für jemanden" erzeugen
- NICHT bei rein informativen Ausgaben (Korrektur-Ergebnisse, API-Antworten)

**Why:** Chris ist aufgefallen dass beide Elternbrief-Entschärfer-Outputs mit exakt denselben Floskeln begannen und strukturell identisch waren — für reale Verwendung nicht glaubwürdig.

**How to apply:** In jedem Prompt der "echte" Texte erzeugt: explizit Anti-KI-Anweisungen einbauen. Eigene Ausgabe vor dem Senden kurz gegenprüfen.
