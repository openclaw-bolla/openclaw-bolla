---
name: project_surface_book
description: "Surface Book Akku-Problem, Boot-Fix, SSH-Diagnose — alles was bei Problemen sofort bekannt sein muss"
metadata: 
  node_type: memory
  type: project
  originSessionId: ddb698ce-8e5e-4a23-9905-6d99260a7483
---

# Surface Book — Dauerproblem Akku & Boot

## Das Gerät
- Surface Book (Chris' Schulrechner, Hostname: Chris_Surface_B, User: ernst)
- SSH-Zugang: Port 2222 über Reverse Tunnel (siehe [[reference_technical]])

## Kernproblem: Akku 1 ist defekt
- Akku 1 (`ACPI\PNP0C0A\1`) ist physisch kaputt — verursacht Boot-Loops, Aufwach-Probleme, Systemabstürze
- **Lösung:** Akku 1 per `Disable-PnpDevice` deaktiviert → Windows sieht nur noch Akku 0
- Akku 0 (ID: `6142SMPX906980`) ist der gesunde, funktioniert normal

## Angewendete Fixes (alle aktiv, Stand 27.05.2026)

### Fix 1: Akku 1 deaktiviert
```powershell
Disable-PnpDevice -InstanceId "ACPI\PNP0C0A\1" -Confirm:$false
```
Status prüfen:
```powershell
$d = Get-PnpDevice -InstanceId "ACPI\PNP0C0A\1"
Write-Host $d.Status $d.Problem
# Soll sein: Error / CM_PROB_DISABLED
```

### Fix 2: HiberbootEnabled = 0
- Fast Startup (Hybrid Boot) deaktiviert — verhindert Boot-Probleme nach Updates
- Registry: `HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power\HiberbootEnabled = 0`
- **Überlebt Windows Updates** via Scheduled Task `BollaKeepHiberbootOff` (läuft als SYSTEM)

### Fix 3: CPU-Fresser dauerhaft deaktiviert
- Windows Search (WSearch): `Disabled`
- Windows Widgets: Policy `AllowNewsAndInterests=0` + WebExperience Pack entfernt

## Diagnose bei neuen Problemen (Checkliste per SSH)

```powershell
# 1. Akku 1 noch deaktiviert?
$d = Get-PnpDevice -InstanceId "ACPI\PNP0C0A\1"
Write-Host "Akku1:" $d.Problem   # Soll: CM_PROB_DISABLED

# 2. HiberbootEnabled noch 0?
(Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power" -Name HiberbootEnabled).HiberbootEnabled
# Soll: 0

# 3. Scheduled Task aktiv?
(Get-ScheduledTask -TaskName "BollaKeepHiberbootOff").State
# Soll: Ready
```

## Wenn Akku 1 wieder aktiviert wurde (z.B. nach Windows Update)
```powershell
Disable-PnpDevice -InstanceId "ACPI\PNP0C0A\1" -Confirm:$false
```
→ Kein Neustart nötig, wirkt sofort.

## Bekannte Eigenheiten
- Nach ~20 Min Akkubetrieb + Transport: gelegentlicher Standby-Schluckauf beim Strom-Einstecken → einmaliger Force-Reset (15 Sek Power + Lautstärke hoch) löst das
- Windows Update kann HiberbootEnabled kurz zurücksetzen — Task korrigiert das bei nächstem Start
- Akku 1 wird durch Windows Updates NICHT wieder aktiviert (getestet 27.05.2026)

**Why:** Akku 1 ist physisch defekt und verursacht seit Wochen Boot-Loops und Absturz-Probleme in der Schule.
**How to apply:** Bei jedem Surface Book Problem zuerst diese Checkliste per SSH abarbeiten, bevor neue Hypothesen aufgestellt werden.
