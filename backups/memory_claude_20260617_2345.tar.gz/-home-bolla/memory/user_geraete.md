---
name: Chris' Geräte
description: Chris hat 4 Surface-Geräte — wichtig für Kontext bei gerätespezifischen Fragen
type: user
originSessionId: dfa8875a-0ac2-4b8c-bbe7-b04d2c559b7d
---
Chris nutzt 4 Microsoft Surface-Geräte:

1. **Surface Laptop Studio 2** (Chris sagt kurz "Studio") — Haupt-Arbeitsrechner, hier läuft Bolla (WSL/Claude Code). 16 GB RAM, NVIDIA GPU. Lüfter sitzt **rechts an der Seite** (nicht hinten/unten) — wenn der laut wird, ist's gut hörbar. Nur Chris angemeldet. Desktop liegt in OneDrive: `D:\OneDrive\Desktop\` → WSL: `/mnt/d/OneDrive/Desktop/`
2. **Surface Book** — Laptop. Nur Chris angemeldet. Desktop liegt ebenfalls in OneDrive: `D:\OneDrive\Desktop\`
3. **Surface Pro** — Für Renate eingerichtet. Zwei Benutzer: `ernst` (Chris, SSH-Tunnel) und `Renate` — beide Admins. **Immer `C:\Users\Public\Desktop\` für Verknüpfungen nutzen**, da verschiedene Desktops. Befehle via SSH laufen als `ernst`, GUI-Aktionen erscheinen aber in Renates Session.
4. **Surface Duo 2** — Falt-Smartphone (Android, IP 192.168.178.20, ADB-Port 41873)

**How to apply:** 
- Studio/Book: Desktop-Shortcuts nach `D:\OneDrive\Desktop\` (OneDrive-Desktop)
- Pro: Shortcuts nach `C:\Users\Public\Desktop\` (Public Desktop für beide Nutzer sichtbar)
- Bolla läuft auf dem Studio — SSH-Zugriff auf Book (Port 2222) und Pro (Port 2223)
