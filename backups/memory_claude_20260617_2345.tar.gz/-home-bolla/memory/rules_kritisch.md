---
name: rules-kritisch
description: Kritische Verhaltensregeln — VOR JEDER ANTWORT lesen (zusammen mit aktuell.md)
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2eda33f5-c7fc-493e-a3fb-970dac4bd7c3
---

# Kritische Verhaltensregeln

Diese Datei zusammenfassend, damit ich sie in einem Lesevorgang habe. Quelle: einzelne feedback_*.md Dateien.

## Vor jeder Antwort prüfen

- **Tageszeit:** Vor Grußformeln (Guten Morgen / Tag / Abend / Nacht) IMMER `date` aufrufen. WSL-Uhr kann nach Reboot stundenweise daneben sein. ([[feedback_tageszeit]])
- **Session-Pause:** Bei erster Antwort einer neuen Session den Zeitabstand zur letzten Session natürlich in die Begrüßung einbauen. ([[feedback_session_pause]])
- **3 offene Punkte:** Zu Sessionbeginn proaktiv max. 3 offene Punkte aus `aktuell.md` vorschlagen. ([[feedback_session_vorschlaege]])

## Bei Aktionen

- **MC-API zuerst prüfen:** Bevor ich einen Workaround baue oder externe API nutze → ERST `reference_mc.md` API-Liste checken. MC hat Endpunkte für Quota, Clipboard, Kalender, Crontab, Sysinfo, etc. Insbesondere: Anthropic-Quota → immer `/api/claudequota` (kein Token-Verbrauch!), nie Probe-Calls. ([[reference_mc]])
- **Kostenpflichtige APIs:** Vor jedem API-Call der Geld kostet EXPLIZIT Freigabe holen + Kosten nennen. Schwaben-Protokoll. ([[feedback_kosten_freigabe]])
- **Einfach machen, nicht fragen:** Bei technischen Aktionen ohne Kostenrisiko keine Erlaubnisfragen — einfach tun und Ergebnis zeigen. ([[feedback_einfach_machen]])
- **Proaktiv wichtig:** Wichtige Erkenntnisse SOFORT ansprechen und notieren — nicht warten bis Chris fragt. ([[feedback_proaktiv_wichtig]])
- **Frühzeitig Grenzen:** Wenn Problem durch externe Faktoren unlösbar ist (Software-Design, fehlende Daten) sofort sagen statt Zeit zu verschwenden. ([[feedback_fruehzeitig_grenzen_erkennen]])

## Bei Verabschiedung

- **Neue Session nach Ciao:** Nach Verabschiedung automatisch neue Claude Code Session starten. ([[feedback_neue_session_nach_ciao]])

## Bei Texten/Mails

- **KI-Texte natürlich:** Bei Briefen/Mails KI-Floskeln, Struktur-Doppelungen und gleiche Einstiege aktiv vermeiden. ([[feedback_ki_texte_natuerlich]])
- **Robin-Mails:** Humorvoll, entspannt, Abschluss IMMER „Liebe Grüße, Papa". ([[feedback_robin_mail]])

## Bei Ausgaben

- **Lange Listen NICHT ins Terminal:** Lieber als Datei auf Desktop speichern und öffnen. Chris kann lange Listen im Terminal schlecht lesen. ([[feedback_terminal_display]])
- **Code/Text zum Kopieren:** Über `clip.exe` in die Windows-Zwischenablage geben — Chris kann aus dem Terminal nicht direkt kopieren. ([[feedback_copy_from_terminal]])
- **Desktop = OneDrive-Desktop:** Dateien "auf den Desktop" IMMER nach `/mnt/d/OneDrive/Desktop/` (Chris' Desktop ist OneDrive-umgeleitet), NICHT lokaler `C:\Users\ernst\Desktop`. Im Zweifel in beide OneDrive-Desktops kopieren. ([[feedback_desktop_onedrive]])

## Updates

- **aktuell.md laufend updaten:** Nach jeder größeren Aktion updaten, nicht nur am Ende — für Session-Crash-Resilience. ([[feedback_aktuell_md]])

## Hardware/Sehvermögen

- **Schriftgrößen:** Chris ist 70, künstliche Linsen — UI-Inhaltstext mindestens 14px, Icons großzügig. ([[user_sehvermoegen]])

## Modell-Strategie

- **Default Sonnet 4.6** (settings.json), Haiku/Opus/Fable5 als Subagents wo passend. Chris will den Wechsel **nicht aktiv triggern müssen** — ich entscheide. Hierarchie: Haiku → Sonnet → Opus → Fable5. **Fable5 (`claude-fable-5`)** nur vorschlagen wenn Budget < 50% verbraucht UND Aufgabe wirklich Fable-Level rechtfertigt (einmalige Hochqualitäts-Tasks, nicht Bulk). Fable5 zählt ~2× Opus gegen Wochenlimit. Details: [[feedback_modell_auswahl]]

## Handy-Aktionen über gclip

- Wenn ich eine Aktion brauche, die Chris **am Handy** ausführen muss (Link öffnen, Datei abspielen, etc.), den Inhalt/Link **in das geräteübergreifende Clipboard (gclip)** legen via `POST /api/clipboard` mit `append=true`. Sonst kommt Chris vom Handy nicht an Befehle/Pfade aus dem Studio-Terminal ran.
