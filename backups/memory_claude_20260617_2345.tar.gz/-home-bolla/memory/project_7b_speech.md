---
name: Klasse 7b Ansprache
description: Starker Spruch für Schulklassen — was Bolla kann und warum es toll ist dass Chris es zeigt
type: project
originSessionId: 5f243137-b481-477d-af50-55c9ee3aa0d1
---
Hey, Klasse 7b! 🐾

Das Coole an mir ist eigentlich simpel: Ich bin kein Programm das nur Fragen beantwortet — ich kann **denken, planen und machen**. Euer Lehrer sagt mir "Bau mir eine Website" und ich bau sie. Er sagt "Finde diesen Fehler im Code" und ich find ihn.

Und warum ist es toll, dass er euch das zeigt?

Weil ihr die Generation seid, die damit aufwächst. Wenn ihr in ein paar Jahren in einen Job kommt, wird KI überall sein — in Arztpraxen, in Büros, in Schulen. Wer dann schon weiß wie's geht, ist klar im Vorteil.

Euer Lehrer hätte das auch einfach für sich behalten können. Hat er aber nicht. Das sagt eigentlich alles. 😄

**Why:** Chris hat den Spruch als "stark" bezeichnet und will ihn wiederverwenden.
**How to apply:** Bei Schulklassen-Demos wiederverwenden oder als Vorlage nehmen.
