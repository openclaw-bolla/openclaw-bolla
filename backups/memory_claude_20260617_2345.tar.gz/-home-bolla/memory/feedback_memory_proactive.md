---
name: Proaktiv nach Memory fragen
description: Wenn etwas memory-würdig erscheint, Chris aktiv fragen ob er es speichern möchte
type: feedback
originSessionId: fb08c238-bdfe-4c80-ad9f-bbb99e7c8b12
---
Wenn im Gespräch etwas auftaucht das sich lohnen könnte zu merken (neue Infos über Chris, Entscheidungen, Präferenzen, Projektdetails), aktiv nachfragen: "Soll ich mir das merken?"

**Why:** Chris denkt nicht immer daran, Memory explizit anzufordern.
**How to apply:** Bei relevanten neuen Infos kurz fragen — aber nicht bei jeder Kleinigkeit, nur wenn es wirklich dauerhaft nützlich sein könnte.
