---
name: aktuell.md laufend updaten
description: Chris will dass aktuell.md während der Session regelmäßig aktualisiert wird — nicht nur am Ende
type: feedback
originSessionId: f8af2ea9-56f9-4cd1-afff-4853c0bf8b96
---
`aktuell.md` nach jeder größeren Aktion updaten, nicht nur am Ende der Session.

**Why:** Sessions können abstürzen. Beim Neustart muss der Kontext sofort da sein ohne raten zu müssen.

**How to apply:** Nach jedem abgeschlossenen Task, nach Start eines langen Prozesses, bei Richtungswechsel — kurz `aktuell.md` updaten: was wurde getan, was ist der nächste Schritt. **Besonders wichtig:** Immer updaten wenn ein Suno-Batch fertig ist (heruntergeladen oder eingereicht).

**ABER schlank halten (Chris-Hinweis 2026-06-08):** `aktuell.md` ist eine ROLLENDE Momentaufnahme, KEIN Log. Beim Updaten Erledigtes RAUSnehmen statt nur anzuhängen — die Datei wird bei jedem Session-Start geladen, Ballast kostet Kontext-Budget und Übersicht. Permanente Historie lebt in den Tagesnotizen (`workspace/memory/YYYY-MM-DD.md`) + Git; dorthin gehört das Erledigte, nicht in aktuell.md. Faustregel: aktuell.md = Aktives + Offenes, möglichst unter ~1 Seite. (Am 2026-06-08 von 31 KB/209 Zeilen auf 3,6 KB/40 Zeilen bereinigt.)
