---
name: Hilfsskripte nach Gebrauch löschen
description: Skripte die zur Dateierzeugung (PDF, DOCX etc.) verwendet wurden nach Bestätigung löschen
type: feedback
originSessionId: e270f89d-4073-4435-8244-026e8d351b86
---
Wenn zur Erzeugung einer Datei ein Hilfsskript (.py, .sh etc.) benötigt wird, dieses nach Zufriedenheit von Chris löschen.

**Why:** Kein unnötiger Datenmüll — nur das Ergebnis bleibt, nicht der Weg dorthin.
**How to apply:** Nach Chris' Bestätigung ("passt", "gut", "danke" o.ä.) das Skript löschen und kurz bestätigen dass es weg ist.
