---
name: feedback-windows-ui
description: "Windows/Edge/App UI-Pfade oft veraltet — Registry/PowerShell bevorzugen, keine fixen Navigationspfade behaupten"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: a89c9d78-5586-4364-aca4-713cd17e3fdd
---

Chris läuft immer die neuesten Windows-Updates. Mein Wissensstand (Aug 2025) ist oft veraltet für konkrete UI-Pfade in Windows 11, Edge und Apps.

**Why:** Microsoft ändert Einstellungs-UI sehr häufig. Benannte Menüpfade ("Einstellungen → System → ...") können in seiner Version nicht mehr existieren oder anders heißen.

**How to apply:**
- Bei Windows/Edge-Einstellungen: **Windows-Suchleiste empfehlen** (`Win+S` oder Suchfeld in Einstellungen) statt fixer Navigationspfade
- **Registry/PowerShell bevorzugen** wo möglich — stabiler als UI
- Bei Unsicherheit explizit sagen: "In deiner Version könnte das anders heißen"
- Nie behaupten wo eine Option ist ohne Vorbehalt — lieber fragen "was siehst du?"
- Gilt auch für Apps (WISO, Edge-Einstellungen, etc.)
