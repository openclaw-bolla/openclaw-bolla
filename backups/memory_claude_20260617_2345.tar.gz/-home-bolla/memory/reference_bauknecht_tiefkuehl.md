---
name: reference_bauknecht_tiefkuehl
description: Bauknecht Tiefkühlschrank — Display-Tasten und Bedienung
metadata: 
  node_type: memory
  type: reference
  originSessionId: cea5730f-cbdf-439f-abe2-64dd46f1b94e
---

# Bauknecht Tiefkühlschrank — Tastenbedienung

## Display
- Grüne Ziffernanzeige (z.B. "-16")
- Grüner Pfeil nach unten neben der Zahl = Gerät kühlt aktiv auf Zieltemperatur

## Tasten (von links nach rechts)

1. **°C-Taste** — Temperatur einstellen (+ und - zum Hoch-/Runterregeln)
2. **Thermometer-Taste** (leuchtet orange/gelb wenn aktiv) — Betriebsmodus
3. **Schlüssel-Taste** 🔑 — **Tastensperre (Kindersicherung)**

## Wichtige Hinweise

- **Werkseinstellung:** -18°C
- **Tastensperre aktiv** → °C-Taste lässt sich nicht drücken (passiert schnell aus Versehen)
- **Sperre aufheben:** Schlüssel-Taste **3–5 Sekunden gedrückt halten** → Display blinkt kurz → entsperrt
- Danach mit °C-Taste auf gewünschte Temperatur einstellen (z.B. mehrfach drücken bis -18 erscheint)
- Aus- und Einschalten hebt die Tastensperre NICHT auf

## Symptom → Lösung

| Symptom | Ursache | Lösung |
|---|---|---|
| Temperaturtaste reagiert nicht | Tastensperre aktiv | Schlüssel 3–5 Sek. halten |
| Temperatur zu hoch (z.B. -11 statt -18) | Jemand hat verstellt oder Sperre war offen | Entsperren, dann auf -18 stellen |
| Grüner Pfeil neben Anzeige | Gerät kühlt aktiv | Normal — warten bis Zieltemp. erreicht |
