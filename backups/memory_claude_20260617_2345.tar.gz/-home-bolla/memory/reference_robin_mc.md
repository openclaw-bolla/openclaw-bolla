---
name: Robin Mission Control URL
description: Öffentliche URL von Robins Mission Control (Cloudflare Tunnel)
type: reference
originSessionId: 2305f4c2-ac77-421c-844a-76f5b6d04dd8
---
Robins Mission Control ist erreichbar unter: **https://mc.robinmandel.de**

Cloudflare Access läuft über `robinmandel.cloudflareaccess.com`.
