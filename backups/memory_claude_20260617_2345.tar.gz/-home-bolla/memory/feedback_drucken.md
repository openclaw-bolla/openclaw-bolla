---
name: Drucken — Format und Drucker
description: Wie Chris drucken lässt und welches Format er erwartet
type: feedback
originSessionId: 080984ef-5d04-4952-965e-dd355c159d3f
---
Beim Drucken immer Word-COM-Format verwenden (nicht Out-Printer — das ist unleserlich).

**Why:** Out-Printer gibt nur blanken Text aus, zu klein und keine Schriftgestaltung. Chris hat Word-Format explizit als Standard bestätigt.

**How to apply:** Bei jedem Druckauftrag automatisch Word COM benutzen:
- Schrift: Calibri
- Titel: 22pt, fett
- Abschnittsüberschriften: 13pt, fett, farbig (ColorIndex 3)
- Zeilen: Label 11pt fett, Beschreibung 11pt normal grau
- Fußzeile: 9pt grau mit Datum

Drucker: `HPCE59BF (HP ENVY Inspire 7900 series)` — WiFi, über Windows erreichbar via PowerShell Word-COM.

Chris sagt **"drucke das"** oder **"wie vorhin"** = immer dieses Format.
