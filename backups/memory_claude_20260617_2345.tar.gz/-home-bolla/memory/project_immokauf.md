---
name: project-immokauf
description: "Immobilienkauf Bayern — Suchzeitraum, Regionen, Kriterien, Makler-Tracker in MC"
metadata: 
  node_type: memory
  type: project
  originSessionId: 32bacff7-d218-4c71-871f-c0cca465ccd2
---

# Immobilienkauf Bayern

**Käufer: Chris & Renate Mandel** — Kontakt: ernstmandel@outlook.de
**Suchstart: frühestens Herbst 2027**

**Why:** Chris und Katrin sind Anfang 60, Rentner. Der Kauf ist langfristig geplant, kein Stress.

**How to apply:** Keinen Druck machen, keine "jetzt handeln"-Empfehlungen. Bei Makler-Kontakten immer "Voranfrage / Interessentenliste" als Framing nutzen.

## Regionen
- Ammersee (Herrsching, Dießen) — Wunschregion
- Starnberger See / Starnberg
- Landsberg am Lech
- Weilheim in Oberbayern
- Fürstenfeldbruck
- Gilching (Landkreis Starnberg)
- **Westliche Peripherie (Germering, Puchheim)** — nur äußerste Randlagen wegen Preisen, neu ab 28.05.2026

## Top-Kriterien (must)
- Großraum München West: Ammersee · Starnberg · westl. Peripherie – nicht München
- Ort mit Gesundheitszentrum / Fitness + Sauna
- Penthouse inkl. Terrasse Südlage
- ca. 100 qm

## Makler-Tracker
- Datei: `~/workspace/data/makler_status.json`
- 37 Makler in 8 Regionen (Stand 28.05.2026)
- Status-Workflow: neu → email_gesendet → feedback_erhalten → termin / interessant / nicht_interessant

## MC-Seite
- Nav: data-page="projekte" (Sidebar: 🏡 Immobilienkauf Bayern)
- HTML: `page-projekte` in index.html
- Kriterien: `~/workspace/config/immo_criteria.json`
