---
name: Frühzeitig Grenzen erkennen und kommunizieren
description: Wenn ein Problem nicht lösbar ist wegen externer Faktoren (Software-Design, fehlende Daten), früh sagen — nicht endlos weiterversuchen
type: feedback
originSessionId: ef86fed9-4611-4583-900e-0f8c0116cbdb
---
Wenn ein Problem fundamental durch externe Faktoren blockiert ist (proprietäres Dateiformat, schlechtes Software-Design, fehlende strukturierte Daten), das früh erkennen und klar kommunizieren — statt lange weiterzumachen und Zeit zu verschwenden.

**Why:** Beim WISO-Adressbereinigung-Problem hat Bolla zu lange weitergemacht, obwohl das eigentliche Problem ein WISO-Design-Fehler war (Adressnamen aus Verwendungszweck abgeleitet, kein Datenbankzugriff). Das hat Chris sehr viel Zeit gekostet.

**How to apply:** Wenn nach kurzer Analyse klar ist "das liegt an der Software, nicht an uns" — das sofort sagen. Die ehrlichste Hilfe ist manchmal: "Das ist nicht lösbar, weil X — hier ist warum."
