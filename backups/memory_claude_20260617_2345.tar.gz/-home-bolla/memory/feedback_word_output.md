---
name: Word-Ausgaben Layoutregel
description: Ziel für Word/docx-Ausgaben: kompakt auf eine Seite, 2-Spalten wenn sinnvoll
type: feedback
originSessionId: 27bdbc7b-4e9a-4642-a895-df7c4ce6dd2e
---
Alle Word-Dokumente die Bolla erstellt sollen grundsätzlich auf **eine A4-Seite** passen.

Mittel dafür:
- Enge Ränder (1.5–1.8 cm statt Standard 2.54 cm)
- Kleinere Schrift (10pt statt 11pt)
- 2-Spalten-Tabellen wo sinnvoll (z.B. Zutaten + Bild links | Zubereitung rechts)
- Kompakte Zeilenabstände, keine leeren Paragraphen verschwenden
- Bild einbinden aber klein halten (max. 5 cm breit im Seitenlayout)

**Ausnahme:** Technische Erklärungen (Setup-Anleitungen, API-Doku, Schritt-für-Schritt-Guides) — dort ist Komprimierung kontraproduktiv, Lesbarkeit geht vor.

**Why:** Chris explizit so gewünscht — "bei Word-Ausgaben eine Seite, Ausnahme technische Erklärungen wo Komprimierung kontraproduktiv wäre"

**How to apply:** Bei allen zukünftigen docx-Erstellungen: Rezepte, Stundenpläne, Zusammenfassungen, Listen → 1 Seite. Technische Doku → Lesbarkeit first.
