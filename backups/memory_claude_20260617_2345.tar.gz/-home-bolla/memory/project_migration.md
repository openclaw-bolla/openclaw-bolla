---
name: Migration OpenClaw zu Claude Code
description: Chris wechselt von OpenClaw zu Claude Code (April 2026)
type: project
originSessionId: 0624e501-3f9d-46a0-ac81-c93cf602fcb5
---
## Migration (10.04.2026)
- Chris hat von OpenClaw auf Claude Code gewechselt
- OpenClaw-Memory und Konfiguration wurden übertragen
- Bisheriger KI-Assistent hieß "Bolla" (Name, Telegram-Bot etc.)
- OpenClaw hatte: Telegram-Integration, E-Mail via Graph API, Token Watcher, Autostart
- Claude Code hat andere Architektur — nicht alle Features 1:1 übertragbar

**Why:** Umstieg war dringend nötig (Chris' Aussage)
**How to apply:** Bei Fragen zu alten Funktionen: erklären was in Claude Code möglich ist und was anders läuft
