---
name: Suno API Endpoint
description: Aktuelle Suno API Base-URL und Token-Methode (Stand Mai 2026)
metadata:
  type: reference
---
# Suno API (Stand 2026-05-15)

## Base URL
`https://studio-api-prod.suno.com` ← NEU! (alte `.ai` Domain ist suspended)

## Wichtige Endpoints
- Songs liste: `GET /api/feed/?page=0&page_size=20`
- (weitere Endpoints noch nicht erforscht)

## Auth
Bearer Token (Clerk JWT) aus Browser-Konsole auf suno.com:
```javascript
fetch('https://auth.suno.com/v1/client',{credentials:'include'}).then(r=>r.json()).then(d=>{const sess=d.response?.sessions||[];sess.forEach(s=>{const tok=s.last_active_token?.jwt||'';if(tok)console.log('TOKEN:'+tok)});})
```
→ Token in `/tmp/suno_token.txt` speichern

## Token Gültigkeit
~1 Stunde (Clerk JWT)

## Hinweis
`studio-api.suno.ai` (alt) → "Service Suspended" (Cloudflare)
`studio-api-prod.suno.com` (neu) → funktioniert ✅
Rate Limit: ~17 Seiten à 20 Songs ohne Pause → danach 429
Mit 0.3s Pause: ~13 Seiten zuverlässig
