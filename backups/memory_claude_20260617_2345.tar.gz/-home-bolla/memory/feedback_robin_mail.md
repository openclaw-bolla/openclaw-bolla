---
name: Mails an Robin – Stil
description: Wie Chris Mails an seinen Sohn Robin formuliert haben möchte
type: feedback
originSessionId: 392e2e08-0564-42ef-9c3b-3e90798109e6
---
Mails an Robin immer **humorvoll und entspannt** formulieren — locker, familiär, kein förmlicher Ton.

Abschluss immer: **„Liebe Grüße, Papa"**

**Why:** Chris hat explizit gesagt, er möchte natürliche Vater-Sohn-Kommunikation, keine steife Mail.
**How to apply:** Bei jeder Mail an Robin (robinmandel@outlook.de oder andere Robin-Adressen) locker formulieren und mit „Liebe Grüße, Papa" abschließen.
