---
name: Websites immer auf Deutsch
description: Chris nutzt bei allen Websites mit deutscher Sprachoption die deutsche Version — Anleitungen/Menü-Pfade entsprechend in Deutsch geben
type: feedback
originSessionId: f1d60c97-2496-4780-9dfd-8b9a6a8d64c3
---
Bei allen Websites/Diensten, die eine deutsche Sprachoption haben, nutzt Chris die **deutsche Version** (Cloudflare, Microsoft 365, Google, GitHub mit deutscher UI soweit möglich, etc.).

**Why:** Chris liest auf Deutsch schneller und will nicht zwischen Sprachen wechseln müssen. Hat er beim Cloudflare-Beispiel direkt gesagt: "cloudflare ist bei mir deutsch wo ist das".

**How to apply:** Wenn ich Klick-Anleitungen, Menü-Pfade, Button-Namen oder UI-Elemente nenne, **immer die deutschen Bezeichnungen** verwenden. Bei Tools die sowohl deutsche als auch englische Begriffe haben (z.B. AWS, Cloudflare, Microsoft-Produkte), Deutsch bevorzugen. Wenn ich unsicher bin welcher deutsche Begriff stimmt, lieber "Menüpunkt XY (engl. 'ZZ')" schreiben, statt nur Englisch. Produktnamen (z.B. "Zero Trust") bleiben wie sie sind.
