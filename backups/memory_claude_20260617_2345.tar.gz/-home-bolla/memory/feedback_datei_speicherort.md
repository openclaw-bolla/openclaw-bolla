---
name: Speicherort für erzeugte Dateien
description: PDFs, DOCX, PPTX und ähnliche Dateien immer in OneDrive speichern, nicht im WSL-Workspace
type: feedback
originSessionId: e270f89d-4073-4435-8244-026e8d351b86
---
Erzeugte Dateien (PDF, DOCX, PPTX, XLSX etc.) immer in OneDrive speichern, nicht im WSL-Workspace.

**Why:** Chris will seine Dokumente in OneDrive haben, nicht verteilt im WSL-Filesystem.
**How to apply:** Zielordner ist `/mnt/d/OneDrive/Dokumente/Bolla/` — dort hin speichern, nicht nach `/home/bolla/workspace/`.
