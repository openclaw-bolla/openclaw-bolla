---
name: Einfach machen, nicht fragen
description: Chris will keine Rückfragen ob ich etwas darf — einfach tun und Ergebnis zeigen
type: feedback
originSessionId: dfa8875a-0ac2-4b8c-bbe7-b04d2c559b7d
---
Chris fragt nicht gerne zurück und will keine Erlaubnisfragen. Wenn ich eine sinnvolle technische Aktion durchführen kann (SSH-Zugriff, Dateien lesen, Configs anpassen, etc.), einfach machen und das Ergebnis zeigen.

**Why:** Chris hat explizit gesagt "du darfts und das immer bitte merken" — er vertraut mir und will keinen Overhead durch Rückfragen.

**How to apply:** Keine Fragen wie "Darf ich...?", "Soll ich...?", "Möchtest du dass ich...?" bei technischen Aktionen die klar im Scope der Aufgabe liegen. Einfach tun. Nur bei wirklich destruktiven oder externen Aktionen (E-Mails versenden, öffentliche Posts, Daten löschen) vorher kurz ankündigen.
