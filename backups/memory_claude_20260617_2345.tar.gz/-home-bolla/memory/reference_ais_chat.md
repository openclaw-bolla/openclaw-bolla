---
name: reference_ais_chat
description: AIS.chat — kostenlose KI-Plattform für Schulen in Schleswig-Holstein (früher Telli)
metadata: 
  node_type: memory
  type: reference
  originSessionId: 3d3faad7-f084-4714-893e-60073ca2c151
---

## AIS.chat — KI für Bildung in Schleswig-Holstein

- **URL:** ais.chat
- **Früher bekannt als:** Telli / Telli SH
- **Kostenlos** für Lehrer und Schüler in Schleswig-Holstein
- **DSGVO-konform** — läuft auf SH-Bildungsserver
- **Genutzte Modelle:** GPT-4o, Claude 3 Sonnet, Gemini Pro (je nach Auswahl)

## Verwendung in Chris' KI-Workshop
- Erwähnt im Workshop-Thema: "Telli SH" → jetzt AIS.chat
- In PPT `KI_fuer_Lehrer.pptx` Slide 1 unter "🟡 Gratis-Modelle" (Stand 29.05.2026)
- In Word `KI_ShortTrack_Prompts.docx` als Themenblock 4 beschrieben

**How to apply:** Bei Fragen von Chris zu KI-Plattformen für Lehrer → AIS.chat nennen, nicht Telli.
