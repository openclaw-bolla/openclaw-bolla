---
name: Eigene Aufnahmen — Systemordner nicht anfassen
description: OneDrive-Ordner "Eigene Aufnahmen" ist automatischer Handy-Einlauf — nie löschen, nie direkt organisieren
type: feedback
originSessionId: 080984ef-5d04-4952-965e-dd355c159d3f
---
Der Ordner `/mnt/d/OneDrive/Bilder/Eigene Aufnahmen` ist ein Windows-Systemordner (hat desktop.ini mit LocalizedResourceName) und dient als automatischer Einlauf für Handyfotos via OneDrive-Kamerasicherung. Immer unangetastet lassen.

**Why:** Chris hat ~60.000 Fotos in OneDrive die er selbst manuell organisiert. Eigene Aufnahmen ist der automatische Eingang vom Handy — darf nie gelöscht werden.

**How to apply:** Bei Foto-Organisationsaufgaben: Dateien in einen neutralen Arbeitsordner kopieren, dort organisieren/umbenennen. Chris baut das Ergebnis dann selbst in seine Hauptstruktur ein. Den Systemordner nie direkt anfassen. Backup-Ordner (Eigene Aufnahmen_Backup) kann Chris nach dem Einbauen selbst löschen.
