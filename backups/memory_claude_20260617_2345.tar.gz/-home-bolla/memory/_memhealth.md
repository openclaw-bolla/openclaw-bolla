---
name: _memhealth
description: Nächtlicher Memory-Größen-Wächter — bei ACTION NEEDED in einer Session aufräumen
metadata:
  node_type: memory
  type: reference
---

# 🩺 Memory-Health — 2026-06-17

**STATUS: ACTION NEEDED**  ·  127 Memory-Dateien  ·  Summe 198391 B  ·  Global CLAUDE.md 4575 B  ·  MEMORY.md 13278 B  ·  aktuell.md 3019 B

## ⚠️ Zu tun (von Bolla in einer Session, mit Urteilsvermögen — Git/OneDrive macht alles reversibel)
- 11 Memory(s) nicht im MEMORY.md-Index verlinkt (evtl. vergessen/verwaist): feedback_default_model.md, feedback_model_choice.md, feedback_tageszeit.md, project_authenticator_sync.md, project_foto_organisation.md, project_migration.md, project_plan_downgrade.md, project_pro_renate.md, project_school.md, reference_ais_chat.md, user_geraete.md

## Top 10 größte Memory-Dateien
-  13278 B  MEMORY.md
-   8570 B  fsecure_recherche.md
-   6630 B  project_book_akku.md
-   6331 B  feedback_modell_auswahl.md
-   4910 B  projekt_ki_thriller.md
-   4660 B  project_voice_setup.md
-   3827 B  rules_kritisch.md
-   3413 B  reference_mc.md
-   3361 B  reference_kindle.md
-   3309 B  project_aimor.md

_Automatisch erzeugt von scripts/memory_health.py (Cron, nachts). Kein LLM/Quota. Letzter Lauf: 2026-06-17._
