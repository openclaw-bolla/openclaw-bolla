---
name: Robin — Studium & Details
description: Robin (Chris' Sohn), Medizinstudent Uni Ulm, alle relevanten Details
type: project
originSessionId: 7265fa90-2a51-4c5a-8721-102beb2f414a
---
Robin ist Chris' Sohn und studiert Medizin an der **Universität Ulm**.

## Studienverlauf Medizin (Uni Ulm)
| Zeitraum | Abschnitt | Details |
|---|---|---|
| WS 2021/22 | FS 1–2 · Vorklinik | Biochemie, Anatomie, Physiologie, Biologie, Chemie ✅ |
| WS 2022/23 | FS 3–4 · Vorklinik | Pathophysiologie, Pharmakologie Grundlagen, Abschluss Vorklinik ✅ |
| SS 2023 | **M1 · Physikum** | 1. Staatsexamen — Vorklinischer Abschnitt bestanden ✅ |
| WS 2023/24 | FS 5–6 · Klinik | Klinische Propädeutik, Innere Medizin, Chirurgie Einführung ✅ |
| WS 2024/25 | FS 7 · Klinik | Neurologie, Psychiatrie, Pädiatrie, Kardiologie ✅ |
| SS 2025 | Forschungssemester | Experimentelle Medizin · Doktorarbeit: Neutrophile Granulozyten / TRAKI / Kardiochirurgie ✅ |
| WS 2025/26 | FS 8 · Blockpraktikum | Alle klinischen Fächer: Innere, Chirurgie, Gynäkologie, Pädiatrie, Psychiatrie, Dermatologie, HNO, Augenheilkunde, Orthopädie u.a. ✅ |
| SS 2026 | **FS 9 ◀ JETZT** | Fortsetzung klinische Ausbildung · Blockpraktika & Kurse |
| WS 2026/27 | FS 10 · Klinik Abschluss | Abschluss klinischer Abschnitt, Prüfungsvorbereitung M2 |
| Frühjahr 2027 | **M2 · Hammerexamen** | Schriftlich, 320 Fragen über 3 Tage |
| SS 2027 – SS 2028 | PJ · Praktisches Jahr | 3 × 16 Wochen: Innere Medizin · Chirurgie · Wahlfach |
| Herbst 2028 | **M3 · 3. Staatsexamen** | Mündlich-praktische Prüfung · Approbation als Arzt 🎉 |

- **Aktuell:** 9. Fachsemester (SS 2026)
- **Doktorarbeit-Titel:** „Veränderungen neutrophiler Granulozyten als Diagnose- und Prognosewerkzeug von TRAKI während kardiochirurgischer Eingriffe"
- **Approbation voraussichtlich:** Herbst 2028

## Adressen in Ulm
- **WG:** Walfischgasse 5, 89073 Ulm (Koordinaten: 48.3993, 9.9892)
- **Uni Med. Fakultät:** Albert-Einstein-Allee, 89081 Ulm (Koordinaten: 48.4221, 9.9524)
- **Heimatadresse (Norderstedt):** Buchenweg 67a, 22846 Norderstedt

## Kontakt
- Mobil: +49 (157) 32563353

## Events (in Mission Control)
- Medimeisterschaften: 11.–14. Juni 2026, Obermehler, Thüringen
- Abflug Tansania (Famulatur): 31.07.2026 (Nachtflug STR→FRA→JRO, Ankunft 01.08. Ortszeit)
- Rückkehr: 08.09.2026 (38 Tage Famulatur)

## Vorlesungsfreie Zeiten Uni Ulm Medizin 2026
- Semesterferien Sommer: 19.07. – 11.10.2026
- Weihnachtsferien: 24.12.2026 – 05.01.2027

**How to apply:** Diese Infos immer heranziehen wenn Chris über Robin spricht — Studium, Termine, Adresse, Doktorarbeit.
