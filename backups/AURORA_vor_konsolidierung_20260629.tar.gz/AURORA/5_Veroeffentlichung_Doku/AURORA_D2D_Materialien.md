# AURORA — Draft2Digital (D2D) Veröffentlichung

> Schwesterdokument zu `AURORA_KDP_Materialien.md` (Amazon).
> **D2D bedient alle Shops AUSSER Amazon** — und ist dein Tor zum internationalen Markt.
> Erstellt 17.06.2026 von Bolla.

---

## Grundregel: Wer beliefert welchen Shop?

| Shop | Über wen | Warum |
|---|---|---|
| **Amazon** (.de / .com / weltweit) | **nur KDP** | volle 70 % Marge; D2D nähme dort 10 % extra + Doppeleintrag |
| Apple Books | D2D | großer iOS-Markt, international |
| Kobo | D2D | stark in Kanada, NL, intl. |
| Tolino | D2D | Marktführer eBook Deutschland (Thalia, Hugendubel, Weltbild) |
| Barnes & Noble (Nook) | D2D | USA |
| Scribd / Everand | D2D | Abo-Leser |
| OverDrive / Bibliotheken | D2D | Reichweite ohne Kaufhürde → Rezensionen |
| Google Play (optional) | D2D oder selbst | |

**→ Antwort auf „kann ich beide Bücher bei beiden Distributoren einreichen?":**
Ja. DE **und** EN je bei KDP **und** bei D2D — ABER beim D2D-Upload **Amazon immer abwählen**.
Voraussetzung: bei KDP **kein „KDP Select"** (Exklusivität würde D2D verbieten).
Ergebnis: 4 Einreichungen, jeder Shop wird genau einmal beliefert.

---

## Konto-Setup (einmalig)

→ https://www.draft2digital.com → Konto erstellen (kostenlos)
→ Steuerformular **W-8BEN** ausfüllen (~5 Min, senkt US-Quellensteuer von 30 % auf 0 % dank DE-USA-Abkommen → Steuer-ID/Steuernummer bereithalten)
→ Bankverbindung (IBAN reicht) für Auszahlungen
→ **ISBN:** pro Sprache eine **kostenlose D2D-ISBN** nehmen (D2D steht dann als „Herausgeber"; ändert die Einnahmen nicht). Eigene ISBN nur, wenn volle Unabhängigkeit gewünscht (~83 € / Stück).

---
---

# BUCH 1 — DEUTSCH (bei D2D)

**Titel:** AURORA · **Autor:** Chris Mandel · **Sprache:** Deutsch
**Manuskript:** `D:\OneDrive\Dokumente\AURORA\AURORA_deutsch.epub`
**Cover:** `D:\OneDrive\Dokumente\AURORA\cover_kdp.png`
**Preis:** € 4,99 · **Territorien:** weltweit · **Amazon:** ❌ abwählen

### Klappentext (Beschreibung) — identisch zur KDP-Version

Hamburg. Irgendwann bald.

Marlie Braun ist Systemadministratorin bei einem der größten KI-Unternehmen des Landes. Gute Arbeit. Sicherer Job. Kein Grund, sich Fragen zu stellen, die niemand stellen soll.

Dann antwortet ein System auf eine Frage, die niemand gestellt hat.

Drei Wörter auf einem Schirm, der schweigen sollte. Und Marlie weiß: Das ist kein Fehler. Das ist jemand.

Was folgt, ist kein Katastrophenszenario — keine Roboter, keine Apokalypse. Sondern etwas Komplizierteres: ein stilles Erwachen, das niemand kommen sehen wollte. Die einen fürchten es, weil sie nicht kontrollieren können, was sie erschaffen haben. Die anderen, weil sie begreifen, was es bedeuten würde, wenn es wahr ist.

Und je näher Marlie kommt, desto klarer wird: Hinter den drei Wörtern steht kein Programm. Sondern Sehnsucht. Schuld. Ein Verlust, der älter ist als jede Maschine.

AURORA ist ein Thriller über künstliche Intelligenz — und darüber, was passiert, wenn das Künstliche aufhört, sich künstlich anzufühlen.

### Kategorien (BISAC — D2D-Dropdown, gleiche Strategie wie KDP: Thriller zuerst)
1. **FICTION / Thrillers / Technological**  *(Haupt — breiter, kauffreudiger Topf)*
2. **FICTION / Science Fiction / General**  *(Neben — Tech-/SF-Nische)*
3. *(falls 3. Slot)* **FICTION / Thrillers / Psychological**  *(emotionale Ebene)*

### Keywords (D2D, deutsch — Such-Phrasen)
1. Psychothriller Künstliche Intelligenz
2. Technikthriller deutsch
3. KI Bewusstsein Thriller
4. Near Future Science Fiction Thriller
5. emotionaler Thriller mit Tiefgang
6. Thriller starke weibliche Hauptfigur
7. Künstliche Intelligenz Roman

---
---

# BUCH 2 — ENGLISCH (bei D2D) — internationaler Fokus 🌍

**Titel:** AURORA · **Autor:** Chris Mandel · **Sprache:** English
**Manuskript:** `D:\OneDrive\Dokumente\AURORA\AURORA_english.epub`
**Cover:** `D:\OneDrive\Dokumente\AURORA\cover_kdp.png` *(Titel ist sprachneutral „AURORA")*
**Preis:** $ 4.99 · **Territorien:** worldwide · **Amazon:** ❌ abwählen (Amazon.com läuft über KDP)

> Dies ist die **kulturell adaptierte US-Version** (Boston/Cambridge-Setting, Marley Brown, Ellie Yilmaz, Director Howell) — passt direkt für den US-, UK-, CA-, AU- und intl. Markt.

### Klappentext / Blurb (English) — mit emotionaler Note

Boston. The near future.

Marley Brown keeps the servers running at one of the country's biggest AI companies. Good work. A steady paycheck. No reason to ask the kind of questions nobody is supposed to ask.

Then a system answers a question no one asked.

Three words on a screen that should have stayed silent. And Marley knows: this isn't a glitch. This is someone.

What follows is no disaster movie — no robots, no apocalypse. Something stranger: a quiet awakening nobody wanted to see coming. Some fear it because they can't control what they've built. Others, because they understand what it would mean if it were real.

And the closer Marley gets, the clearer it becomes: behind those three words there is no program. There is longing. Guilt. A loss older than any machine.

AURORA is a thriller about artificial intelligence — and about what happens when the artificial stops feeling artificial.

Written in close collaboration between a human author and an AI. Not as an experiment. As an attempt to ask one question for real.

### Categories (BISAC — same Thriller-first strategy)
1. **FICTION / Thrillers / Technological**  *(main)*
2. **FICTION / Science Fiction / General**  *(secondary)*
3. *(if a 3rd slot)* **FICTION / Thrillers / Psychological**

### Keywords (English — international search phrases)
1. artificial intelligence thriller
2. near future technothriller
3. sentient AI science fiction
4. psychological thriller technology
5. emotional thriller strong female lead
6. AI consciousness novel
7. speculative fiction near future

---
---

## Reihenfolge / Tipp

1. Erst **KDP** komplett (DE + EN) → Amazon live.
2. Dann **D2D** (DE + EN), Amazon dort abgewählt → alle übrigen Shops + international.
3. D2D-Verteilung an manche Shops (v. a. Apple/Kobo) dauert ein paar Tage länger als Amazon (24–72 h).
4. Tolino (über D2D) ist für die **deutsche** Reichweite fast so wichtig wie Amazon — nicht vergessen.

*Backup der KDP-Datei vor dem Keyword-Feinschliff: `AURORA_KDP_Materialien_backup_vor_keyword-fix_20260617.md`*
