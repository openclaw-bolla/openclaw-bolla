# AURORA — Veröffentlichung: Was zu tun ist

## Schritt 1: KDP-Konto anlegen (Amazon)
→ https://kdp.amazon.com
→ Mit ernstmandel@outlook.de einloggen (Amazon-Account)
→ Steuerinfos hinterlegen (einmalig, braucht Steuer-ID)
→ Bankverbindung hinterlegen für Auszahlungen

## Schritt 2: Draft2Digital-Konto anlegen (alle anderen Shops)
→ https://www.draft2digital.com
→ Neues Konto erstellen
→ Steuerinfos hinterlegen (W-8BEN-Formular für US-Tantiemen, ~5 Min)

## Schritt 3: Deutsches Buch bei KDP hochladen
Dateien liegen bereit:
- Manuskript: `D:\OneDrive\Dokumente\AURORA\AURORA_deutsch.epub`
- Cover:      `D:\OneDrive\Dokumente\AURORA\cover_kdp.png`
- Materialien (Klappentext, Keywords, Kategorien, Preis):
  → `D:\OneDrive\Dokumente\aurora\AURORA_KDP_Materialien.md`
- KDP Select: NEIN (wegen D2D)
- Preis: €4,99 · Royalty 70%

## Schritt 4: Deutsches Buch auch bei D2D hochladen
→ Selbe EPUB + Cover hochladen
→ Shops auswählen: Apple Books, Kobo, Tolino, Scribd, OverDrive (Bibliotheken)
→ Amazon dort NICHT ankreuzen (haben wir direkt über KDP gemacht — D2D nähme 10% Provision)
→ ISBN: kostenlose D2D-ISBN nehmen reicht für den Start

## ISBN & ASIN — kurz zur Einordnung
- ASIN = Amazons interne Nummer, automatisch & kostenlos, ändert das Einkommen NICHT.
- Eine ISBN gilt pro Format + Sprache → DE und EN brauchen je eine eigene.
- Amazon direkt: keine ISBN nötig (ASIN reicht). D2D: gratis D2D-ISBN ok.
- Eigene ISBNs (Unabhängigkeit) erst später: ~83 € einzeln / ~225 € netto für 10er-Block.
- Print: NICHT selbst. Nur falls ein Verlag anfragt → der kauft dann die Print-ISBN.
- Details: AURORA_ISBN_ASIN_Uebersicht (Word) im selben Ordner.

## Schritt 5: Englisches Buch bei D2D hochladen
- Aktuell vorhanden: direkte Übersetzung (Hamburg-Setting, deutsche Namen)
- Geplant (später, mit Fable 5): kulturell angepasste US-Version
  (Boston-Setting, Ellie statt Leni, GDPR statt DSGVO, Sleeping-Beauty-Vorspann)
- Für jetzt: direkte Übersetzung hochladen ist ok als Anfang
- Datei: `D:\OneDrive\Dokumente\AURORA\AURORA_english.epub`
- Preis: $4,99

## Wann?
Kein Zeitdruck. Alles liegt bereit. KDP-Review dauert nach Upload 24–72h.
