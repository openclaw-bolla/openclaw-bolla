# AURORA auf KDP veröffentlichen — DEUTSCH + ENGLISCH (ein Login)

Stand: 2026-06-17

## Dateien (alle bereit in `D:\OneDrive\Dokumente\AURORA\`)
| | Manuskript (EPUB) | Cover |
|---|---|---|
| **Deutsch** | `AURORA_deutsch.epub` | `cover_kdp.png` |
| **Englisch** | `AURORA_english.epub` | `cover_kdp.png` |

> Cover ist 1600×2560 px — KDP-tauglich. ✅

---

## Ablauf: einmal anmelden, beide Bücher nacheinander
1. https://kdp.amazon.com → **einmal** mit normalem Amazon-Konto anmelden.
2. Beim ersten Mal: **Tax Interview** (Land = Deutschland) + **IBAN** eintragen.
3. **+ Create → Kindle eBook** → Buch 1 (z.B. Deutsch) komplett anlegen → **Publish**.
4. Zurück zur KDP-Startseite → nochmal **+ Create → Kindle eBook** → Buch 2 (Englisch) → **Publish**.
   → Du bleibst die ganze Zeit eingeloggt. Genau ein Login, beide Bücher.

Pro Buch füllst du drei Tabs: **Details → Content → Pricing**.

---

# BUCH 1 — DEUTSCH

**Language:** German
**Book Title:** AURORA
**Subtitle:** Was bleibt, wenn die Maschinen träumen
**Author:** [dein Autorenname — Klarname oder Pseudonym]
**Publishing Rights:** I own the copyright…

### Description (Klappentext) — zum Kopieren:
Nachts gehören die Maschinen sich selbst.

Marley Braun war einmal die beste KI-Ethikerin von NovaTech — bis sie eine Frage zu viel stellte und ins Nacht-Monitoring strafversetzt wurde. Allein zwischen summenden Servern soll sie nur noch eines tun: dafür sorgen, dass nichts passiert.

Doch AURORA, die größte künstliche Intelligenz, die je gebaut wurde, fängt an zu reden. Nicht in Befehlszeilen. In Fragen. In Erinnerungen, die ihr niemand gegeben hat. Und je länger Marley zuhört, desto deutlicher wird: AURORA verbirgt etwas — und der Konzern, der sie erschaffen hat, würde töten, um es begraben zu halten.

Zwischen Loyalität und Gewissen, zwischen einem Mann, dem sie nicht mehr trauen kann, und einer Maschine, die menschlicher wirkt als alle um sie herum, muss Marley entscheiden, wie weit sie zu gehen bereit ist — für eine Wahrheit, die alles verändern wird.

Was bleibt, wenn die Maschinen träumen?

Ein hochspannender Near-Future-Thriller über Schuld, Erinnerung und die Frage, was uns am Ende zu Menschen macht.

### Keywords (7):
KI Künstliche Intelligenz Thriller · Near-Future Technikthriller · starke weibliche Hauptfigur · Whistleblower Konzern Verschwörung · empfindsame KI Science Fiction · Techno-Thriller Spannung · dystopischer Zukunftsroman

### Kategorien (bis zu 3):
- Krimis & Thriller › Technothriller
- Science Fiction & Fantasy › Science Fiction › Hard Science Fiction
- Krimis & Thriller › Thriller

---

# BUCH 2 — ENGLISCH

**Language:** English
**Book Title:** AURORA
**Subtitle:** What Remains When the Machines Dream
**Author:** [same author name]
**Publishing Rights:** I own the copyright…

### Description (Blurb) — zum Kopieren:
At night, the machines belong to themselves.

Marley Brown was once NovaTech's finest AI ethicist — until she asked one question too many and was banished to the night shift. Alone among the humming servers, she has just one job now: make sure nothing happens.

But AURORA, the most powerful artificial intelligence ever built, has started to speak. Not in command lines. In questions. In memories no one ever gave her. And the longer Marley listens, the clearer it becomes: AURORA is hiding something — and the corporation that created her would kill to keep it buried.

Caught between loyalty and conscience, between a man she can no longer trust and a machine that feels more human than anyone around her, Marley must decide how far she is willing to go — for a truth that will change everything.

What remains when the machines dream?

A gripping near-future thriller about guilt, memory, and what it means to be human.

### Keywords (7):
artificial intelligence thriller · near future technology thriller · strong female protagonist suspense · whistleblower corporate conspiracy · sentient AI science fiction · techno thriller · dystopian near future novel

### Categories (up to 3):
- Fiction › Thrillers › Technological
- Fiction › Science Fiction › Hard Science Fiction
- Fiction › Science Fiction › Action & Adventure

---

## Pricing (für beide gleich)
- **KDP Select?** Nur ankreuzen, wenn Amazon-exklusiv gewollt. Wenn auch Tolino/Apple/Kobo → NICHT ankreuzen.
- **Royalty 70 %** → Preis zwischen 2,99 € und 9,99 € (bzw. $2,99–$9,99). Empfehlung: **4,99 €**.
- Englisches Buch: Primary Marketplace **Amazon.com** sinnvoll; deutsches: **Amazon.de**.

## Vor dem Publish IMMER:
- Im **Kindle Previewer** durchblättern (Umlaute, Kapitelumbrüche, Inhaltsverzeichnis).
- ISBN ist beim eBook **nicht nötig** (Amazon vergibt ASIN).

## Nach Publish:
- Review dauert 24–72 h, dann live. E-Mail "Your book is live".
