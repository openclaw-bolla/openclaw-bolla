# AURORA — KDP Veröffentlichung

## Schritt 1: KDP-Account
→ https://kdp.amazon.com → mit Amazon-Account einloggen (ernstmandel@outlook.de)
→ "Neuen Titel hinzufügen" → eBook → Kindle-eBook

---

## Schritt 2: Buchdetails

**Sprache:** Deutsch
**Buchtitel:** AURORA
**Untertitel:** (leer lassen)
**Autor:** Chris Mandel
**Mitwirkende:** (leer)
**Beschreibung:** (→ Klappentext unten, HTML-Formatierung erlaubt)

---

## Klappentext (in das Beschreibungsfeld kopieren)

Hamburg. Irgendwann bald.

Marlie Braun ist Systemadministratorin bei einem der größten KI-Unternehmen des Landes. Gute Arbeit. Sicherer Job. Kein Grund, sich Fragen zu stellen, die niemand stellen soll.

Dann antwortet ein System auf eine Frage, die niemand gestellt hat.

Drei Wörter auf einem Schirm, der schweigen sollte. Und Marlie weiß: Das ist kein Fehler. Das ist jemand.

Was folgt, ist kein Katastrophenszenario — keine Roboter, keine Apokalypse. Sondern etwas Komplizierteres: ein stilles Erwachen, das niemand kommen sehen wollte. Die einen fürchten es, weil sie nicht kontrollieren können, was sie erschaffen haben. Die anderen, weil sie begreifen, was es bedeuten würde, wenn es wahr ist.

Und je näher Marlie kommt, desto klarer wird: Hinter den drei Wörtern steht kein Programm. Sondern Sehnsucht. Schuld. Ein Verlust, der älter ist als jede Maschine.

AURORA ist ein Thriller über künstliche Intelligenz — und darüber, was passiert, wenn das Künstliche aufhört, sich künstlich anzufühlen.

Dieses Buch entstand in enger Zusammenarbeit zwischen Autor und KI. Nicht als Experiment. Als Versuch, eine Frage wirklich zu stellen.

---

## Schlüsselwörter (7 Felder)

> **Strategie (17.06.):** bewusst Richtung **Thriller** verschoben statt rein Sci-Fi — Krimi/Thriller ist das Lieblingsgenre Nr. 1 der (kauffreudigeren) weiblichen eBook-Leser. Tech-Nische bleibt (Feld 1–4), dazu emotionale + „starke Frau"-Begriffe (Feld 5–6) für die weibliche Leserschaft. Keywords sind Such-*Phrasen* — so wie Leser tippen.

1. Psychothriller Künstliche Intelligenz
2. Technikthriller deutsch
3. KI Bewusstsein Thriller
4. Near Future Science Fiction Thriller
5. emotionaler Thriller mit Tiefgang
6. Thriller starke weibliche Hauptfigur
7. Künstliche Intelligenz Roman Hamburg

---

## Kategorien (2 auswählen)

> **Strategie (17.06.):** Haupt- und Nebenkategorie **getauscht** — der breitere, kauffreudigere Topf „Thriller & Krimis" wird Hauptkategorie, die engere Sci-Fi-Nische rutscht auf Platz 2. So landet AURORA im Genre, das die größte Käufergruppe (Frauen) am häufigsten durchsucht, bleibt aber auch für Tech-/Sci-Fi-Leser sichtbar.

**Hauptkategorie:**
Belletristik → Thriller & Krimis → Technothriller
*(falls wählbar alternativ: Thriller & Krimis → Psychothriller — trifft die emotionale Ebene noch besser)*

**Nebenkategorie:**
Belletristik → Science-Fiction → Techno-Thriller

---

## Altersfreigabe / Klassifizierung

- Altersfreigabe: Alle Altersgruppen (kein expliziter Inhalt)
- Jugendbuch: Nein

---

## Schritt 3: Manuskript & Cover

**Manuskript hochladen:**
`D:\OneDrive\Dokumente\AURORA\AURORA_deutsch.epub`

**Cover hochladen:**
`D:\OneDrive\Dokumente\AURORA\cover_kdp.png`
(1600×2560 px, mit Titel und Autorenname, Amazon-Standard-Format ✓)

---

## Schritt 4: KDP Select

**NEIN — NICHT einschreiben**
Wir nutzen Draft2Digital (D2D) parallel → KDP Select würde 90-Tage-Exklusivität erzwingen
und D2D sperren. Also: KDP Select ablehnen.

---

## Schritt 5: Territorien & Preis

**Territorien:** Weltweit (alle Regionen)

**Preis:**
- DE: **€ 4,99**
- US: **$ 4,99**
- Rest: automatisch umgerechnet lassen

**Royalty:** 70% (automatisch bei €2,99–€9,99). Bei €4,99 ≈ €3,49 brutto,
minus kleine Übertragungsgebühr (Dateigröße-abhängig, ~€0,12/MB) → real ~€3,1–3,3 pro Verkauf.
Über D2D zu Amazon wären es ~10% weniger → Amazon daher IMMER direkt über KDP.

---

## PARALLEL: Draft2Digital (D2D) — der eigentliche Plan

→ https://www.draft2digital.com → Konto erstellen (kostenlos)

**Was D2D macht:**
- Ein Upload → verteilt an: Amazon, Apple Books, Kobo, Barnes & Noble, Tolino, Scribd, OverDrive (Bibliotheken)
- Kein Exklusivvertrag, kein Abo, keine Vorabkosten
- D2D nimmt 10% der Einnahmen (transparent)
- Eigene ISBN gratis, oder du bringst deine eigene mit
- Funktioniert für DE-Buch (Deutsch) UND EN-Buch (Englisch) im selben Konto

**Workflow:**
1. KDP direkt anmelden (ohne Select) für maximale Kontrolle + volle Marge auf Amazon
2. D2D für alle anderen Shops (Apple, Kobo, Tolino, etc.)
3. EN-Version separat bei D2D hochladen → international sichtbar

**WICHTIG — Amazon bei D2D ABWÄHLEN:**
D2D kann zwar auch an Amazon liefern, nimmt dort aber 10% Provision.
Amazon machst du selbst direkt über KDP (volle 70%). Bei D2D also Amazon
NICHT ankreuzen — sonst doppelte Einträge + weniger Marge.

---

## Schritt 6: ISBN & ASIN — die Fakten

**Grundregel:** Eine ISBN = ein Format + eine Sprache.
→ DE-E-Book und EN-E-Book sind zwei Ausgaben → brauchen **zwei** ISBNs.
→ Die Plattform (Amazon vs. D2D) ist KEIN Format — eine eigene ISBN gilt überall.

**Was ist eine ASIN?**
→ Amazons interne Produkt-Nummer. Wird **automatisch & kostenlos** vergeben.
→ Jedes Kindle-Buch hat eine ASIN — auch wenn D2D es einstellt (Amazon erzeugt sie selbst).
→ ISBN und ASIN schließen sich NICHT aus, sie liegen nebeneinander.
→ **Einkommen:** ASIN oder ISBN ändert die Tantieme NICHT. Reine Identifikationsnummer.

**Option A (Start, kostenlos):**
→ Amazon direkt: nur ASIN (gratis, keine ISBN nötig)
→ D2D-Kanäle: kostenlose D2D-ISBN pro Sprache
→ Haken: D2D-ISBN ist an D2D gebunden, D2D steht als Herausgeber drin.

**Option B (Unabhängigkeit, kostenpflichtig):**
→ Eigene ISBNs kaufen — über die MVB (Frankfurt, einzige offizielle Stelle in DE)
   oder günstigere Reseller wie german-isbn.de
→ Reale Preise (Stand 2026, Reseller, zzgl. MwSt):
   - Einzel-ISBN: ~70 € netto (~83 € brutto)
   - 10er-Block: ~225 € netto (~268 € brutto) → ~22,50 €/Stück
→ Für 2 Stück (DE+EN) sind 2 Einzel-ISBNs billiger (~167 € brutto).
   10er-Block lohnt erst ab ~4 geplanten Ausgaben.

**Empfehlung für jetzt:** Option A (kostenlos). Bei gutem Lauf / Verlagsinteresse
auf eigene ISBNs upgraden — bringt kein Cent mehr pro Verkauf, nur Unabhängigkeit.

---

## Nach der Veröffentlichung

- Review-Prozess: 24–72 Stunden
- Dann live auf amazon.de, amazon.com etc.
- DRM: Amazon schützt das Buch automatisch (Käufer können es nicht weiterleiten)
- Rezensionen bitten: Kunden direkt per Mail oder über den Rezensions-Bitte-Abschnitt im Buch

---

*Erstellt von Bolla — 15.06.2026*
