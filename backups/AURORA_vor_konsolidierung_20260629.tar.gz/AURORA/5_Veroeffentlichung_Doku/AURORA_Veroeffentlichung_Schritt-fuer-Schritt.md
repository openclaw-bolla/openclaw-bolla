# AURORA — Veröffentlichung Schritt für Schritt
*Stand 17.06.2026 · Reihenfolge: erst KDP (Amazon), dann D2D (Rest + international)*

---

## 0. Vorher bereitlegen
- [ ] Amazon-Login (ernstmandel@outlook.de)
- [ ] **Steuer-ID / Steuernummer** (für KDP-Steuerinterview + D2D W-8BEN)
- [ ] **IBAN** (Auszahlungen)
- [ ] Dateien (liegen bereit in `D:\OneDrive\Dokumente\AURORA\`):
  - `AURORA_deutsch.epub`
  - `AURORA_english.epub`
  - `cover_kdp.png` (1600×2560)

---
# TEIL A — KDP (Amazon) · zuerst!

## A0. Konto
1. https://kdp.amazon.com → mit Amazon-Account einloggen.
2. Falls erstes Mal: **Steuerinterview** + **Bankverbindung** ausfüllen (einmalig).

## A1. Deutsches eBook anlegen
„Neuen Titel hinzufügen" → **Kindle eBook**.

### Reiter 1 — Details
- Sprache: **Deutsch**
- Buchtitel: **AURORA**
- Untertitel: *(leer)*
- Autor: **Chris Mandel**
- Beschreibung: **→ KLAPPENTEXT DE (siehe unten, Block 1)**
- Verlag: *(leer lassen)*
- Schlüsselwörter (7) → **Block 2**
- Kategorien (bis zu 3) → **Block 3**
- Altersfreigabe: Alle Altersgruppen / kein Jugendbuch
- **KDP Select: NICHT ankreuzen!** (sonst keine D2D-Verteilung möglich)

### Reiter 2 — Inhalt
- Manuskript hochladen: `AURORA_deutsch.epub`
- Cover hochladen: `cover_kdp.png`
- Vorschau prüfen (Online-Previewer)

### Reiter 3 — Preise
- KDP Select: nein
- Territorien: **Weltweit**
- Tantieme: **70 %**
- Preis DE: **€ 4,99** (andere Länder automatisch umrechnen lassen)
- → **„Kindle-eBook veröffentlichen"**

## A2. Englisches eBook anlegen
Gleicher Ablauf, aber:
- Sprache: **English**
- Beschreibung: **→ KLAPPENTEXT EN (Block 4)**
- Schlüsselwörter: **Block 5**
- Kategorien: **Block 6**
- Manuskript: `AURORA_english.epub`
- Preis: **$ 4.99**, 70 %, weltweit

---
# TEIL B — Draft2Digital (D2D) · danach

## B0. Konto
1. https://www.draft2digital.com → Konto erstellen.
2. **W-8BEN** ausfüllen (Steuer-ID → senkt US-Quellensteuer 30 % → 0 %).
3. IBAN hinterlegen.

## B1. Deutsches eBook
- Buch hochladen (`AURORA_deutsch.epub`) + Cover (`cover_kdp.png`)
- Titel/Autor/Beschreibung: **wie KDP DE** (Block 1)
- ISBN: **kostenlose D2D-ISBN** nehmen
- Kategorien (BISAC) → **Block 3** (englische BISAC-Namen, gleiche Reihenfolge)
- Preis: € 4,99
- **Shops auswählen:** alle AUSSER **Amazon** ❌ (Amazon läuft über KDP!)
  → also: Apple Books, Kobo, Tolino, Barnes & Noble, Scribd/Everand, OverDrive …

## B2. Englisches eBook
- `AURORA_english.epub` + Cover
- Beschreibung: **Block 4** · Kategorien **Block 6**
- ISBN: zweite kostenlose D2D-ISBN
- Preis: $ 4.99 · Territorien: worldwide
- **Amazon wieder abwählen** ❌

---
---
# COPY-PASTE-BLÖCKE

## ▸ Block 1 — KLAPPENTEXT DE
```
Hamburg. Irgendwann bald.

Marlie Braun ist Systemadministratorin bei einem der größten KI-Unternehmen des Landes. Gute Arbeit. Sicherer Job. Kein Grund, sich Fragen zu stellen, die niemand stellen soll.

Dann antwortet ein System auf eine Frage, die niemand gestellt hat.

Drei Wörter auf einem Schirm, der schweigen sollte. Und Marlie weiß: Das ist kein Fehler. Das ist jemand.

Was folgt, ist kein Katastrophenszenario — keine Roboter, keine Apokalypse. Sondern etwas Komplizierteres: ein stilles Erwachen, das niemand kommen sehen wollte. Die einen fürchten es, weil sie nicht kontrollieren können, was sie erschaffen haben. Die anderen, weil sie begreifen, was es bedeuten würde, wenn es wahr ist.

Und je näher Marlie kommt, desto klarer wird: Hinter den drei Wörtern steht kein Programm. Sondern Sehnsucht. Schuld. Ein Verlust, der älter ist als jede Maschine.

AURORA ist ein Thriller über künstliche Intelligenz — und darüber, was passiert, wenn das Künstliche aufhört, sich künstlich anzufühlen.
```

## ▸ Block 2 — KEYWORDS DE (7 Felder)
```
Psychothriller Künstliche Intelligenz
Technikthriller deutsch
KI Bewusstsein Thriller
Near Future Science Fiction Thriller
emotionaler Thriller mit Tiefgang
Thriller starke weibliche Hauptfigur
Künstliche Intelligenz Roman
```

## ▸ Block 3 — KATEGORIEN DE (BISAC, Thriller zuerst)
```
1. FICTION / Thrillers / Technological      (Haupt)
2. FICTION / Science Fiction / General      (Neben)
3. FICTION / Thrillers / Psychological      (falls 3. Slot)
```
*KDP-Dropdown deutsch: „Thriller & Krimis → Technothriller" als Haupt, „Science-Fiction → Techno-Thriller" als Neben.*

## ▸ Block 4 — KLAPPENTEXT EN
```
Boston. The near future.

Marley Brown keeps the servers running at one of the country's biggest AI companies. Good work. A steady paycheck. No reason to ask the kind of questions nobody is supposed to ask.

Then a system answers a question no one asked.

Three words on a screen that should have stayed silent. And Marley knows: this isn't a glitch. This is someone.

What follows is no disaster movie — no robots, no apocalypse. Something stranger: a quiet awakening nobody wanted to see coming. Some fear it because they can't control what they've built. Others, because they understand what it would mean if it were real.

And the closer Marley gets, the clearer it becomes: behind those three words there is no program. There is longing. Guilt. A loss older than any machine.

AURORA is a thriller about artificial intelligence — and about what happens when the artificial stops feeling artificial.
```

## ▸ Block 5 — KEYWORDS EN (7 Felder)
```
artificial intelligence thriller
near future technothriller
sentient AI science fiction
psychological thriller technology
emotional thriller strong female lead
AI consciousness novel
speculative fiction near future
```

## ▸ Block 6 — KATEGORIEN EN (BISAC)
```
1. FICTION / Thrillers / Technological      (main)
2. FICTION / Science Fiction / General      (secondary)
3. FICTION / Thrillers / Psychological      (if 3rd slot)
```

---
## Nach dem Veröffentlichen
- KDP-Review: 24–72 h → dann live auf amazon.de / .com
- D2D-Verteilung an Apple/Kobo: kann ein paar Tage länger dauern
- Quelldateien: `AURORA_KDP_Materialien.md` + `AURORA_D2D_Materialien.md` (im AURORA-Ordner)
