# AURORA (English) — Schritt-für-Schritt zur Veröffentlichung auf Amazon KDP

Stand: 2026-06-17 · Dateien bereit:
- EPUB: `D:\OneDrive\Dokumente\AURORA\AURORA_english.epub` (3109 KB, 47 Kap.)
- Cover: `D:\OneDrive\Dokumente\AURORA\cover_v6.png`

---

## 0. Vorbereitung (5 Min)
- Dein normales Amazon-Konto reicht (kein separates Autorenkonto nötig).
- Steuerdaten parat: IBAN (für Tantiemen), Steuer-ID. KDP fragt das im "Tax Interview" ab.
- Cover prüfen: KDP will fürs eBook mind. **1600 × 2560 px**, Verhältnis 1:1,6. cover_v6.png ggf. checken.

## 1. Konto anlegen / einloggen
1. https://kdp.amazon.com → Anmelden mit Amazon-Konto.
2. Beim ersten Mal: **Tax Information** ausfüllen ("Tax Interview", ~5 Min).
   - Land: Deutschland → es gibt ein Steuerabkommen, damit die USA nicht 30% einbehalten.
3. **Payment**: IBAN für Tantiemen eintragen.

## 2. Neues eBook anlegen
KDP-Startseite → **"+ Create"** → **Kindle eBook**.

### Tab 1 — eBook Details
- **Language**: English
- **Book Title** (+ optional Subtitle)
- **Author**: dein Autorenname (Pseudonym oder Klarname)
- **Description**: Klappentext (max. 4000 Zeichen). Wichtig fürs Verkaufen!
- **Publishing Rights**: "I own the copyright…"
- **Keywords**: 7 Suchbegriffe (z.B. Thriller-Themen, KI, Boston…)
- **Categories**: 1–3 passende Kategorien wählen.
- **Age Range / Adult content**: nach Inhalt.

### Tab 2 — eBook Content
- **Manuscript**: `AURORA_english.epub` hochladen.
- **Book Cover**: cover_v6.png hochladen (oder "Launch Cover Creator").
- **Kindle Previewer**: NACH Upload den Preview öffnen und **durchblättern** — Umlaute, Kapitelumbrüche, Inhaltsverzeichnis prüfen.
- **ISBN**: für eBook NICHT nötig (Amazon vergibt interne ASIN).

### Tab 3 — Pricing
- **KDP Select** (optional): 90 Tage Amazon-Exklusiv → 70% Tantieme + Kindle Unlimited. Wenn du das Buch auch woanders verkaufen willst → NICHT ankreuzen.
- **Primary Marketplace**: Amazon.com (USA) für ein englisches Buch sinnvoll.
- **Royalty**:
  - **70%** nur bei Preis zwischen **$2,99 und $9,99** (sonst nur 35%).
  - Empfehlung Debüt-Roman: $3,99–$5,99.
- Preise für andere Märkte (DE, UK…) werden automatisch umgerechnet — kannst du anpassen.

## 3. Veröffentlichen
- **"Publish Your Kindle eBook"** klicken.
- Review durch Amazon: **24–72 Stunden**.
- Danach ist das Buch live, ASIN + Produktseite entstehen.

## 4. Nach Veröffentlichung
- Du bekommst eine E-Mail "Your book is live".
- Produktseite checken (Cover, Beschreibung, Preis).
- Optional: **Taschenbuch** zusätzlich anlegen (Paperback) — eigener Flow, braucht PDF-Innenteil + Cover mit Buchrücken.
- Verkäufe im **KDP-Dashboard** → "Reports".

---

## Häufige Stolpersteine
- **Cover zu klein/falsches Verhältnis** → Upload meckert. 1600×2560 px.
- **EPUB-Fehler** im Previewer → Inhaltsverzeichnis / Umbrüche prüfen.
- **Tax Interview nicht gemacht** → Auszahlung blockiert.
- **Preis außerhalb $2,99–$9,99** → nur 35% Tantieme.

## Alternativen zu KDP (falls nicht Amazon-exklusiv)
- **Tolino Media** (Thalia/Weltbild, deutscher Raum)
- **Draft2Digital** (verteilt an Apple Books, Kobo, B&N…)
- **Google Play Books**
→ Dann bei KDP NICHT "KDP Select" ankreuzen.
