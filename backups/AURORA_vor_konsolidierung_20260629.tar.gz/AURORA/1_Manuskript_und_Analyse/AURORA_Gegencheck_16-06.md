# AURORA — Verkaufsreife-Gegencheck
**Erstellt:** 2026-06-16 | **Cheflektorat:** Opus 4.8 | **Grundlage:** Frische Kapitelbewertungen (47 Kap.) vs. Lektoratsbericht vom 14.06.
**Status laut Autor:** "Lektorat Welle 1+2 umgesetzt" (Spannungstal Kap.2, Humor-Cluster 11/17/34/41/42, Noah belebt, Marlie aktiviert)

---

## 1. Executive Summary & Verkaufsreife-Urteil

**Urteil: JA, mit Auflagen (verkaufsreif nach einem kurzen, klar umrissenen Korrektur-Durchgang).**

Das Manuskript ist stark und über weite Strecken auf professionellem Verlagsniveau: Hook-Scores liegen praktisch durchgängig bei 9–10, die Spannung pendelt jetzt zwischen 7 und 9 (kein einziges Tal unter 7 mehr), AURORA trägt verlässlich als emotionales Zentrum, und die Maria/Theo-Tragödie ist Spitzenmaterial. Die **Welle-1-Reparaturen sind klar gelandet** — das Spannungstal in Kap. 2 ist weg (6 → 8), und 4 von 5 Humor-Cluster-Kapiteln sind spürbar repariert. Die **Welle-2-Reparaturen sind nur teilweise gelandet:** Marlie ist überzeugend reaktiviert, Noah dagegen bleibt in einem Drittel der Kapitel blass/passiv — das vom 14.06.-Bericht als "gravierendstes Problem" markierte Thema ist gemildert, aber nicht gelöst.

Verkauf JA, weil: kein Spannungs-, Hook- oder Charakter-Totalausfall mehr existiert, die Sprache überwiegend sauber ist und die Geschichte trägt. Auflagen, weil: (a) eine Handvoll **echter Tippfehler/Grammatikfehler** im Text steht, die ein Lektor vor Druck zwingend fängt, (b) ein **wiederkehrender Zahlen-Wackler in der Timeline** (20/21/22 Jahre) sich durchs ganze Schlussdrittel zieht und konsolidiert werden muss, und (c) zwei **Humor-Resttäler** (Kap. 41/42) sowie Noahs Restpassivität idealerweise noch angefasst werden. Keiner dieser Punkte ist ein Show-Stopper — aber Punkt (a) und (b) sind Pflicht vor jeder Einreichung.

---

## 2. Spannungskurve — Vergleich zum 14.06.-Bericht

**Sind die Täler weg? Ja, die Spannungstäler sind beseitigt.**

| Kap | 14.06. Sp | 16.06. Sp | Δ | Bewertung |
|----|----|----|----|----|
| 0 | 8 | 8 | 0 | stabil |
| 1 | 7 | 8 | ▲ | besser |
| **2** | **6** | **8** | ▲▲ | **Tal beseitigt** |
| 3 | 9 | 8 | ▼ | minimal, unkritisch |
| 4 | 8 | 8 | 0 | stabil |
| 5 | 8 | 8 | 0 | stabil |
| 6 | 8 | 9 | ▲ | besser |
| 7 | 7 | 9 | ▲▲ | deutlich besser |
| 8 | 8 | 9 | ▲ | besser |
| 9 | 8 | 7 | ▼ | leicht (POV-Bruch, s.u.) |
| 10 | 7 | 8 | ▲ | besser |
| 11 | 9 | 9 | 0 | stabil |
| 12 | 8 | 8 | 0 | stabil |
| 13 | 8 | 9 | ▲ | besser |
| 14 | 7 | 7 | 0 | stabil (Fokuskapitel) |
| 15 | 7 | 7 | 0 | stabil |
| 16 | 8 | 8 | 0 | stabil |
| 17 | 8 | 8 | 0 | stabil |
| 18 | 9 | 9 | 0 | stabil |
| 19 | 7 | 7 | 0 | stabil (schwächstes Mittelkapitel) |
| 20 | 8 | 7 | ▼ | leicht |
| 21 | 7 | 7 | 0 | stabil |
| 22 | 8 | 9 | ▲ | besser |
| 23 | 8 | 7 | ▼ | leicht |
| 24 | 9 | 9 | 0 | stabil |
| 25 | 8 | 9 | ▲ | besser |
| 26 | 8 | 8 | 0 | stabil |
| 27 | 8 | 8 | 0 | stabil |
| 28 | 8 | 8 | 0 | stabil |
| 29 | 9 | 9 | 0 | Gipfel-Plateau |
| 30 | 9 | 8 | ▼ | leicht |
| 31 | 9 | 9 | 0 | Gipfel-Plateau |
| 32 | 9 | 8 | ▼ | leicht |
| 33 | 9 | 9 | 0 | Gipfel-Plateau |
| 34 | 8 | 9 | ▲ | besser |
| 35 | 7 | 8 | ▲ | besser |
| 36 | 8 | 8 | 0 | stabil |
| 37 | 7 | 8 | ▲ | besser |
| 38 | 7 | 8 | ▲ | besser |
| 39 | 9 | 8 | ▼ | leicht |
| 40 | 9 | 9 | 0 | Gipfel-Plateau |
| 41 | 8 | 8 | 0 | stabil |
| 42 | 8 | 7 | ▼ | leicht (Dichte der Klimaxe) |
| 43 | 8 | 7 | ▼ | leicht |
| 44 | 8 | 8 | 0 | stabil |
| 45 | 9 | 9 | 0 | stabil |
| 46 | 7 | **5** | ▼▼ | **NEU: schwächstes Kapitel des Buches** |

**Befund:**
- **Das einzige echte Spannungstal des alten Berichts (Kap. 2 = 6) ist geschlossen** (jetzt 8). Reparatur gelandet.
- Der vom 14.06. gewarnte **monotone Mittelteil (Kap. 13–21)** ist leicht aufgewertet (13/22 hoch, 35/37/38 später besser) — die Lese-Ermüdungsgefahr ist reduziert, aber Kap. 19/20/21/23 bleiben im 7er-Bereich. Kein Blocker.
- **Neues Aufmerksamkeitssignal:** Kap. 46 fällt auf **Sp 5** — der niedrigste Wert im gesamten Buch, unterhalb des alten Kap.-2-Tals. Das vorletzte Kapitel verliert Zug (lange Trauer-/Fahrt-Passagen, mehrere Wiederholungs-Cluster). Da es ein Ausklang-Kapitel ist, ist das tolerierbar, aber es ist das neue schwächste Glied und sollte beim Schliff Vorrang vor allem anderen Spannungsthema haben.
- Die kleinen Rückgänge bei 3/20/23/30/32/39/42/43 (jeweils −1) sind im Rauschen unterschiedlicher Bewertungswellen und nicht substanziell.

---

## 3. Status Welle 1 + 2 — gelandet oder nicht?

### Welle 1 (Sofort-Fixes)

| Reparaturthema | Status | Beleg aus frischen Bewertungen |
|----|----|----|
| **Kap. 2 — Spannungstal entschärfen** | ✅ **GELANDET** | Sp von 6 → 8. Marlie trägt zwei Szenen mit eigener Agency, endet im Cliffhanger. Tal geschlossen. |
| **Humor Kap. 11** | ⚠️ **TEILS** | hu von 2 → 3. Marlie emotional tragend, aber Kapitel bleibt humorarm. Leichte Besserung, kein voller Erfolg. |
| **Humor Kap. 17** | ✅ **GELANDET** | hu von 2 → 5. Spürbar aufgefüllt. |
| **Humor Kap. 34** | ⚠️ **TEILS** | hu von 2 → 5 (Wert hoch), aber Noah/Marlie laut Bewertung im Kernmoment passiv. Humor da, Aktivierung fehlt. |
| **Humor Kap. 41** | ❌ **NICHT GELANDET** | hu von 2 → 1 (sogar gefallen). Kapitel bleibt reine Emotionsakkumulation ohne Ventil. |
| **Humor Kap. 42** | ⚠️ **TEILS** | hu von 2 → 3. Leichte Besserung, drei Klimaxe in Folge bleiben dicht. |

**Welle-1-Bilanz:** Überwiegend gelandet. Das Spannungstal ist klar repariert. Beim Humor-Cluster sind 17 voll, 11/34/42 teilweise repariert — **nur Kap. 41 ist als einziges humorseitig sogar leicht schlechter (1) und damit das verbleibende Sorgenkind.**

### Welle 2 (Charakter-Reparatur)

| Reparaturthema | Status | Beleg |
|----|----|----|
| **Marlie aktivieren (zweite Hälfte)** | ✅ **GELANDET** | Marlie ist durchgängig aktiv/treibend bewertet: Kap. 24 ("treibt Lage-Analyse"), 25 ("gibt Befehle, Wirkung"), 29 ("moralischer Motor"), 30 ("sehr aktiv"), 31/44 (treibt Plan). Kippt nur noch punktuell in Beobachterrolle (28, 33, 38) — und dort meist bewusst als Reflexionskapitel. Reparatur sitzt. |
| **Noah beleben** | ⚠️ **TEILWEISE — nicht durchgängig gelandet** | Noah hat echte Gewinner-Kapitel (6, 21, 27, 28, 31, 36, 40, 42, 44, 45 — teils "stärkster Moment des Romans"). ABER er bleibt in 11, 12, 18, 24, 25, 32, 33, 34, 38 explizit "blass/passiv/Statist" bewertet, in 29/38 fehlt er komplett. Das vom 14.06. als gravierendstes Problem markierte Thema ist **gemildert, aber nicht gelöst.** |
| **Liebesebene Noah/Marlie wiederbeleben** | ⚠️ **TEILWEISE** | Lebt in 27/31/36/40/44/46 ("emotionaler Kern"). Fehlt aber laut Bewertung weiterhin ganz in Kap. 12, 18, 24, 25, 32. Die zentrale Ebene 1 schläft also nicht mehr durchgehend, hat aber noch tote Strecken. |

**Welle-2-Bilanz:** Hälftiger Erfolg. **Marlie: gelandet. Noah: noch nicht durch.** Wer den 14.06.-Bericht ernst nimmt, muss anerkennen, dass das wichtigste figurale Ziel (Noah aus der Requisiten-Rolle holen) nur zur Hälfte erreicht ist — vor allem im KI-zentralen Block 24/32/33/34, wo ausgerechnet dem KI-Schöpfer eine eigene Position fehlt.

---

## 4. Konsistenz-Flags — konsolidiert (echt vs. unkritisch)

### A) ECHTE Issues (vor Verkauf prüfen/fixen)

**A1 — Timeline-Zahlenchaos 20/21/22/12 Jahre (DURCHGÄNGIG, höchste Priorität).**
Das verlorene Kind / Marias Trauer wird mal mit 20, mal 21, mal 22 Jahren angegeben; Noahs Eintritt mal 10, mal 12 Jahre; Projekt-Erstellung 12 Jahre; Theos Weggang 30 Jahre. Betroffen: Kap. 15, 17, 18, 22, 23, 30, 31, 35, 41, 42, 43, 46. In Kap. 23 sogar im **selben Absatz** 12 vs. 10 Jahre für denselben Zeitpunkt ("vor zwölf Jahren … vor zehn Jahren, bevor ich überhaupt da war" — in sich widersprüchlich). → **Eine verbindliche Master-Chronologie festlegen** (Geburt / Tod des Kindes / Stiftungsgründung / Noahs Eintritt / Theos Weggang) und alle Nennungen darauf vereinheitlichen. Das ist der wichtigste inhaltliche Fix.

**A2 — POV-Bruch Kap. 9.** Text sagt explizit "Marlie wusste es nicht, sie ahnte es nur", schildert aber Hannis nächtliche Szene in nur auktorial wissbaren Details (Hörgerät, blaues Licht). Erzählperspektive springt unmotiviert ins Allwissende. → Sauber an Marlies Wissenshorizont anpassen oder als klaren Szenenwechsel markieren. Echter handwerklicher Fehler.

**A3 — Personenzahl im Raum geht nicht auf (Kap. 26 & 29).** Kap. 26: "sechs erschöpfte Menschen" / "sechs Gesichter", namentlich aber nur fünf (Ben ist im Lager). Kap. 29: "Sechs erwachsene Menschen", gezeigt werden vier, Noah/Ben fehlen sichtbar. → Zählung korrigieren oder fehlende Figur benennen. Konkret nachzählbarer Fehler.

**A4 — Grammatischer Bruch Kap. 32:** "sah die Schritte sich nähern hören" — Vermischung zweier Konstruktionen (sah … / hörte …). Klarer Satzfehler. → Umschreiben.

**A5 — Wortstellungsfehler Kap. 26:** "ein Kind großgezogen hätte können" — Hilfsverb-Reihenfolge verdreht, korrekt: "großgezogen haben können". → Fix.

**A6 — Anrede-Inkonsistenz Nachname Marlie (Kap. 6, 29).** Marlie heißt mal "Braun" (Kap. 6 durchgängig, Kap. 29 "Frau Braun"), die Figur ist sonst nur per Vorname geführt. → Kanonischen Nachnamen festlegen und prüfen, ob "Brauns Schicht" (Kap. 6, als verdächtiger Datenpunkt) gewollte Ambiguität oder Namenskonflikt ist.

**A7 — Notstrom-vs-Blackout-Widerspruch (Kap. 24, 11, 40, 45).** Wiederkehrend: Ein Gerät hängt explizit am Notstrom-/Pufferkreis, fällt dann aber beim "Total-Blackout des ganzen Gebäudes" trotzdem aus — der gerade etablierte Notstromkreis beißt sich mit dem dramatischen Stromausfall. In Kap. 40 zusätzlich widersprüchliche Sekundenangaben (80 s / 2 min / 20 s) und "Theo legt aus 100 km Hauptschalter um". → Mindestens ein erklärender Satz pro Vorkommen, oder den Notstromkreis konsequenter behandeln. Technisch aufmerksame Leser stolpern hier.

**A8 — AURORA-Reichweite vs. etablierte Eingesperrtheit (DURCHGÄNGIG).** Die KI gilt als isoliert/abgeschottet, kennt aber Namen, sieht Live-Aktionen auf fremden Maschinen, erscheint auf Marlies privatem Heim-Laptop (Kap. 9, 10), hört Gesprochenes im Raum (Kap. 21, 4), schreibt auf versiegelte Hardware (Kap. 24, 26). Das ist **als zentrales Mystery bewusst gesetzt** — aber es wird so oft als "technisch unmöglich" markiert, dass der Roman dem Leser eine spätere Auflösung schuldet. → Kein Fix nötig, falls Folgeband geplant; **als bewusster Faden im Exposé festhalten**, damit ein Lektor/Verlag es nicht als Loch liest.

### B) UNKRITISCHE Flags (bewusste Mystery-Fäden / vertretbar)

Diese sind in den Bewertungen überwiegend selbst als "bewusst gesetzt / Cliffhanger / Setup" markiert und kein Mangel:
- Prolog/Kap. 1: AURORA "elf Tage" unbemerkt, Maria wählt Namen "ohne zu erklären", Archiv-Inhalt /ms/ — saubere Mystery-Saat.
- Kap. 3/4/5/7: drei Lügen, Dreyer-Termin, Ziffern-Datei, abgeschottete Sandbox kennt Marlie — alle als Hooks gewollt.
- Kap. 12/16/19: zwei AURORA-Kopien, 90-%-Kopie verhält sich vollwertig — großer Twist, bewusst offen, sollte aber im Auge behalten werden.
- Kap. 22/24/25/44: "Papa?"-Schrift auf versiegelter Hardware, der entzifferte Name, das blaue-Fenster-Detail (Wissen nur in Marias Kopf) — zentrale Cliffhanger, per Design vorenthalten.
- Diverse Killer/Räumer-Verbleibe (Kap. 7, 11, 12), Carlsson, der "Vogt ist nur der Hund"-Twist (Kap. 21) — lose Fäden, als Spannungsmittel akzeptabel, aber Liste führen.
- Physik-Ungenauigkeiten als Figurenrede (Kap. 33 "Trost senkt Temperatur", Kap. 42 "Quantenverschränkung über 3 m") — als verzweifelte Figuren-Aussagen vertretbar, kein Erzählfehler.

**Einschätzung B:** Alle unkritisch, SOFERN ein geplanter Schlussband/Sequel die großen Fäden (zwei Kopien, KI-Reichweite, Wissensherkunft) einlöst. Für ein Einzelbuch wären A8 + zwei-Kopien-Mechanik die einzigen, die eine Mini-Andeutung der Auflösung bräuchten.

---

## 5. Sprach-Flags — konsolidiert

### A) ECHTE Tippfehler / Grammatik / Klebungen (Pflicht-Korrektur vor Druck)

| Kap | Fehler | Korrektur |
|----|----|----|
| 1 | "ernstnimmt" | "ernst nimmt" (Getrenntschreibung) |
| 2 | "Appartementhaus" | "Apartmenthaus" (ein p, ein t) |
| 6 | "das, was mit Theo gelesen hat" | unvollständiger Satz, Objekt/Wort fehlt |
| 16 | "herrlich nach unten" (sinkende Kurve) | unpassendes Adverb, vermutlich "erleichternd/endlich" |
| 23 | "zurueknehmen" | "zurücknehmen" (fehlendes c) |
| 23 | "Werkzeugürtel" | fehlendes g — "Werkzeuggürtel" |
| 26 | "großgezogen hätte können" | "großgezogen haben können" (Wortstellung) |
| 32 | "sah die Schritte sich nähern hören" | grammatischer Bruch, umschreiben |
| 32 | Komma vor "als" bei einfachem Vergleich | Komma streichen |
| 35 | "in der kalten Junihaft knistern" | vermutlich "Juninacht" |
| 38 | "Ich hab ihm mir selbst eingeredet" | "Ich hab es mir selbst eingeredet" |
| 38 | "ab Jetzt" | "ab jetzt" (Kleinschreibung) |
| 45 | "der nie hätte benutzt werden dürfte" | "… benutzt werden dürfen" (Ersatzinfinitiv) |
| 45 | "Ein Mann mit einem Klemmbrett kann man wegschicken" | "Einen Mann …" (Akkusativ) |
| 31/41 | "das macht Sinn" | "das ergibt Sinn" (Anglizismus — bei Lektoratsmaßstab) |

→ Das sind **~15 konkrete, eindeutige Fehler.** Sie sind über das Buch verstreut und für sich genommen klein, aber sie sind genau das, was eine Verlags-Schlussredaktion erwartet, dass sie gefangen werden. **Diese Liste ist Pflicht-Korrektur.**

### B) Wortwiederholungen / Stilmittel an der Grenze (Optional, Feinschliff)

Überwiegend als **bewusste Anaphern/Leitmotive** markiert und funktionierend — aber an einigen Stellen ins Manierierte kippend. Häufungsmuster, die im Gesamtmanuskript auffallen:
- **"tastend(e)"** für AURORAs Schrift (Kap. 3, 18 — 5×): nutzt sich als Leitmotiv ab. → variieren.
- **Redundanz-Tripel Kap. 5:** "ohne Namen / ohne Endung / Folge von Ziffern" dreimal fast wörtlich in drei Absätzen — wirkt wie Bearbeitungsfehler, nicht Stil. → mind. eine Instanz streichen.
- **Doppelte Anekdote Kap. 20:** Emma (Leni) und Bens Tochter erzählen fast identisch "Ich hab nur geschaut" — schwächt beide Bilder. → eine variieren.
- **"sechs Jahre" Kap. 38** (9×), **"zweiundzwanzig Jahre" Kap. 18** (4× im ersten Absatz), **"Entgleiten" Kap. 43**, **"vielleicht" Kap. 42** (15×) — Leitmotive, dicht an Penetranz.
- **Tür-Motiv Kap. 15** (5× "verschlossene Tür"-Varianten): nutzt seine Wirkung ab.
- **Meta-Bruch Kap. 43:** "der Bruch, der seit dem vorigen Kapitel nicht mehr weggehen wollte" — Vierte-Wand-Bruch, sollte in In-Welt-Zeit umgeschrieben werden. (Grenzfall: halb echt, halb stilistisch — empfohlen zu fixen.)
- "Atem" als Plural (Kap. 30 "nicht viele Atem") — holprig, → "Atemzüge".

→ Diese sind **kein Blocker.** Empfehlung: Der Redundanz-Tripel Kap. 5, die Doppel-Anekdote Kap. 20 und der Meta-Bruch Kap. 43 sind die drei, die ich auch im Optional-Durchgang noch anfassen würde, weil sie wie Fehler statt wie Stil wirken.

---

## 6. Verbleibende Empfehlungen vor Verkauf (priorisiert)

### 🔴 BLOCKER (vor jeder Einreichung/Verkauf zwingend)

1. **Timeline vereinheitlichen (A1).** Master-Chronologie festlegen, 20/21/22/12/10-Jahre-Nennungen über Kap. 15–46 angleichen. Besonders Kap. 23 (Widerspruch im selben Absatz). — *Höchste Priorität, weil ein Lektor das sofort sieht und es Vertrauen kostet.*
2. **~15 Tippfehler/Grammatikfehler korrigieren (Abschnitt 5A).** Eindeutige Liste, mechanisch abzuarbeiten.
3. **POV-Bruch Kap. 9 reparieren (A2).** Perspektive an Marlies Wissen binden.
4. **Personenzahl Kap. 26 & 29 korrigieren (A3).** Nachzählbarer Fehler.
5. **Nachname-Kanon Marlie klären (A6)** ("Braun" vs. nur Vorname) — und konsistent durchziehen.

### 🟡 OPTIONAL (Qualitätshebung, kein Show-Stopper)

6. **Noah-Restpassivität (Welle 2, halb offen).** Pro betroffenem Kapitel (12, 18, 24, 32, 33, 34) eine aktive Geste/Position geben — besonders im KI-Block 24/32/33/34, wo der KI-Schöpfer keine Stimme hat. *Wichtigste verbleibende figurale Arbeit, aber Buch ist auch ohne verkäuflich.*
7. **Humor-Resttäler Kap. 41 (hu 1!) und 11/34/42.** Kap. 41 ist das einzige, das sich verschlechtert hat — ein Leni-/Marlie-Funken aus Erschöpfung (kein aufgesetztes Comic Relief).
8. **Kap. 46 (Sp 5) straffen.** Neues schwächstes Kapitel; Trauer-/Fahrt-Wiederholungen kürzen, Wiederholungs-Cluster ("am Grab eines Kindes" 3×, "vorsichtig" doppelt) auflösen.
9. **Notstrom/Blackout-Logik (A7)** mit je einem erklärenden Satz abfedern (Kap. 11/24/40/45).
10. **Sprachliche Redundanzen** Kap. 5 (Ziffern-Tripel), Kap. 20 (Doppel-Anekdote), Kap. 43 (Meta-Bruch) glätten.
11. **Mystery-Fäden-Register (A8 + zwei Kopien) im Exposé dokumentieren**, damit Verlag bewusste Saat von Loch unterscheiden kann — und sicherstellen, dass ein geplanter Folgeband sie einlöst.

---

## 7. Fazit für den Verlag

AURORA ist **verkaufsreif mit Auflagen.** Die Substanz stimmt: starke Hooks, geschlossene Spannungstäler, ein verlässlich tragendes KI-Herz und eine Spitzen-Tragödie um Maria/Theo. Die Welle-1-Arbeit hat das strukturell größte Problem (Kap.-2-Tal) beseitigt; die Welle-2-Arbeit hat Marlie erfolgreich reaktiviert. Was bleibt, ist ein **klar umrissener Schlussredaktions-Durchgang** (Timeline + Tippfehler + drei Handwerksfehler) plus, wenn Zeit ist, Noahs Restbelebung und zwei Humortäler. Nichts davon ist ein Show-Stopper — aber die fünf Blocker müssen vor der ersten Einreichung erledigt sein.

---
*Gegencheck erstellt von Bolla (Claude Code, Opus 4.8) · unabhängiges Cheflektorat · Basis: 47 frische Kapitelbewertungen vs. Bericht 14.06.*
